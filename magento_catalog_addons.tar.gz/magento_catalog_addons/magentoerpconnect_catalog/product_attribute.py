# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright 2013
#    Author: Guewen Baconnier - Camptocamp
#            Augustin Cisterne-Kaas - Elico-corp
#            David Béal - Akretion
#            Sébastien Beau - Akretion
#            Chafique Delli - Akretion
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################


from openerp import models, fields, api, _
#from openerp.tools.translate import _
from openerp.osv.osv import except_osv
from openerp.exceptions import Warning
from openerp.addons.connector.unit.mapper import (
    mapping,
    #changed_by,
    ImportMapper,
    ExportMapper,)
from openerp.addons.magentoerpconnect.unit.import_synchronizer import (
    DelayedBatchImport,
    MagentoImportSynchronizer, )
import logging
_logger = logging.getLogger(__name__)

#from openerp.addons.connector.exception import MappingError
from openerp.addons.magentoerpconnect.backend import magento
from openerp.addons.magentoerpconnect.unit.backend_
 import GenericAdapter
from openerp.addons.magentoerpconnect.unit.binder import MagentoModelBinder
from openerp.addons.magentoerpconnect.unit.delete_synchronizer import (
    MagentoDeleteSynchronizer)
from openerp.addons.magentoerpconnect.unit.export_synchronizer import (
    MagentoExporter)
from openerp.addons.magentoerpconnect.unit.import_synchronizer import (
    DelayedBatchImport,
    MagentoImportSynchronizer,)
from openerp.addons.connector.exception import FailedJobError


@magento(replacing=MagentoModelBinder)
class MagentoAttributeBinder(MagentoModelBinder):
    _model_name = [
        'magento.product.attribute',
        'magento.attribute.option',
        'magento.attribute.set',
        ]



@magento
class ProductAttributeAdapter(GenericAdapter):
    _model_name = 'magento.product.attribute'
    _magento_model = 'ol_catalog_product_attribute'
    _magento_default_model = 'product_attribute'

    def delete(self, id):
        return self._call('%s.remove'% self._magento_model,[int(id)])
    
    def search(self, filters=None):
        """ Search records according and returns a list of ids
        :rtype: list
        """
        return [int(row['attribute_id']) for row
                in self._call('%s.entirelist' % self._magento_model, [])]
#         return self._call('%s.entirelist' % self._magento_model, [])
        #return self._call('%s.search' % self._magento_model, [])
    
    def search_attribute(self, filters=None):
        """ Search records according and returns a list of ids
            :rtype: list
        """
        id=filters.get('attribute_set_id')
#         return [int(row['attribute_id']) for row
#                 in self._call('%s.list' % self._magento_model,[id])]
        return self._call('%s.list' % self._magento_model, [id])

    def read(self, id,  attributes=None):
        """ Returns the information of a record
        :rtype: dict
        """
        #return self._call('%s.info' % self._magento_model, [int(id)])
#         if isinstance(id, dict):
#             id=id.get('attribute_id' , False)
        result = self._call('%s.info' % self._magento_model,[int(id)])          
        
        return result
#     
#     def read(self, id, attributes=None):
#         """ Returns the information of a record
# 
#         :rtype: dict
#         """
#         #Updated by krishna/Krishna
#         if isinstance(id, dict):
#             id=id.get('attribute_id' , False)
#         #Over
#         arguments = [int(id)]
#         if attributes:          
#             arguments.append(attributes)
#         result=self._call('%s.info' % self._magento_model,
#                           arguments)


# Attribute Set
class AttributeSet(models.Model):
    _inherit = 'attribute.set'

    magento_bind_ids=fields.One2many(comodel_name='magento.attribute.set',
                                     inverse_name='openerp_id',
                                     string='Magento Bindings')
    


class MagentoAttributeSet(models.Model):
    _name = 'magento.attribute.set'
    _description = "Magento attribute set"
    _inherit = 'magento.binding'
    _rec_name = 'attribute_set_name'

    openerp_id=fields.Many2one('attribute.set',
                               string='Attribute set',
                               ondelete='cascade')
    
    attribute_set_name=fields.Char(string='Name',size=64,required=True)
    sort_order=fields.Integer(string='Sort order',readonly=True)
    attribute_list=fields.Text(string="Attribute List")
    group_list=fields.Text(string="Group List")
    
    @api.multi
    def name_get(self):
        res = []
        for elm in self.read( ['attribute_set_name']):
            res.append((elm['id'], elm['attribute_set_name']))
        return res

    _sql_constraints = [
        ('magento_uniq', 'unique(backend_id, openerp_id)',
         "An 'Attribute set' with the same ID on this Magento backend "
         "already exists")
                        ]
    @api.multi
    def create_new_field(self):
        ctx=self.env.context.copy()
        ctx.update({'connector_no_export': True})
        #if not self._context:
        #self.session.change_context({'connector_no_export': True})           
        for attributeset in self:
            product_template_models = self.env['ir.model'].search([('model', '=', 'product.product')])
            product_template_model_id=[x.id for x in product_template_models]
            if not attributeset.openerp_id:
                new_set = self.env['attribute.set'].with_context(ctx).create({'model_id': product_template_model_id[0],
                                                                          'name': attributeset.attribute_set_name})
                new_set=new_set.id
                attributeset.with_context(ctx).write({'openerp_id': new_set})
            else:
                new_set = attributeset.openerp_id.id
            groups = self.env['magento.attribute.group'].search([('attribute_set_id', '=', attributeset.id)])

            for group in groups: 
                group_check = self.env['attribute.group'].search([('name', '=', group.name),('attribute_set_id', '=', new_set),
                                                                                ('model_id', '=',product_template_model_id[0])])
                group_check_id=[x.id for x in group_check]
                if group_check_id:
                    new_group_id = group_check_id[0]
                else:
                    new_group = self.env['attribute.group'].with_context(ctx).create({'name': group.name,
                                                                         'attribute_set_id': new_set,
                                                                         'sequence': group.sort_order,
                                                                         'model_id': product_template_model_id[0]})
                    new_group_id=new_group.id
                #self.pool.get('magento.attribute.group').write(cr, uid, group.id, {'openerp_id': new_group})
                group.with_context(ctx).write({'openerp_id': new_group_id})

                if group.attribute_list:
                    check_attribute = eval(group.attribute_list)
                else:
                    check_attribute = {}
                for key in check_attribute.keys():
                    openerp_attribute_list = self.env['magento.product.attribute'].search([('magento_id', '=', key)])
                    for openerp_attribute in openerp_attribute_list: 
                        openerp_attribute.create_new_field()
                    for attribute in openerp_attribute_list:
                        if attribute.openerp_id:
                            check = self.env['attribute.location'].search([('attribute_id', '=', attribute.openerp_id.id),('attribute_group_id', '=', new_group_id)])
                            if not check:
                                self.env['attribute.location'].with_context(ctx).create({'attribute_id': attribute.openerp_id.id,
                                                                            'attribute_group_id': new_group_id,
                                                                            'sequence': int(check_attribute.get(key))
                                                                            
                                                                           })
        return True


@magento
class AttributeSetAdapter(GenericAdapter):
    _model_name = 'magento.attribute.set'
    _magento_default_model = 'product_attribute_set'
    _magento_model = 'ol_catalog_product_attributeset'

    def create(self, data):
        """ Create a record on the external system """
        return self._call('%s.create' % self._magento_default_model,
                          [data['attribute_set_name'], data['skeletonSetId']])

    def delete(self, id):
        """ Delete a record on the external system """
        return self._call('%s.remove' % self._magento_default_model, [str(id)])

    def search(self, filters=None):
        """ Search records according and returns a list of ids
        :rtype: list
        """
        return self._call('%s.search' % self._magento_model, [])

    def read(self, id, storeview_id=None, attributes=None):
        """ Returns the information of a record
        :rtype: dict
        """
        #        return self._call('%s.info' % self._magento_model, [int(id)])
        result = self._call('%s.info' % self._magento_model, [int(id)])
        groups = self._call('ol_catalog_product_attribute_group.list', [{'attribute_set_id': int(id)}])
        attribute_list = self._call('ol_catalog_product_attribute.list', [int(id)])
        result_groups = []
        for item in groups:
            if item.get('attribute_set_id') == id:
                group_attribute_list = {}
                for attribute in attribute_list:
                    if attribute.get('group_id') == item.get('attribute_group_id'):
                        group_attribute_list[attribute.get('attribute_id')] = attribute.get('attribute_set_info').get(
                            id).get('sort')
                item['attribute_list'] = group_attribute_list
                result_groups.append(item)
        result['group_list'] = result_groups
        return result   

    
#     def read(self, id, storeview_id=None, attributes=None):
#         """ Returns the information of a record
#         :rtype: dict
#         """
#         return self._call('%s.info' % self._magento_model, [int(id)])

    def update(self, id, attribute_id):
        """ Add an existing attribute to an attribute set on the external system
        :rtype: boolean
        """
        return self._call('%s.attributeAdd' % self._magento_default_model,
                          [str(attribute_id),str(id)])


@magento
class AttributeSetDelayedBatchImport(DelayedBatchImport):
    _model_name = ['magento.attribute.set']


@magento
class AttributeSetImport(MagentoImportSynchronizer):
    _model_name = ['magento.attribute.set']
    
    def _create(self, data):
        """ Create the OpenERP record """
        with self.session.change_context({'connector_no_export': True}):
            binding_id = self.session.create(self.model._name, data)
            option_list = []
            if data.get('group_list'):
                for item in data.get('group_list'):
                    check = self.session.search('magento.attribute.group',
                                                [('magento_id', '=', item.get('attribute_group_id')),
                                                 ('backend_id', '=', data.get('backend_id'))])
                    if not check:
                        id = self.session.create('magento.attribute.group',
                                                 {'magento_id': item.get('attribute_group_id'),
                                                  'sort_order': item.get('sort_order'),
                                                  'attribute_list': item.get('attribute_list'),
                                                  'attribute_set_id': binding_id,
                                                  'backend_id': data.get('backend_id'),
                                                  'name': item.get('attribute_group_name'), })
                    else:
                        id = check[0]
                        self.session.write('magento.attribute.group', [id],
                                           {'magento_id': item.get('attribute_group_id'),
                                            'sort_order': item.get('sort_order'),
                                            'attribute_list': item.get('attribute_list'),
                                            'attribute_set_id': binding_id,
                                            'backend_id': data.get('backend_id'),
                                            'name': item.get('attribute_group_name')})
                    option_list.append(id)
                check_link = self.session.search('magento.attribute.group', [('id', 'not in', option_list),
                                                                             ('attribute_set_id', '=', binding_id),
                                                                             ('backend_id', '=',
                                                                              data.get('backend_id'))])
                self.session.unlink('magento.attribute.group', check_link)
                self.session.browse('magento.attribute.set',[binding_id]).create_new_field()
        _logger.debug('%s %d created from magento %s',
                      self.model._name, binding_id, self.magento_id)
        return binding_id

    def _update(self, binding_id, data):
        """ Create the OpenERP record """
        with self.session.change_context({'connector_no_export': True}):
            self.session.write(self.model._name, binding_id, data)
            option_list = []
            if data.get('group_list'):
                for item in data.get('group_list'):
                    check = self.session.search('magento.attribute.group',
                                                [('magento_id', '=', item.get('attribute_group_id')),
                                                 ('attribute_set_id', '=', binding_id),
                                                 ('backend_id', '=', data.get('backend_id'))])
                    if not check:
                        id = self.session.create('magento.attribute.group',
                                                 {'magento_id': item.get('attribute_group_id'),
                                                  'sort_order': item.get('sort_order'),
                                                  'attribute_list': item.get('attribute_list'),
                                                  'attribute_set_id': binding_id,
                                                  'backend_id': data.get('backend_id'),
                                                  'name': item.get('attribute_group_name')})
                    else:
                        id = check[0]
                        self.session.write('magento.attribute.group', [id],
                                           {'magento_id': item.get('attribute_group_id'),
                                            'sort_order': item.get('sort_order'),
                                            'attribute_list': item.get('attribute_list'),
                                            'attribute_set_id': binding_id,
                                            'backend_id': data.get('backend_id'),
                                            'name': item.get('attribute_group_name')})
                    option_list.append(id)
                check_link = self.session.search('magento.attribute.group', [('id', 'not in', option_list),
                                                                             ('attribute_set_id', '=', binding_id),
                                                                             ('backend_id', '=',data.get('backend_id'))])
                self.session.unlink('magento.attribute.group', check_link)
                self.session.browse('magento.attribute.set',[binding_id]).create_new_field()
        _logger.debug('%s %d created from magento %s',
                      self.model._name, binding_id, self.magento_id)
        return binding_id




@magento
class AttributeSetImportMapper(ImportMapper):
    _model_name = 'magento.attribute.set'

    direct = [
        ('attribute_set_name', 'attribute_set_name'),
        ('attribute_set_id', 'magento_id'),
        ('sort_order', 'sort_order'),
        ('group_list', 'group_list'),
        ('attribute_list', 'attribute_list')]
         

    @mapping
    def backend_id(self, record):
        return {'backend_id': self.backend_record.id}


@magento
class AttributeSetDeleteSynchronizer(MagentoDeleteSynchronizer):
    _model_name = ['magento.attribute.set']


@magento
class AttributeSetExport(MagentoExporter):
    _model_name = ['magento.attribute.set']


@magento
class AttributeSetExportMapper(ExportMapper):
    _model_name = 'magento.attribute.set'

    direct = [
        ('attribute_set_name', 'attribute_set_name'),
        ('sort_order', 'sort_order'),
    ]

    @mapping
    def skeletonSetId(self, record):
        tmpl_set_id = self.backend_record.attribute_set_tpl_id.id
        if tmpl_set_id:
            binder = self.get_binder_for_model('magento.attribute.set')
            magento_tpl_set_id = binder.to_backend(tmpl_set_id)
        else:
            raise FailedJobError((
                "'Attribute set template' field must be define on "
                "the backend.\n\n"
                "Resolution: \n"
                "- Go to Connectors > Magento > Backends > '%s'\n"
                "- Fill the field Attribte set Tempalte\n"
                )% self.backend_record.name)
        return {'skeletonSetId': magento_tpl_set_id}


# Attribute
class AttributeAttribute(models.Model):
    _inherit = 'attribute.attribute'

    @api.multi
    def _get_model_product(self):
        model, res_id = self.env['ir.model.data'].get_object_reference('product', 'model_product_product')
        return res_id

    magento_bind_ids=fields.One2many('magento.product.attribute',
                                     'openerp_id',
                                     string='Magento Bindings')
                                     #default=_get_model_product)
    
class MagentoProductAttribute(models.Model):
    _name = 'magento.product.attribute'
    _description = "Magento Product Attribute"
    _inherit = 'magento.binding'
    _rec_name = 'attribute_code'
    MAGENTO_HELP = "This field is a technical / configuration field for " \
                   "the attribute on Magento. \nPlease refer to the Magento " \
                   "documentation for details. "


    
    @api.multi
    def copy(self, default=None):
        if default is None:
            default = {}
        default['attribute_code'] = default.get('attribute_code', '') + 'Copy '
        return super(MagentoProductAttribute, self).copy(default)
    
    @api.multi
    def _frontend_input(self):
        res={}
        for elm in self:
            field_type = elm.openerp_id.attribute_type
            map_type = {
                'char': 'text',
                'text': 'textarea',
                'float': 'price',
                'datetime': 'date',
                'binary': 'media_image',
            }
            res[elm.id] = map_type.get(field_type, field_type)
        return res

 
    openerp_id=fields.Many2one('attribute.attribute',
                               string='Attribute',    
                               ondelete='cascade')
    
    attribute_code=fields.Char(string='Code',
                               required=True,
                               size=200)
    
    scope=fields.Selection([('store', 'store'), ('website', 'website'), ('global', 'global')],
                           string='Scope',default='global',
                           required=True,
                           help=MAGENTO_HELP)
    
    apply_to=fields.Selection([('simple', 'simple')],
                              string='Apply to',required=True,default='simple',
                              help=MAGENTO_HELP)
    
    frontend_input=fields.Char(compute=_frontend_input,
                               method=True,
                               string='Frontend input',
                               store=False,
                               help="This field depends on OpenERP attribute 'type' field "
                               "but used on Magento")
    
    frontend_label=fields.Char(string='Label', required=True, size=100, help=MAGENTO_HELP)
    position=fields.Integer(string='Position', help=MAGENTO_HELP)
    group_id= fields.Integer(string='Group', help=MAGENTO_HELP) 
    default_value=fields.Char(string='Default Value',size=10,help=MAGENTO_HELP)
    note=fields.Char(string='Note', size=200, help=MAGENTO_HELP)
    entity_type_id=fields.Integer(string='Entity Type', help=MAGENTO_HELP)
        # boolean fields
    is_visible_in_advanced_search=fields.Boolean(string='Visible in advanced search?', help=MAGENTO_HELP,default=True)
    is_visible=fields.Boolean(string='Visible?', help=MAGENTO_HELP,default=True)
    is_visible_on_front=fields.Boolean(string='Visible (front)?', help=MAGENTO_HELP,default=True)
    is_html_allowed_on_front=fields.Boolean(string='Html (front)?', help=MAGENTO_HELP)
    is_wysiwyg_enabled=fields.Boolean(string='Wysiwyg enabled?', help=MAGENTO_HELP)
    is_global=fields.Boolean('Global?', help=MAGENTO_HELP)
    is_unique=fields.Boolean('Unique?', help=MAGENTO_HELP)
    is_required=fields.Boolean('Required?', help=MAGENTO_HELP)
    is_filterable=fields.Boolean('Filterable?', help=MAGENTO_HELP,default=True)
    is_comparable=fields.Boolean('Comparable?', help=MAGENTO_HELP,default=True)
    is_searchable=fields.Boolean('Searchable ?', help=MAGENTO_HELP,default=True)
    is_configurable=fields.Boolean('Configurable?', help=MAGENTO_HELP)
    is_user_defined=fields.Boolean('User defined?', help=MAGENTO_HELP)
    used_for_sort_by=fields.Boolean('Use for sort?', help=MAGENTO_HELP)
    is_used_for_price_rules=fields.Boolean('Used for pricing rules?', help=MAGENTO_HELP)
    is_used_for_promo_rules=fields.Boolean('Use for promo?', help=MAGENTO_HELP)
    used_in_product_listing=fields.Boolean('In product listing?', help=MAGENTO_HELP)
    #added by krishna
    options=fields.Text(string="Attribute Options")
    option_ids=fields.One2many('magento.attribute.option', 'attribute_id',string='Options')
    field_id=fields.Many2one('ir.model.fields', string='Field ID')
    create_state=fields.Selection([('new', 'New'),('created', 'Done')], string='State')
    additional_check=fields.Boolean(string='is it additional?')
    type=fields.Selection([('char', 'Char'),
                                         ('text', 'Text'),
                                         ('select', 'Select'),
                                         ('multiselect', 'Multiselect'),
                                         ('boolean', 'Boolean'),
                                         ('integer', 'Integer'),
                                         ('date', 'Date'),
                                         ('datetime', 'Datetime'),
                                         ('binary', 'Binary'),
                                         ('float', 'Float')],
                                         string='Type',required=True)
    
                                 
    _sql_constraints = [
        ('magento_uniq', 'unique(attribute_code)',
         "Attribute with the same code already exists : must be unique"),
        ('openerp_uniq', 'unique(backend_id, openerp_id)',
         'An attribute can not be bound to several records on the same backend.'),
    ]
    #added by krishna
    @api.multi
    def create_new_field(self):
        ctx=self.env.context.copy()
        ctx.update({'connector_no_export': True})
        if not self._context:
            self.session.change_context({'connector_no_export': True})
        for attribute in self:
            if not attribute.field_id:
                product_template_models = self.env['ir.model'].search([('model', '=', 'product.product')])
                product_template_model_id=[x.id for x in product_template_models]
                checks = self.env['ir.model.fields'].search([('name', '=', 'x_%s' % attribute.attribute_code),('model_id','in',product_template_model_id)])
                check=[x.id for x in checks]
                if not check:
                    field_obj = self.env['attribute.attribute'].with_context(ctx).create({'relation_model_id': None,
                                                                                     'attribute_type': attribute.type,
                                                                                     'model': 'product.product',
                                                                                     'model_id':
                                                                                         product_template_model_id[0],
                                                                                     'ttype': attribute.type,
                                                                                     'name': 'x_%s' % attribute.attribute_code,
                                                                                     'field_description': attribute.frontend_label,
                    })
                    field_id=field_obj.id 
                    
                else:
                    check_atts = self.env['attribute.attribute'].search([('field_id', 'in', check)])
                    check_att=[x.id for x in check_atts]
                    if check_att:
                        field_id = check_att[0]
                    else:
                        field_obj = self.env['attribute.attribute'].with_context(ctx).create( {'relation_model_id': None,
                                                                                         'attribute_type': attribute.type,
                                                                                         'model': 'product.product',
                                                                                         'model_id': product_template_model_id[0],
                                                                                         'field_id': check[0] })
                        field_id=field_obj.id          
                for option in attribute.option_ids:
                    check_option = self.env['attribute.option'].search([('name', '=', option.name),
                                                                        ('attribute_id', '=', field_id)])
                    if not check_option:
                        option_obj = self.env['attribute.option'].with_context(ctx).create({'name': option.name,
                                                                              'attribute_id': field_id,
                                                                              'system_option':option.system_option})
                        option.with_context(ctx).write({'openerp_id': option_obj.id})                
                attribute.with_context(ctx).write({'openerp_id': field_id, 'create_state': 'created'})
        return True


@magento
class ProductAttributeDeleteSynchronizer(MagentoDeleteSynchronizer):
    _model_name = ['magento.product.attribute']
    
#Added by krishna

@magento
class ProductAttributeDelayedBatchImport(DelayedBatchImport):
    _model_name = ['magento.product.attribute']


@magento
class ProductAttributeImport(MagentoImportSynchronizer):
    _model_name = ['magento.product.attribute']
    
    def _create(self, data):
        """ Create the OpenERP record """
        with self.session.change_context({'connector_no_export': True}):

            check = self.session.search('magento.product.attribute', [('magento_id', '=', data.get('magento_id')),
                                                                      ('backend_id', '=', data.get('backend_id'))])

            if not check:
                check = self.session.search('magento.product.attribute',
                                            [('attribute_code', '=', data.get('attribute_code'))])
            if not check:
                binding_id = self.session.create(self.model._name, data)
            else:
                binding_id = check[0]
                self.session.write(self.model._name, binding_id, data)
            option_list = []
            if data.get('options'):
                for item in data.get('options'):
                    check = self.session.search('magento.attribute.option',
                                                [('magento_id', '=', str(item.get('value'))),
                                                 ('backend_id', '=', data.get('backend_id')),
                                                 ('attribute_id', '=', binding_id)])
                    if not check:
                        if item.get('value') == 0:
                            value = '0'
                        elif item.get('value') is None:
                            value = 'None'
                        elif item.get('value') is False:
                            value = 'False'
                        elif item.get('value') == '':
                            continue
                        else:
                            value = item.get('value')
                        option_id = self.session.create('magento.attribute.option', {'magento_id': value,
                                                                                     'attribute_id': binding_id,
                                                                                     'backend_id': data.get(
                                                                                         'backend_id'),
                                                                                     'name': item.get('label'),
                                                                                     'system_option': item.get('system_option','false') == 'true' })
                                                                                                    
                    else:
                        option_id = check[0]
                    option_list.append(option_id)
                extra_option_ids = self.session.search('magento.attribute.option', [('id', 'not in', option_list),
                                                                              ('attribute_id', '=', binding_id),
                                                                              ('backend_id', '=',
                                                                               data.get('backend_id'))])
                if extra_option_ids:
                    with self.session.change_context({'connector_no_export': True}):
                        self.session.unlink('magento.attribute.option', extra_option_ids)
                        
            self.session.browse('magento.product.attribute',[binding_id]).create_new_field()
             
        _logger.debug('%s %d created from magento %s',
                      self.model._name, binding_id, self.magento_id)#('%s %d created from magento %s', 'magento.product.attribute', 272, '185')
            
        return binding_id
#'%s %d created from magento %s',self.model._name, binding_id, self.magento_id
    
    def _update(self, binding_id, data):
        """ Update an OpenERP record """
        with self.session.change_context({'connector_no_export': True}):
            self.session.write(self.model._name, binding_id, data)
        _logger.debug('%s %d updated from magento %s',
                      self.model._name, binding_id, self.magento_id)
        return
    
@magento
class ProductAttributeImportMapper(ImportMapper):
    _model_name = 'magento.product.attribute'
    direct = [
        ('attribute_code', 'attribute_code'),  # required
#         ('frontend_input', 'frontend_input'),
        ('scope', 'scope'),
        ('is_global', 'is_global'),
        ('is_filterable', 'is_filterable'),
        ('is_comparable', 'is_comparable'),
        ('is_visible', 'is_visible'),
        ('is_searchable', 'is_searchable'),
        ('is_user_defined', 'is_user_defined'),
        ('is_configurable', 'is_configurable'),
        ('is_visible_on_front', 'is_visible_on_front'),
        ('is_used_for_price_rules', 'is_used_for_price_rules'),
        ('is_unique', 'is_unique'),
        ('is_required', 'is_required'),
        ('position', 'position'),
        ('group_id', 'group_id'),
        ('default_value', 'default_value'),
        ('is_visible_in_advanced_search', 'is_visible_in_advanced_search'),
        ('note', 'note'),
        ('entity_type_id', 'entity_type_id'),
        ('frontend_label', 'frontend_label'),
#         ('backend_type', 'type'),
        ('attribute_id', 'magento_id'),
        ('options', 'options'),
        ('is_wysiwyg_enabled','is_wysiwyg_enabled'),
        ('is_html_allowed_on_front','is_html_allowed_on_front'),
        ('is_used_for_promo_rules','is_used_for_promo_rules'),
        ('used_for_sort_by','used_for_sort_by'),
        ('used_in_product_listing','used_in_product_listing'),
        ('field_id','field_id'),        
        ('additional_check','additional_check')
    ]

    @mapping
    def backend_id(self, record):

        return {'backend_id': self.backend_record.id}

    @mapping
    def frontend_label(self, record):
        #required
        direct = [
        ('updated_date','updated_date_in_magento'),
        ('attribute_code', 'attribute_code'),  # required
#         ('frontend_input', 'frontend_input'),
        ('scope', 'scope'),
        ('is_global', 'is_global'),
        ('is_filterable', 'is_filterable'),
        ('is_comparable', 'is_comparable'),
        ('is_visible', 'is_visible'),
        ('is_searchable', 'is_searchable'),
        ('is_user_defined', 'is_user_defined'),
        ('is_configurable', 'is_configurable'),
        ('is_visible_on_front', 'is_visible_on_front'),
        ('is_used_for_price_rules', 'is_used_for_price_rules'),
        ('is_unique', 'is_unique'),
        ('is_required', 'is_required'),
        ('position', 'position'),
        #('group_id', 'group_id'),
        ('default_value', 'default_value'),
        ('is_visible_in_advanced_search', 'is_visible_in_advanced_search'),
        ('note', 'note'),
        ('entity_type_id', 'entity_type_id'),
        ('frontend_label', 'frontend_label'),
#         ('backend_type', 'type'),
        ('attribute_id', 'magento_id'),
        ('options', 'options'),
        ('is_wysiwyg_enabled','is_wysiwyg_enabled'),
        ('is_html_allowed_on_front','is_html_allowed_on_front'),
        ('is_used_for_promo_rules','is_used_for_promo_rules'),
        ('used_for_sort_by','used_for_sort_by'),
        ('used_in_product_listing','used_in_product_listing'),
        ('field_id','field_id'),
    ]
        res = {}
        apply_list = ['grouped', 'configurable', 'virtual', 'bundle', 'downloadable','simple']
        if not record.get('apply_to'):
            record['apply_to'] = apply_list
        for apply_type in apply_list:
            if apply_type in record.get('apply_to'):
                res['apply_to_%s' % apply_type] = True
            else:
                res['apply_to_%s' % apply_type] = False
        for item in direct:
            if record.get(item[0]):
                if record.get(item[0]) == '0':
                    res[item[1]] = False
                else:
                    res[item[1]] = record[item[0]]
        if isinstance(record.get('frontend_label'), list):
            label = record.get('frontend_label')[0].get('label')
        else:
            label = record.get('frontend_label')
        if not label:
            label = 'No frontend label'
        #replace type with 'frontend_input' by krishna
        print record.get('frontend_input',False)
        if record.get('frontend_input'):
            if record.get('frontend_input') in  ['textarea']:
                record['type'] = 'text'
            elif record.get('frontend_input') == 'text':
                record['type'] = 'char'
            elif record.get('frontend_input') == 'date':
                record['type'] = 'date'
            elif record.get('frontend_input') == 'boolean':
                record['type'] = 'boolean'
            elif record.get('frontend_input') == 'multiselect':
                record['type'] = 'multiselect'
            elif record.get('frontend_input') in ['price', 'weee', 'weight']:
                record['type'] = 'float'
            elif record.get('frontend_input') == 'media_image':
                record['type'] = 'binary'
            elif  record.get('frontend_input') == 'select':
                record['type'] = 'select'
            else:
                record['type'] = 'text'
        else:
            record['type'] = 'text'
        scope = record.get('scope')
        if not scope:
            scope = 'global'
        config_value = False
        if record.get('is_configurable'):
            if record.get('is_configurable') == '1':
                config_value = True
        if record.get('is_filterable'):
            if record.get('is_filterable') != '0':
                res['is_filterable'] = True
        res['is_configurable'] = config_value
        res['frontend_label'] = label
        res['type'] =  record.get('type')
        res['scope'] = scope
        #{'is_configurable': config_value, 'frontend_label': label, 'scope': scope, 'frontend_input': record.get('frontend_input')}
        return res

#Completed

@magento
class ProductAttributeExport(MagentoExporter):
    _model_name = ['magento.product.attribute']

    def _should_import(self):
        "Attributes in magento doesn't retrieve infos on dates"
        return False

#     def _after_export(self):
#         """ Run the after export"""
#         sess = self.session
#         attribute_location_obj = sess.pool.get('attribute.location')
#         magento_attribute_obj = sess.pool.get('magento.product.attribute')
#         magento_attribute_set_obj = sess.pool.get('magento.attribute.set')
#         attribute_set_adapter = self.get_connector_unit_for_model(
#             GenericAdapter, 'magento.attribute.set')
#         attribute_id = self.binding_record.openerp_id.id
#         magento_attribute_id = magento_attribute_obj.browse(
#                     sess.cr, sess.uid,
#                     self.binding_record.id,context=sess.context).magento_id
#         attribute_location_ids = attribute_location_obj.search(
#             sess.cr, sess.uid,
#             [['attribute_id','=',attribute_id]], context=sess.context)
#         for attribute_location in attribute_location_ids:
#             attribute_set_id = attribute_location_obj.browse(
#                 sess.cr, sess.uid,
#                 attribute_location, context=sess.context).attribute_set_id.id
#             magento_attribute_set_ids = magento_attribute_set_obj.search(
#                 sess.cr, sess.uid,
#                 [['openerp_id','=',attribute_set_id]],
#                 context=sess.context)
#             for magento_attribute_set in magento_attribute_set_ids:
#                 magento_attribute_set_id = magento_attribute_set_obj.browse(
#                     sess.cr, sess.uid,
#                     magento_attribute_set,context=sess.context).magento_id
#                 attribute_set_adapter.update(
#                     magento_attribute_set_id, magento_attribute_id)



@magento
class ProductAttributeExportMapper(ExportMapper):
    _model_name = 'magento.product.attribute'

    direct = [
        ('attribute_code', 'attribute_code'), # required
        ('frontend_input', 'frontend_input'),
        ('scope', 'scope'),
        ('is_global', 'is_global'),
        ('is_filterable', 'is_filterable'),
        ('is_comparable', 'is_comparable'),
        ('is_visible', 'is_visible'),
        ('is_searchable', 'is_searchable'),
        ('is_user_defined', 'is_user_defined'),
        ('is_configurable', 'is_configurable'),
        ('is_visible_on_front', 'is_visible_on_front'),
        ('is_used_for_price_rules', 'is_used_for_price_rules'),
        ('is_unique', 'is_unique'),
        ('is_required', 'is_required'),
        ('position', 'position'),
        ('group_id', 'group_id'),
        ('default_value', 'default_value'),
        ('is_visible_in_advanced_search', 'is_visible_in_advanced_search'),
        ('note', 'note'),
        ('entity_type_id', 'entity_type_id'),
        ]

    @mapping
    def frontend_label(self, record):
        #required
        return {'frontend_label': [{
                'store_id': 0,
                'label': record.frontend_label,
            }]}


# Attribute option
class AttributeOption(models.Model):
    _inherit = 'attribute.option'

    
    magento_bind_ids=fields.One2many('magento.attribute.option',
                                     'openerp_id',
                                     string='Magento Bindings')
    is_default=fields.Boolean(string='Is default',default=False)
    system_option=fields.Boolean(string='System Option',default=False)
    
    @api.model
    def create(self,vals):
        if not self._context:
            self._context = {}
        attribute_option=super(AttributeOption, self).create(vals)
        id = attribute_option.id
        option = self.browse(id)
        if option.attribute_id:
            for backend in option.attribute_id.magento_bind_ids:
                check = self.env['magento.attribute.option'].search([('openerp_id','=',id),
                                                                     ('attribute_id', '=', backend.id),
                                                                     ('backend_id', '=',backend.backend_id.id)])
                if not check:
                    self.env['magento.attribute.option'].create({'openerp_id': id,
                                                                 'attribute_id': backend.id,
                                                                 'backend_id': backend.backend_id.id,
                                                                 'name': option.name,
                                                                 'is_default': option.is_default,
                                                                 'system_option': option.system_option})

        return attribute_option
    
    @api.multi
    def unlink(self):
        for option in self:
            if not option.system_option:
                for magento_option in option.magento_bind_ids:
                #self.env['magento.attribute.option'].unlink(cr, uid, magento_option.id)
                    magento_option.unlink()
            else:
                raise Warning('You can not delete default Magento Attribute option')
        return super(AttributeOption, self).unlink()

    @api.multi
    def write(self,vals):
        for option in self:
            if not option.system_option:
                for magento_option in option.magento_bind_ids:
                    check_default = vals.get('is_default',None)
                    if vals.get('name') or check_default is not None:
                        name = vals.get('name', option.name)
                        if check_default is not None:
                            is_default = vals.get('is_default')
                        else:
                            is_default = option.is_default
#                         self.env['magento.attribute.option'].write(cr, uid, magento_option.id,
#                                                                     {'name': name, 'is_default': is_default})
                        magento_option.write({'name': name, 'is_default': is_default})
            else:
                raise Warning('You can not update default Magento Attribute option')
        return super(AttributeOption, self).write(vals)

    


class MagentoAttributeOption(models.Model):
    _name = 'magento.attribute.option'
    _description = ""
    _inherit = 'magento.binding'

    
    openerp_id=fields.Many2one('attribute.option',
                               string='Attribute option',                               
                               ondelete='cascade')
    name=fields.Char(string='Name',
                     size=64,
                     required=True)
    is_default=fields.Boolean(string='Is default',default=True)
    attribute_id=fields.Many2one('magento.product.attribute',
                                 string='Product Attribute',
                                 ondelete='cascade')
    magento_id=fields.Char(string='ID on Magento', size=255)
    system_option=fields.Boolean(string='System Option',default=False)


    _sql_constraints = [
        ('magento_uniq', 'unique(backend_id, magento_id,attribute_id)',
         'An attribute option with the same ID on Magento already exists.'),
        ('openerp_uniq', 'unique(backend_id, openerp_id)',
         'An attribute option can not be bound to several records on the same backend.'),
    ]
    
    @api.multi
    def unlink(self):
        if not self.env.context.get('connector_no_export',False):
            for option in self:
                if option.system_option:
                    raise Warning('You can not delete default Magento Attribute option')
                
        return super(MagentoAttributeOption, self).unlink()

    @api.multi
    def write(self,vals):
        if not self.env.context.get('connector_no_export',False):
            for option in self:
                if option.system_option:
                    raise Warning('You can not update default Magento Attribute option')
                
        return super(MagentoAttributeOption, self).write(vals)


@magento
class AttributeOptionAdapter(GenericAdapter):
    _model_name = 'magento.attribute.option'
    _magento_model = 'oerp_product_attribute'

    def create(self, data):
        return self._call('ol_catalog_product_attribute.addOption',
                          [data.pop('attribute'), data])
    #added by krishna
    def write(self, id, data):
        """ Update records on the external system """
        #self._call('catalog_product_attribute.addOption',
        #                  [data.pop('attribute'), data])
        try:
            id = int(id)
        except ValueError:
            pass
        return self._call('ol_catalog_product_attribute.updateOption',
                          [data.pop('attribute'), id, data])

#     def delete(self, id, attribute_id):
#         """ Delete a record on the external system """
#         try:
#             id = int(id)
#         except ValueError:
#             pass
#         return self._call('ol_catalog_product_attribute.removeOption', [int(attribute_id), id])
    def delete(self, vals):
        """ Delete a record on the external system """
        option_id = vals.get('option_id','')
        attribute_id=vals.get('attribute_id','')
        return self._call('ol_catalog_product_attribute.removeOption', [int(attribute_id), option_id])

    def read(self, id, attribute_id=None):
        """ Returns the information of a record

        :rtype: dict
        """
        try:
            id = int(id)
        except ValueError:
            pass

        return self._call('ol_catalog_product_attribute.infoOption' % self._magento_model,
                          [int(attribute_id), id])
    #over

@magento
class AttributeOptionDeleteSynchronizer(MagentoDeleteSynchronizer):
    _model_name = ['magento.attribute.option']
    #added by krishna
    def run(self,vals):
        self.backend_adapter.delete(vals)
        return _('Record %s deleted on Magento') % vals.get('option_id','')

@magento
class AttributeOptionExport(MagentoExporter):
    _model_name = ['magento.attribute.option']
    
    def _should_import(self):
        return False
    
@magento
class AttributeOptionExportMapper(ExportMapper):
    _model_name = 'magento.attribute.option'

    direct = []

    @mapping
    def label(self, record):
        storeview_ids = self.session.search(
                'magento.storeview',
                [('backend_id', '=', self.backend_record.id)])
        storeviews = self.session.browse('magento.storeview', storeview_ids)
        label = []
        for storeview in storeviews:
            
#             name = record.openerp_id.read(['name'], context={
#                 'lang': storeview.lang_id.code,
#                 })[0]['name']
            name = record.openerp_id.read(['name'])[0]['name']
            label.append({
                'store_id': [storeview.magento_id],
                'value': name
                })
        return {'label': label}

    @mapping
    def attribute(self, record):
        binder = self.get_binder_for_model('magento.product.attribute')
        magento_attribute_id = binder.to_backend(record.openerp_id.attribute_id.id, wrap=True)
        return {'attribute': magento_attribute_id}

    @mapping
    def order(self, record):
        #TODO FIXME
        return {'order': record.openerp_id.sequence + 1 }

    @mapping
    def is_default(self, record):
        return {'is_default': int(record.is_default)}
