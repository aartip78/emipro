# -*- coding: utf-8 -*-

from openerp.addons.magentoerpconnect.unit.binder import MagentoModelBinder
from openerp import models, fields, api, _
from openerp.addons.magentoerpconnect.backend import magento
from openerp.addons.connector.unit.mapper import mapping,ExportMapper
from openerp.addons.magentoerpconnect.unit.export_synchronizer import MagentoExporter
from openerp.addons.magentoerpconnect.unit.delete_synchronizer import MagentoDeleteSynchronizer
from openerp.addons.magentoerpconnect.unit.backend_adapter import GenericAdapter

@magento(replacing=MagentoModelBinder)
class MagentoGroupBinder(MagentoModelBinder):
    _model_name = [
        'magento.attribute.group',
    ]


class attribute_group(models.Model):
    _inherit = "attribute.group"

    def create(self,vals):
        if vals.get('attribute_ids'):
            for attribute in vals['attribute_ids']:
                if vals.get('attribute_set_id') and attribute[2] and \
                        not attribute[2].get('attribute_set_id'):
                    attribute[2]['attribute_set_id'] = vals['attribute_set_id']
        else:
            vals['attribute_ids'] = []
        return super(attribute_group, self).create(vals)


@magento
class AttributeGroupExportMapper(ExportMapper):
    _model_name = 'magento.attribute.group'

    direct = [
        ('name', 'attribute_group_name'),
        ('sort_order', 'sort_order'),
    ]

    @mapping
    def backend_id(self, record):
        return {'attribute_group_name': record.name, 'backend_id': self.backend_record.id,
                'attribute_set_id': int(record.attribute_set_id.magento_id)}


class Magento_attribute_group(models.Model):
    _name = "magento.attribute.group"
    _inherit = 'magento.binding'
    
    openerp_id=fields.Many2one('attribute.group',
                               string='Attribute option',
                               ondelete='cascade')
    name=fields.Char(string='Name',size=64,required=True)
    sort_order=fields.Integer(string='Sort order')
    attribute_list=fields.Text(string='Atrtibute list')
    attribute_set_id=fields.Many2one('magento.attribute.set', 'Attribute set')

    _sql_constraints = [
        ('magento_uniq', 'unique(backend_id, magento_id)',
         'An attribute option with the same ID on Magento already exists.'),
        ('openerp_uniq', 'unique(backend_id, openerp_id)',
         'An attribute option can not be bound to several records on the same backend.'),
    ]


@magento
class AttributeGroupExportSynchronizer(MagentoExporter):
    _model_name = ['magento.attribute.group']

    def _should_import(self):
        """ Before the export, compare the update date
        in Magento and the last sync date in OpenERP,
        if the former is more recent, schedule an import
        to not miss changes done in Magento.
        """
        return False


@magento
class AttributeGroupDeleteSynchronizer(MagentoDeleteSynchronizer):
    _model_name = ['magento.attribute.group']


@magento
class AttributeGroupAdapter(GenericAdapter):
    _model_name = 'magento.attribute.group'
    _magento_model = 'ol_catalog_product_attribute_group'

    def create(self, data):
        return self._call('ol_catalog_product_attribute_group.create',
                          [data.get('attribute_set_id'), data])

    def write(self, id, data):
        """ Update records on the external system """
        data['attribute_group_id'] = id
        return self._call('ol_catalog_product_attribute_group.update',
                          [data])

    #        self._call('%s.update' % self._magento_model,[id, data])
    def delete(self, id):
        """ Delete a record on the external system """
        return self._call('ol_catalog_product_attribute_group.delete', [id])

    def addAttribute(self, attribute_id, set_id, group_id):
        return self._call('ol_catalog_product_attribute_group.addAttribute', [attribute_id, set_id, group_id])
    
   