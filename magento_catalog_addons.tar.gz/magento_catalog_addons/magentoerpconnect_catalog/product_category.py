# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright 2013
#    Author: Guewen Baconnier - Camptocamp SA
#            Augustin Cisterne-Kaasv - Elico-corp
#            David Béal - Akretion
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api, _
from openerp.addons.connector.unit.mapper import (mapping,
                                                  #changed_by,
                                                  ExportMapper)
from openerp.addons.magentoerpconnect.unit.delete_synchronizer import (
        MagentoDeleteSynchronizer)
from openerp.addons.magentoerpconnect.unit.export_synchronizer import (
    MagentoExporter)
from openerp.addons.magentoerpconnect.backend import magento
from openerp.addons.magentoerpconnect import product_category


class MagentoProductCategory(models.Model):
    _inherit = 'magento.product.category'
    MAGENTO_HELP = "This field is a technical / configuration field for " \
                   "the category on Magento. \nPlease refer to the Magento " \
                   "documentation for details. "

    def get_custom_design(self):
        return [
            ('base/default', 'base default'),
            ('default/modern', 'default modern'),
            ('default/iphone', 'default iphone'),
            ('default/default', 'default default'),
            ('default/blank', 'default blank'),
            ]

    @api.multi
    def _get_custom_design(self):
        return self.get_custom_design()

    @api.multi
    def get_page_layout(self):
        return [
            ('empty', 'Empty'),
            ('one_column', '1 colmun'),
            ('two_columns_left', '2 columns with left bar'),
            ('two_columns_right', '2 columns with right bar'),
            ('three_columns', '3 columns'),
            ]

    @api.multi
    def _get_page_layout(self):
        return self.get_page_layout()

    
    #==== General Information ====
    thumbnail_like_image=fields.Boolean(string='Thumbnail like main image',default=True)
    thumbnail_binary=fields.Binary(string='Thumbnail')
    thumbnail=fields.Char(string='Thumbnail name',size=100, help=MAGENTO_HELP)
    image_binary=fields.Binary(string='Image')
    image=fields.Char(string='Image name', size=100, help=MAGENTO_HELP)
    meta_title=fields.Char(string='Title (Meta)', size=75, help=MAGENTO_HELP)
    meta_keywords=fields.Text(string='Meta Keywords', help=MAGENTO_HELP)
    meta_description=fields.Text(string='Meta Description', help=MAGENTO_HELP)
    url_key=fields.Char(string='URL-key', size=100, readonly="True")
        #==== Display Settings ====
    display_mode=fields.Selection([
                                   ('PRODUCTS', 'Products Only'),
                                   ('PAGE', 'Static Block Only'),
                                   ('PRODUCTS_AND_PAGE', 'Static Block & Products')],
                                  string='Display Mode', required=True, help=MAGENTO_HELP,default='PRODUCTS')
    
    is_anchor=fields.Boolean(string='Anchor?', help=MAGENTO_HELP,default=True)
    use_default_available_sort_by=fields.Boolean(string='Default Config For Available Sort By', help=MAGENTO_HELP,default=True)

   #TODO use custom attribut for category

        #'available_sort_by': fields.sparse(
        #    type='many2many',
        #    relation='magerp.product_category_attribute_options',
        #    string='Available Product Listing (Sort By)',
        #    serialization_field='magerp_fields',
        #    domain="[('attribute_name', '=', 'sort_by'), ('value', '!=','None')]",
        #    help=MAGENTO_HELP),
        #filter_price_range landing_page ?????????????
    default_sort_by=fields.Selection([
                    ('_', 'Config settings'), #?????????????
                    ('position', 'Best Value'),
                    ('name', 'Name'),
                    ('price', 'Price')],
                    string='Default sort by', required=True, help=MAGENTO_HELP,default='_')

        #==== Custom Design ====
    custom_apply_to_products=fields.Boolean(string='Apply to products', help=MAGENTO_HELP)
    custom_design=fields.Selection( _get_custom_design,
                                    string='Custom design',
                                    help=MAGENTO_HELP)
    custom_design_from=fields.Date(string='Active from', help=MAGENTO_HELP)
    custom_design_to=fields.Date(string='Active to', help=MAGENTO_HELP)
    custom_layout_update=fields.Text(string='Layout update', help=MAGENTO_HELP)
    page_layout=fields.Selection(_get_page_layout,string='Page layout', help=MAGENTO_HELP)

    _sql_constraints = [
        ('magento_img_uniq', 'unique(backend_id, image)',
         "'Image file name' already exists : must be unique"),
        ('magento_thumb_uniq', 'unique(backend_id, thumbnail)',
         "'thumbnail name' already exists : must be unique"),
    ]


@magento
class ProductCategoryDeleteSynchronizer(MagentoDeleteSynchronizer):
    """ Product category deleter for Magento """
    _model_name = ['magento.product.category']


@magento
class ProductCategoryExport(MagentoExporter):
    _model_name = ['magento.product.category']
 
    def _export_dependencies(self):
        """Export parent of the category"""
        #TODO FIXME
        env = self.environment
        record = self.binding_record
        binder = self.get_binder_for_model()
        if record.magento_parent_id:
            mag_parent_id = record.magento_parent_id.id
            if binder.to_backend(mag_parent_id) is None:
                exporter = env.get_connector_unit(ProductCategoryExport)
                exporter.run(mag_parent_id)
        elif record.openerp_id.parent_id:
            parent = record.openerp_id.parent_id
            if binder.to_backend(parent.id, wrap=True) is None:
                exporter = env.get_connector_unit(ProductCategoryExport)
                exporter.run(parent.magento_parent_id.id)
        
        return True
    
@magento
class ProductCategoryExportMapper(ExportMapper):
    _model_name = 'magento.product.category'

    direct = [('description', 'description'),
              #change that to mapping top level category has no name
              ('name', 'name'),
              ('meta_title', 'meta_title'),
              ('meta_keywords', 'meta_keywords'),
              ('meta_description', 'meta_description'),
              ('display_mode', 'display_mode'),
              ('is_anchor', 'is_anchor'),
              ('use_default_available_sort_by', 'use_default_available_sort_by'),
              ('custom_design', 'custom_design'),
              ('custom_design_from', 'custom_design_from'),
              ('custom_design_to', 'custom_design_to'),
              ('custom_layout_update', 'custom_layout_update'),
              ('page_layout', 'page_layout'),
             ]

    @mapping
    def sort(self, record):
        return {'default_sort_by':'price', 'available_sort_by': 'price'}

    @mapping
    def parent(self, record):
        """ Magento root category's Id equals 1 """
        if not record.magento_parent_id:
            openerp_parent = record.parent_id
            binder = self.get_binder_for_model('magento.product.category')
            parent_id = binder.to_backend(openerp_parent.id, wrap=True)
        else:
            parent_id = record.magento_parent_id.magento_id
        if not parent_id:
            parent_id = 1
        return {'parent_id':parent_id}

    @mapping
    def image(self, record):
        res = {}
        if record.image_binary:
            res.update({'image': record.image,
                        'image_binary': record.image_binary})
        if record.thumbnail_like_image == True :
            res.update({'thumbnail': record.image,})
        elif record.thumbnail:
            res.update({'thumbnail': record.thumbnail,
                        'thumbnail_binary': record.thumbnail_binary})
        return res

    @mapping
    def country_id(self, record):
        result = {'applicable_countries':0,'spcific_countries':[]}
        if len(record.country_id) > 0:
            result['applicable_countries'] = 1
            result['spcific_countries'] = [x.code for x in record.country_id]
                
        return result


@magento(replacing=product_category.ProductCategoryImportMapper)
class ProductCategoryImportMapper(product_category.ProductCategoryImportMapper):
    _model_name = 'magento.product.category'
    direct = product_category.ProductCategoryImportMapper.direct + []

    @mapping
    def country_id(self, record):
        result = {'country_id':[(6,0,[])]}
        if not record.get('applicable_countries'):
            return result
        if record.get('applicable_countries','0') == '1':
            country_ids = self.session.search('res.country',[('code','in',record.get('spcific_countries',[]))] )
            if country_ids:
                result = {'country_id':[(6,0,country_ids)]}
                
        return result
    #TODO add mapping for default_sort_by and available_sort_by
