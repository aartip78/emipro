# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright 2013
#    Author: Guewen Baconnier - Camptocamp
#            David Béal - Akretion
#            Sébastien Beau - Akretion
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import mimetypes
import logging
import urllib2
import base64
import xmlrpclib
import sys
from collections import defaultdict
from openerp import models, fields, api, _
#from openerp.tools.translate import _
#from openerp.osv.osv import except_osv
from openerp.addons.connector.unit.mapper import (mapping,
                                                  ExportMapper,ImportMapper)
from openerp.addons.magentoerpconnect.unit.binder import MagentoModelBinder
from openerp.addons.magentoerpconnect.unit.delete_synchronizer import (
    MagentoDeleteSynchronizer)
from openerp.addons.magentoerpconnect.unit.export_synchronizer import (
    MagentoExporter)
from openerp.addons.magentoerpconnect.backend import magento
from openerp.addons.magentoerpconnect.product import ProductImportMapper
from openerp.addons.magentoerpconnect.unit.backend_adapter import GenericAdapter
from openerp.addons.connector.unit.synchronizer import (ImportSynchronizer,
                                                        ExportSynchronizer
                                                        )
from openerp.addons.connector.exception import (MappingError,
                                                InvalidDataError,
                                                IDMissingInBackend
                                                )

from  openerp.addons.magentoerpconnect.unit.import_synchronizer import (DelayedBatchImport,
                                       MagentoImportSynchronizer,
                                       TranslationImporter,
                                       AddCheckpoint,
                                       )

MAGENTO_HELP = "This field is a technical / configuration field for " \
               "the attribute on Magento. \nPlease refer to the Magento " \
               "documentation for details. "


@magento(replacing=MagentoModelBinder)
class MagentoImageBinder(MagentoModelBinder):
    _model_name = [
        'magento.product.image',
    ]


class MagentoProductProduct(models.Model):
    _inherit = 'magento.product.product'

    @api.multi
    def _get_images(self):
        res={}
        for prd in self:
            imgs = self.env['magento.product.image'].search([
                    ('product_id', '=', prd.openerp_id.id),
                    ('backend_id', '=', prd.backend_id.id), ])
            img_ids=[x.id for x in imgs]
            res[prd.id] = img_ids
        return res

    @api.multi
    def copy(self, default=None):
        #take care about duplicate on one2many and function fields
        #https://bugs.launchpad.net/openobject-server/+bug/705364
        if default is None:
            default = {}
        default['magento_product_image_ids'] = None
        return super(MagentoProductProduct, self).copy(default=default)
    
    
    magento_product_image_ids=fields.One2many('magento.product.image','magento_product_id',            
                                              string='Magento product images')
    magento_product_storeview_ids=fields.One2many('magento.product.storeview',
                                                  'magento_product_id',
                                                  string='Magento storeview')
    
    @api.multi
    def open_images(self):
        view_id = self.env['ir.model.data'].get_object_reference('magentoerpconnect_catalog',
                                                                 'magento_product_img_form_view')[1]
        return {
            'name': 'Product images',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': view_id,
            'res_model': self._name,
            'context': self._context,
            'type': 'ir.actions.act_window',
            'res_id': self.ids and self.ids[0] or False,
        }


class ProductImage(models.Model):
    _inherit = 'product.image'

    
    magento_bind_ids=fields.One2many('magento.product.image',
                                     'openerp_id',
                                     string='Magento bindings')
  
    

class MagentoProductImage(models.Model):
    _name = 'magento.product.image'
    _description = "Magento product image"
    _inherit = 'magento.binding'
    _inherits = {'product.image': 'openerp_id'}

    
    openerp_id=fields.Many2one('product.image',
                               required=True,
                               ondelete="cascade",
                               string='Image')
    magento_product_id=fields.Many2one('magento.product.product',string="Magento Product Images")
    
    @api.cr_uid_context
    def _get_backend(self,cr,uid,context=None):
        backend_id = False
        backend_m = self.env['magento.backend']
#         back_obj = backend_m.search( [])
#         back_ids=[x.id for x in back_obj]
#         if back_ids:
#             backend_id = backend_m.browse(
#                 cr, uid, back_ids, context=context)[0].id
        back_obj = backend_m.search( [])[0]
        if back_obj:
            backend_id = back_obj.id           
        return backend_id


    _defaults = {
        'backend_id': _get_backend,
    }
    #Removed by krishna to import multiple images of 1 product.
#     _sql_constraints = [
#         ('magento_uniq', 'unique(backend_id, magento_id)',
#          "An image with the same ID on Magento already exists")
#     ]

@magento
class ProductImageDeleteSynchronizer(MagentoDeleteSynchronizer):
    _model_name = ['magento.product.image']


@magento
class ProductImageExport(MagentoExporter):
    _model_name = ['magento.product.image']

    def _should_import(self):
        "Images in magento doesn't retrieve infos on dates"
        return False

# Added by krishna
@magento
class ProductImageImportMapper(ImportMapper):
    _model_name = 'magento.product.image'

    direct = [
            ('label', 'label'),
            ('position', 'sequence'),
            ('url','url'),
            ('file','name'),
                        
        ]
    @mapping
    def link(self, record):        
        return {'link': True}
    
    @mapping
    def backend_id(self, record):
        print self.backend_record.id
        return {'backend_id': self.backend_record.id}
    
#     @mapping
#     def product_id(self, record):
#         binder = self.get_binder_for_model('magento.product.product')
#         binding_id = binder.to_openerp(record['magento_id'],unwrap=True)
#         print binding_id
#         return {'product_id': binding_id} 
    
    
# @magento
# class MagentoImageImporter(ImportSynchronizer):
#     """ Import images for a record.
# 
#     Usually called from importers, in ``_after_import``.
#     For instance from the products importer.
#     """
# 
#     _model_name = ['magento.product.image',
#                    ]
   

 
            
# @magento
# class ProductImport(MagentoImportSynchronizer):
#     _model_name = ['magento.product.product']
# 
#     def _after_import(self, binding_id):
#         """ Hook called at the end of the import """
#         translation_importer = self.get_connector_unit_for_model(
#             TranslationImporter, self.model._name)
#         translation_importer.run(self.magento_id, binding_id,
#                                  mapper_class=ProductImportMapper)
#         image_importer = self.get_connector_unit_for_model(   
#             MagentoImageImporter, self.model._name)# image_importer : <openerp.addons.magentoerpconnect.product.CatalogImageImporter object at 0xac3186c>
#         image_importer.run(self.magento_id, binding_id)

#         if self.magento_record['type_id'] == 'bundle':
#             bundle_importer = self.get_connector_unit_for_model(
#                 BundleImporter, self.model._name)
#             bundle_importer.run(binding_id, self.magento_record)
     
@magento
class ProductImageExportMapper(ExportMapper):
    _model_name = 'magento.product.image'

    direct = [
            ('label', 'label'),
            ('sequence', 'position'),
        ]
 


    @mapping
    def product(self, record):
        binder = self.get_binder_for_model('magento.product.product')
        external_product_id = binder.to_backend(
            record.openerp_id.product_id.id, True)
        return {'product': str(external_product_id)}

    @mapping
    def identifierType(self, record):
        return {'identifierType': 'ID'}

    @mapping
    def types(self, record):
        return {'types': ['image', 'small_image', 'thumbnail']}
    #    return {'types':
    #            [x for x in ['image', 'small_image', 'thumbnail'] if record[x]]
    #           }

    @mapping
    def file(self, record):
        return {'file': {
                'mime': mimetypes.guess_type(record.name + record.extension)[0],
                'name': record.label,
                'content': self.session.pool['image.image'].get_image(
                    self.session.cr, self.session.uid,
                    record.openerp_id.image_id.id,
                    context=self.session.context),
                }
            }


@magento
class ProductImageAdapter(GenericAdapter):
    _model_name = 'magento.product.image'
    _magento_model = 'catalog_product_attribute_media'

    def create(self, data, storeview_id=None):
        #import pdb;pdb.set_trace()
        print data
        return self._call('%s.create' % self._magento_model,
                          [data.pop('product'), data, storeview_id])

    def write(self, id, data):
        """ Update records on the external system
            changes with GenericAdapter : prevent 'int(id)' """
        return self._call('%s.update' % self._magento_model,
                          [data.pop('product'), id, data])

    def delete(self, id):
        """ Delete a record on the external system """
        image_id, external_product_id = id
        return self._call('%s.remove' % self._magento_model,
                          [external_product_id, image_id])
    def search(self, id, storeview_id=None):
        """ Returns the information of a record

        :rtype: dict
        """
        return self._call('product_media.list', [int(id), storeview_id, 'id'])

    def read(self, id, image_name,storeview_id=None):
#         image_name=self.file_name
        return self._call('product_media.info',[int(id), image_name, storeview_id, 'id'])


class MagentoProductStoreview(models.Model):
    _name = 'magento.product.storeview'
    _description = "Magento product storeview"
    _inherits = {'magento.product.product': 'magento_product_id'}

    
    magento_product_id=fields.Many2one('magento.product.product',
                                       required=True,
                                       ondelete="cascade",
                                       string='Image')
    storeview_id=fields.Many2one('magento.storeview',
                                 required=True,
                                 string='Storeview')
    image=fields.Many2one('magento.product.image',
                          string='Base image',
                          help=MAGENTO_HELP)
    small_image=fields.Many2one('magento.product.image',
                                string='Small image',
                                help=MAGENTO_HELP)
    thumbnail=fields.Many2one('magento.product.image',
                              string='Thumbnail',
                              domain="[('backend_id', '=', 'backend_id')]",
                              help=MAGENTO_HELP)
    exclude_ids=fields.Many2many('magento.product.image', 'product_id',
                                 string='Exclude',
                                 help=MAGENTO_HELP)  
    


@magento
class ProductStoreviewExport(MagentoExporter):
    _model_name = ['magento.product.storeview']

#    TODO
#    def _export_dependencies(self):

    def _should_import(self):
        "Images in magento doesn't retrieve infos on dates"
        return False
    #
    #def _run(self, fields=None):
    #    """ Flow of the synchronization, implemented in inherited classes"""
    #    assert self.binding_id
    #    assert self.binding_record
    #
    #
    #    if not self.magento_id:
    #        fields = None  # should be created with all the fields
    #
    #    if self._has_to_skip():
    #        return
    #
    #     export the missing linked resources
    #    self._export_dependencies()
    #
    #    self._map_data(fields=fields)
    #
    #    if self.magento_id:
    #        record = self.mapper.data
    #        if not record:
    #            return _('Nothing to export.')
    #         special check on data before export
    #        self._validate_data(record)
    #        self._update(record)
    #    else:
    #        record = self.mapper.data_for_create
    #        if not record:
    #            return _('Nothing to export.')
    #         special check on data before export
    #        self._validate_data(record)
    #        self.magento_id = self._create(record)
    #    return _('Record exported with ID %s on Magento.') % self.magento_id


@magento
class ProductStoreviewExportMapper(ExportMapper):
    _model_name = 'magento.product.storeview'

    direct = [
        ('label', 'label'),
        ('sequence', 'position'), ]

    @mapping
    def product(self, record):
        return {'product': ''}


#
#@magento
#class ProductStoreviewAdapter(GenericAdapter):
#    _model_name = 'magento.product.storeview'
#
#    def update_image(self, product_id, data, storeview_id=None):
#        #data = {'small', image_id, 'medium':image_id,...}
#
#        return self._call('catalog_product_attribute_media.update',
#            [product_id, image_id, data, storeview_id])
#



#
#@job
#def export_record(session, model_name, binding_id, fields=None):
#    """ Export a record on Magento """
#    record = session.browse(model_name, binding_id)
#    env = get_environment(session, model_name, record.backend_id.id)
#    exporter = env.get_connector_unit(MagentoExporter)
#    return exporter.run(binding_id, fields=fields)
