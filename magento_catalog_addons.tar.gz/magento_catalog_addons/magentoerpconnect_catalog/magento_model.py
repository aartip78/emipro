# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright 2013
#    Author: Guewen Baconnier - Camptocamp
#            David Béal - Akretion
#            Sébastien Beau - Akretion
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging
from openerp import models, fields, api, _
from openerp.addons.magentoerpconnect.backend import magento
from openerp.addons.connector.unit.mapper import mapping,ImportMapper
from openerp.addons.connector.session import ConnectorSession
from openerp.addons.magentoerpconnect.unit.import_synchronizer import import_batch
from datetime import datetime
from openerp.tools import DEFAULT_SERVER_DATETIME_FORMAT
_logger = logging.getLogger(__name__)


class magento_backend(models.Model):
    _inherit = 'magento.backend'

    @api.multi
    def import_attribute_sets(self):
        if not hasattr(self.ids, '__iter__'):
            ids = [self.ids]
        self.check_magento_structure()
        session = ConnectorSession(self.env.cr,self.env.uid,self.env.context)
        for backend_id in self.ids:
            import_batch.delay(session, 'magento.attribute.set', backend_id)
        return True

    
    attribute_set_tpl_id=fields.Many2one('magento.attribute.set',
                                         string='Attribute set template',
                                         help="Attribute set ID basing on which the new attribute set "
                                         "will be created.")
    import_attributes_from_date=fields.Datetime(string='Import Attributes from date')
    import_attribute_sets_from_date=fields.Datetime(string='Import Attribute Sets from date')  

    @api.multi
    def import_attributes(self):
#         if not ids:
#             ids = self.search(cr,uid,[])
#         if not hasattr(ids, '__iter__'):
#             ids = [ids]
        import_start_time = datetime.now().strftime(DEFAULT_SERVER_DATETIME_FORMAT)
        self.check_magento_structure()
        session = ConnectorSession(self.env.cr, self.env.uid,self.env.context)
        for backend in self:
            from_date = backend.import_attributes_from_date or False
            if from_date:
                from_date = datetime.strptime(from_date,DEFAULT_SERVER_DATETIME_FORMAT)
            else:
                from_date = None            
            import_batch.delay(session, 'magento.product.attribute', backend.id,filters=[ from_date and from_date.strftime(DEFAULT_SERVER_DATETIME_FORMAT) or ''])
            backend.write({'import_attributes_from_date' : import_start_time})
            
        return True  
