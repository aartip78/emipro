# -*- coding: utf-8 -*-
##############################################################################
#
#    Copyright 2013
#    Author: Guewen Baconnier - Camptocamp SA
#            Augustin Cisterne-Kaasv - Elico-corp
#            David Béal - Akretion
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp import models, fields, api, _
from openerp.addons.connector.queue.job import job
from openerp.addons.connector.unit.mapper import (mapping,
                                                  changed_by,
                                                  ExportMapper,ImportMapper)
from openerp.addons.magentoerpconnect.unit.delete_synchronizer import (
        MagentoDeleteSynchronizer)
from openerp.addons.connector.exception import IDMissingInBackend
# from openerp.addons.magentoerpconnect.unit.export_synchronizer import (
#         MagentoTranslationExporter)
from openerp.addons.magentoerpconnect.backend import magento
from openerp.addons.magentoerpconnect.product import ProductProductAdapter,ProductImport,ProductImportMapper
from openerp.addons.connector.exception import MappingError
from openerp.addons.magentoerpconnect.unit.export_synchronizer import (
    export_record
)
from openerp.addons.magentoerpconnect.unit.export_synchronizer import MagentoExporter,MagentoBaseExporter
from openerp.addons.connector.unit.synchronizer import (ImportSynchronizer,
                                                        ExportSynchronizer
                                                        )
from openerp.addons.connector.exception import (MappingError,
                                                InvalidDataError,
                                                IDMissingInBackend
                                                )
from openerp.addons.magentoerpconnect.unit.import_synchronizer import (DelayedBatchImport,
                                       MagentoImportSynchronizer,
                                       TranslationImporter,
                                       AddCheckpoint,
                                       )

@magento
class ProductProductDeleteSynchronizer(MagentoDeleteSynchronizer):
    """ Partner deleter for Magento """
    _model_name = ['magento.product.product']


# @magento
# class ProductProductExport(MagentoTranslationExporter):
#     _model_name = ['magento.product.product']
# 
#     def _export_dependencies(self):
#         """ Export the dependencies for the product"""
#         #TODO add export of category
#         attribute_binder = self.get_binder_for_model('magento.product.attribute')
#         option_binder = self.get_binder_for_model('magento.attribute.option')
#         record = self.binding_record
#         for group in record.attribute_group_ids:
#             for attribute in group.attribute_ids:
#                 attribute_ext_id = attribute_binder.to_backend(attribute.attribute_id.id, wrap=True)
#                 if attribute_ext_id:
#                     options = []
#                     if attribute.ttype == 'many2one' and record[attribute.name]:
#                         options = [record[attribute.name]]
#                     elif attribute.ttype == 'many2many':
#                         options = record[attribute.name]
#                     for option in options:
#                         if not option_binder.to_backend(option.id, wrap=True):
#                             ctx = self.session.context.copy()
#                             ctx['connector_no_export'] = True
#                             binding_id = self.session.pool['magento.attribute.option'].create(
#                                                     self.session.cr, self.session.uid,{
#                                                     'backend_id': self.backend_record.id,
#                                                     'openerp_id': option.id,
#                                                     'name': option.name,
#                                                     }, context=ctx)
#                             export_record(self.session, 'magento.attribute.option', binding_id)

@magento
class ProductExport(MagentoExporter):
    _model_name = 'magento.product.product'
    
    def _create(self, data):
        """ Create the Magento record """
        if  not data.get('sku',False):
            return
        filters = {'sku':data.get('sku','')}
        magento_ids = self.backend_adapter.search(filters=filters)
        if magento_ids:
            res = self.backend_adapter.write(magento_ids[0],data)
            return magento_ids[0]
        else:
            res = self.backend_adapter.create(data) 
        return res
    
@magento
class ProductProductExportMapper(ExportMapper):
    _model_name = 'magento.product.product'

    #TODO FIXME
    direct = [('name', 'name'),
              ('description', 'description'),
              ('weight', 'weight'),
              ('list_price', 'price'),
              ('description_sale', 'short_description'),
              ('default_code', 'sku'),
              ('product_type', 'type'),
              ('created_at', 'created_at'),
              ('updated_at', 'updated_at'),
              ('product_type', 'product_type')
              ]
    @mapping
    def all(self, record):
        return {'name': record.name,
                'sku': record.default_code,
                'description': record.description,
                'weight': record.weight,
                'price': record.list_price,
                'short_description': record.description_sale,
                'type': record.product_type,
                'created_at': record.created_at,
                'updated_at': record.updated_at,
                #'status': record.status,
                #'visibility': record.visibility,
                'product_type': record.product_type }

    @mapping
    def sku(self, record):
        sku = record.default_code
        if not sku:
            raise MappingError("The product attribute default code cannot be empty.")
        return {'sku': sku}
    
    #added by krishna
    
#     @mapping
#     def all_attributes(self, record):
#         result={}
#         for key in record.keys():            
#             result[key] = record[key]     
#             
#         return self._after_mapping(result)
    @mapping
    def attribute_set(self, record):
        binder = self.get_binder_for_model('magento.attribute.set')
        binding_id = binder.to_backend(record.attribute_set_id.id, wrap=True)
        return {'attribute_set_id': binding_id}


    @mapping
    def updated_at(self, record):
        updated_at = record.updated_at
        if not updated_at:
            updated_at = '1970-01-01'
        return {'updated_at': updated_at}

    @mapping
    def website_ids(self, record):
        website_ids = []
        for website_id in record.website_ids:
            magento_id = website_id.magento_id
            website_ids.append(magento_id)
        return {'website_ids': website_ids}

    @mapping
    def category(self, record):
        categ_ids = []
        if record.categ_id:
            for m_categ in record.categ_id.magento_bind_ids:
                if m_categ.backend_id.id == self.backend_record.id:
                    categ_ids.append(m_categ.magento_id)

        for categ in record.categ_ids:
            for m_categ in categ.magento_bind_ids:
                if m_categ.backend_id.id == self.backend_record.id:
                    categ_ids.append(m_categ.magento_id)
        return {'categories': categ_ids}

    @mapping
    def get_product_attribute_option(self, record):
        result = {}
        attribute_binder = self.get_binder_for_model('magento.product.attribute')
        option_binder = self.get_binder_for_model('magento.attribute.option')
        for group in record.attribute_group_ids:
            for attribute in group.attribute_ids:
                magento_attribute = None
                #TODO maybe adding a get_bind function can be better
                for bind in attribute.magento_bind_ids:
                    if bind.backend_id.id == self.backend_record.id:
                        magento_attribute = bind

                if not magento_attribute:
                    continue

                if attribute.ttype == 'many2one':
                    option = record[attribute.name]
                    if option:
                        result[magento_attribute.attribute_code] = \
                            option_binder.to_backend(option.id, wrap=True)
                    else:
                        continue
                elif attribute.ttype == 'many2many':
                    options = record[attribute.name]
                    if options:
                        result[magento_attribute.attribute_code] = \
                            [option_binder.to_backend(option.id, wrap=True) for option in options]
                    else:
                        continue
                else:
                    #TODO add support of lang
                    result[magento_attribute.attribute_code] = record[attribute.name]
        return result

    def finalize(self, map_record, values):
        # Here Needs to map all fields which will not take data from attribute struture. like mapped sku with default_code etc..
        
        record=map_record.source
        values.update({'sku':record.default_code})
        categ_ids = []
        if record.categ_id:
            for m_categ in record.categ_id.magento_bind_ids:
                if m_categ.backend_id.id == self.backend_record.id:
                    categ_ids.append(m_categ.magento_id)

        for categ in record.categ_ids:
            for m_categ in categ.magento_bind_ids:
                if m_categ.backend_id.id == self.backend_record.id:
                    categ_ids.append(m_categ.magento_id)        
        values.update({'categories':categ_ids})
        website_ids = []
        for website_id in record.website_ids:
            magento_id = website_id.magento_id
            website_ids.append(magento_id)
        updated_at = record.updated_at
        if not updated_at:
            updated_at = '1970-01-01'
        binder = self.get_binder_for_model('magento.attribute.set')
        attributeset_binding_id = binder.to_backend(record.attribute_set_id.id, wrap=True)
        values.update({'name': record.name,                
                'description': record.description and record.description or values.get('description',''),
                'weight': record.weight or values.get('weight'),
                'price': record.list_price and record.list_price or values.get('price',0.0),
                'short_description': record.description_sale and record.description_sale or values.get('short_description'),
                'type': record.product_type,
                'created_at': record.created_at,         
                'product_type': record.product_type ,
                'website_ids':website_ids,
                'updated_at': updated_at,                
                'attribute_set_id':attributeset_binding_id,
                'drop_ship':False, #record.drop_ship or False,
                'back_order':False, #record.back_order or False,
                'back_order_despatch_msg': '', #record.back_order_item_despatch_msg or '',
                'procure_order_despatch_msg': '',#record.back_order_item_despatch_msg or '',
                'supplier_lead_time':'0',#record.supplier_lead_time_id or '0',
                'procure_lead_time':'0',#record.procure_item_lead_time_id or '0',
                })

        return values
    
@magento
class MagentoImageImporter(MagentoImportSynchronizer):
    """ Import images for a record.

    Usually called from importers, in ``_after_import``.
    For instance from the products importer.
    """

    _model_name = ['magento.product.image',
                   ]
    # added by krishna , To every time create image of product in ERP, No updation .
    def _get_binding_id(self):
        """Return the binding id from the magento id"""
        return False
    
    def _get_magento_data(self):
        """ Return the raw Magento data for ``self.magento_id`` """
        return self.backend_adapter.read(self.magento_id,self.file_name)

#     def run(self, magento_id, binding_id):
#         return True
    def run(self, magento_id, file_name=False,force=False):
        """ Run the synchronization

        :param magento_id: identifier of the record on Magento
        """
        self.magento_id = magento_id # pass this
        self.file_name=file_name
        try:
            self.magento_record = self._get_magento_data()
        except IDMissingInBackend:
            return _('Record does no longer exist in Magento')

        binding_id = self._get_binding_id()

        if not force and self._is_uptodate(binding_id):
            return _('Already up-to-date.')               

        map_record = self._map_data()
        binder = self.get_binder_for_model('magento.product.product')
        openerp_id = binder.to_openerp(self.magento_id,unwrap=True)
        if binding_id:
            record = self._update_data(map_record)           
            record.update({'product_id':openerp_id})            
            self._update(binding_id, record)
        else:
            record = self._create_data(map_record)
            record.update({'product_id':openerp_id})
            binding_id = self._create(record)

        self.binder.bind(self.magento_id, binding_id)

        return binding_id
        
        
@magento(replacing=ProductImport)
class ProductImport(MagentoImportSynchronizer):
    _model_name = ['magento.product.product']

    @property
    def mapper(self):
        if self._mapper is None:
            self._mapper = self.get_connector_unit_for_model(
                ProductImportMapper)
        return self._mapper

    def _import_bundle_dependencies(self):
        """ Import the dependencies for a Bundle """
        bundle = self.magento_record['_bundle_data']
        for option in bundle['options']:
            for selection in option['selections']:
                self._import_dependency(selection['product_id'],
                                  	      'magento.product.product')

    def _import_dependencies(self):
        """ Import the dependencies for the record"""
        record = self.magento_record
        # import related categories
        for mag_category_id in record['categories']:
            self._import_dependency(mag_category_id,
                                    'magento.product.category')
        if record['type_id'] == 'bundle':
            self._import_bundle_dependencies()

    def _validate_product_type(self, data):
        """ Check if the product type is in the selection (so we can
        prevent the `except_orm` and display a better error message).
        """
        sess = self.session
        product_type = data['product_type']
        cr, uid, context = sess.cr, sess.uid, sess.context
        product_obj = sess.pool['magento.product.product']
        types = product_obj.product_type_get(cr, uid, context=context)
        available_types = [typ[0] for typ in types]
        if product_type not in available_types:
            raise InvalidDataError("The product type '%s' is not "
                                   "yet supported in the connector." %
                                   product_type)

    def _must_skip(self):
        """ Hook called right after we read the data from the backend.

        If the method returns a message giving a reason for the
        skipping, the import will be interrupted and the message
        recorded in the job (if the import is called directly by the
        job, not by dependencies).

        If it returns None, the import will continue normally.

        :returns: None | str | unicode
        """
        if self.magento_record['type_id'] == 'configurable':
            return _('The configurable product is not imported in OpenERP, '
                     'because only the simple products are used in the sales '
                     'orders.')

    def _validate_data(self, data):
        """ Check if the values to import are correct

        Pro-actively check before the ``_create`` or
        ``_update`` if some fields are missing or invalid

        Raise `InvalidDataError`
        """
        self._validate_product_type(data)

    def _create(self,data):
        if data.get('default_code',False):
            product_default_code = data.get('default_code','')
            product_ids = self.session.pool['product.product'].search(self.session.cr, self.session.uid,[('default_code', '=',product_default_code)])          
            if product_ids:
                product_obj = self.session.pool['product.product'].browse(self.session.cr, self.session.uid,product_ids)[0]
                if product_obj.magento_bind_ids:
                    res = self._update(product_obj.magento_bind_ids[0],data)
                    return product_obj.magento_bind_ids[0]
                else:
                    vals = self._prepare_magento_binding(product_obj)
                    sess = self.session
                    context = sess.context.copy()
                    context['connector_no_export'] = True
                    binding_id = sess.pool['magento.product.product'].create(sess.cr, sess.uid, vals, context=context)
                    return binding_id
            
        res = super(ProductImport, self)._create(data) 
        return res

    def _after_import(self, binding_id):
        """ Hook called at the end of the import """
#         translation_importer = self.get_connector_unit_for_model(
#             TranslationImporter, self.model._name)
#         translation_importer.run(self.magento_id, binding_id,
#                                  mapper_class=ProductImportMapper)
        image_importer = self.get_connector_unit_for_model(   
            MagentoImageImporter, 'magento.product.image') # image_importer : <openerp.addons.magentoerpconnect.product.CatalogImageImporter object at 0xac3186c>
        all_images = self.backend_adapter.get_images(self.magento_id)
        if all_images:
            for one_image in all_images: 
                image_importer.run(self.magento_id,one_image.get('file',''))
                binder = self.get_binder_for_model('magento.product.product')
                openerp_id = binder.to_openerp(self.magento_id,unwrap=True)
                print openerp_id
#         if self.magento_record['type_id'] == 'bundle':
#             bundle_importer = self.get_connector_unit_for_model(
#                 BundleImporter, self.model._name)
#             bundle_importer.run(binding_id, self.magento_record)
            
    # added by krishna , run of import synchronizer
    def run(self, magento_id, force=False):
        """ Run the synchronization

        :param magento_id: identifier of the record on Magento
        """
        self.magento_id = magento_id
        try:
            self.magento_record = self._get_magento_data()
        except IDMissingInBackend:
            return _('Record does no longer exist in Magento')

        skip = self._must_skip()
        if skip:
            return skip

        binding_id = self._get_binding_id()

        if not force and self._is_uptodate(binding_id):
            return _('Already up-to-date.')
        self._before_import()

        # import the missing linked resources
        self._import_dependencies()

        map_record = self._map_data()
        
        if binding_id:
            record = self._update_data(map_record)
            self._update(binding_id, record)
        else:
            record = self._create_data(map_record)
            binding_id = self._create(record)

        self.binder.bind(self.magento_id, binding_id)

        self._after_import(binding_id)

