# -*- coding: utf-8 -*-
#########################################################################
# Copyright (C) 2009  Sharoon Thomas, Open Labs Business solutions      #
# Copyright (C) 2011 Akretion Sébastien BEAU sebastien.beau@akretion.com#
# Copyright (C) 2013 Akretion Chafique DELLI chafique.delli@akretion.com#
#                                                                       #
#This program is free software: you can redistribute it and/or modify   #
#it under the terms of the GNU General Public License as published by   #
#the Free Software Foundation, either version 3 of the License, or      #
#(at your option) any later version.                                    #
#                                                                       #
#This program is distributed in the hope that it will be useful,        #
#but WITHOUT ANY WARRANTY; without even the implied warranty of         #
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          #
#GNU General Public License for more details.                           #
#                                                                       #
#You should have received a copy of the GNU General Public License      #
#along with this program.  If not, see <http://www.gnu.org/licenses/>.  #
#########################################################################
import base64
import urllib
import os
import re

from openerp.exceptions import Warning
from openerp import models, fields, api
from openerp.tools.translate import _

import logging
_logger = logging.getLogger(__name__)

IMAGE_PER_FOLDER = 500

#TODO find a good solution in order to roll back changed done on file system
#TODO add the possibility to move from a store system to an other
# (example : moving existing image on database to file system)


class image_image(models.Model):
    "Image gallery"
    _name = "image.image"
    _description = __doc__

    @api.multi
    def unlink(self):
        for image in self:
            full_path = self._get_image_full_path(image)
            if full_path:
                os.path.isfile(full_path) and os.remove(full_path)
        return super(image_image, self).unlink()
    
    @api.model
    def create(self,vals):
        if vals.get('name') and not vals.get('extension'):
            vals['name'], vals['extension'] = os.path.splitext(vals['name'])
            vals['name'] = re.sub(r'[?%*:|\"<>]','', vals['name'])
            vals['label'] = vals['name'].replace('_', ' ').capitalize()
        return super(image_image, self).create( vals)

    @api.multi
    def write(self, vals):
        
        if vals.get('name') and not vals.get('extension'):
            vals['name'], vals['extension'] = os.path.splitext(vals['name'])
        
        if vals.get('name') or vals.get('extension'):
            
            for image in self:
                old_full_path = self._get_image_full_path(image)
                if not old_full_path:
                    continue
                # all the stuff below is there to manage
                # the files on the filesystem
                if vals.get('name') and (image.name != vals['name']) \
                        or vals.get('extension') \
                        and (image.extension != vals['extension']):
                    super(image_image, image).write(vals)
#                     upd_ids.remove(image.id)
                    if 'file' in vals:
                        # a new image have been loaded we should
                        # remove the old image
                        # TODO it's look like there is something wrong
                        # with function field in openerp indeed
                        # the preview is always added in the write :(
                        if os.path.isfile(old_full_path):
                            os.remove(old_full_path)
                    else:
                        new_image = self.browse(image.id)
                        new_full_path = self._get_image_full_path(new_image)
                        #we have to rename the image on the file system
                        if os.path.isfile(old_full_path):
                            os.rename(old_full_path, new_full_path)
        return super(image_image, self).write(vals)

    @api.multi
    def _get_image_full_path(self, image):
        if self._use_filesystem():
            base_path = self._get_image_base_path()
            base_index = image.id-image.id%IMAGE_PER_FOLDER
            folder_name = "%s-%s"%(base_index + 1,
                                   base_index + IMAGE_PER_FOLDER)
            full_path = os.path.join(
                    base_path,
                    folder_name,
                    '%s%s' % (image.id, image.extension or ''))
        else:
            full_path = False
        return full_path

    @api.multi
    def _use_filesystem(self):
        if self._get_image_base_path():
            return True
        return False

    @api.multi
    def _get_image_base_path(self):
        config_parameter_obj = self.env['ir.config_parameter']
        path = config_parameter_obj.get_param('image.store_path')
        if path == 'False':
            return False
        return path

    @api.multi
    def get_image(self):
        image = self
        if image.link:
            if image.url:
                (filename, header) = urllib.urlretrieve(image.url)
                with open(filename, 'rb') as f:
                    img = base64.b64encode(f.read())
            else:
                return False
        else:
            full_path = self._get_image_full_path( image)
            if full_path:
                if os.path.exists(full_path):
                    try:
                        with open(full_path, 'rb') as f:
                            img = base64.b64encode(f.read())
                    except Exception, e:
                        _logger.error("Can not open the image %s, error : %s",
                                      full_path, e, exc_info=True)
                        return False
                else:
                    _logger.error("The image %s doesn't exist ", full_path)
                    return False
            else:
                img = image.file_db_store
        return img

    @api.multi
    def _get_image(self):        
        for each in self:
            each.file = each.get_image()
        

    @api.multi
    def _check_filestore(self, image_filestore):
        """check if the filestore is created, if not it create it
        automatically
        """
        try:
            dir_path = os.path.dirname(image_filestore)
            if not os.path.exists(dir_path):
                os.makedirs(dir_path)
        except OSError, e:
            raise Warning('The image filestore can not be created, %s') % (e)
#             raise osv.except_osv(
#                     _('Error'),
#                     _('The image filestore can not be created, %s') % e)
        return True

    @api.multi
    def _save_file(self, path, b64_file):
        """Save a file encoded in base 64"""
        self._check_filestore(path)
        with open(path, 'w') as ofile:
            ofile.write(base64.b64decode(b64_file))
        return True

    @api.multi
    def _set_image(self, name, value, arg):
        image = self.browse(self.id)
        full_path = self._get_image_full_path(image)
        if full_path:
            return self._save_file(full_path, value)
        return self.write({'file_db_store': value})


    name=fields.Char(string='Name',required=True,help="File name")
    label=fields.Char(string='Image label',translate=True,size=64,help="")
    extension=fields.Char(string='File extension',readonly=True,oldname='extention')
    link=fields.Boolean(string='Link?', help="Images can be linked from files on "
                        "your file system or remote (Preferred)",default=False)
    file_db_store=fields.Binary(string='Image stored in database')
#     file=fields.Char(compute=_get_image, fnct_inv=_set_image,type="binary",                        
#                         string="File",filters='*.png,*.jpg,*.gif')
    file=fields.Binary(compute=_get_image, fnct_inv=_set_image,                        
                       string="File",filters='*.png,*.jpg,*.gif')
    url=fields.Char(string='File Location',help="URL")
    comments=fields.Text(string='Comments')


