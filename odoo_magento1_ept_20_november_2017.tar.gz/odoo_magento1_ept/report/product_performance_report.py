from odoo import tools
from odoo import fields,models,api

class product_performance_report(models.Model):
    _name = "magento.product.performance.report"
    _description = "Product Perfomance Statistics"
    _auto = False

    product_id=fields.Many2one('product.product', 'Product', readonly=True)
    product_uom_qty=fields.Float('# of Qty', readonly=True)
    categ_id=fields.Many2one('product.category','Category of Product', readonly=True)
    instance_id=fields.Many2one("magento.backend","Instance",readonly=True)
    storeview_id = fields.Many2one("magento.storeview","Storeview",readonly=True)
    store_id = fields.Many2one("magento.store",
                               string='Store',
                               readonly=True,
                               )
    website_id = fields.Many2one("magento.website",
                                 string='Website',
                                 readonly=True,
                                 )

    _order = 'product_uom_qty desc'
    def _select(self):
        select_str = """
             SELECT min(l.id) as id,
                    l.product_id as product_id,
                    sum(l.product_uom_qty) as product_uom_qty,
                    t.categ_id as categ_id,
                    mb.id as instance_id,
                    mso.store_id,
                    mso.website_id     
        """
        return select_str

    def _from(self):
        from_str = """
                sale_order_line l
                      join sale_order s on (l.order_id=s.id)
                      join magento_sale_order mso on (l.order_id=mso.openerp_id)
                      join magento_backend mb on (mb.id=mso.backend_id)
                      left join product_product p on (l.product_id=p.id)
                      left join product_template t on (p.product_tmpl_id=t.id) 
        """
        return from_str

    def _group_by(self):
        group_by_str = """
            Where s.state = 'done' and t.type='product'
            GROUP BY l.product_id,
                    t.categ_id,
                    mb.id,
                    mso.store_id,
                    mso.website_id              
            ORDER BY product_uom_qty DESC 
            limit 10
        """
        return group_by_str

    @api.model_cr
    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute("""CREATE or REPLACE VIEW %s as (
            %s
            FROM ( %s )
            %s
            )""" % (self._table, self._select(), self._from(), self._group_by()))

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
