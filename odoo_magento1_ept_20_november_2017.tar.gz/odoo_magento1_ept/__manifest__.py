{
    'name': "Odoo Magento 1 Connector",   
    'version': '1.0',
    'category': 'Sales',
    'summary' : 'Integrate & Manage your all  Magento1 operations from Odoo',
    'author': 'Emipro Technologies Pvt. Ltd.',
    'website': 'http://www.emiprotechnologies.com/',
    'maintainer': 'Emipro Technologies Pvt. Ltd.',
    'depends': ['delivery'],
    'data':[
            'security/security.xml',
            'views/logs/model_view.xml',
            'views/logs/queue_data.xml',
            'views/backend/ecommerce_data.xml',
            'views/backend/magento_data.xml',
            'views/backend/magento_model_view.xml',
            'views/backend/magento_menu.xml',
            'wizard/sale_ignore_cancel_view.xml',
            'views/sale/sale_view.xml',
            'security/ir.model.access.csv',
            'security/rules.xml',
            'views/payment_method_view.xml',
            'views/sale/automatic_workflow_data.xml',
            'views/sale/sale_workflow_process_view.xml',
            'views/partner/partner_category_view.xml',
            'views/partner/partner_view.xml',
            'views/delivery_view.xml',
            'views/account/invoice_view.xml',
            'views/product/product_category_view.xml',
            'views/product/product_view.xml',
            'views/stock/stock_view.xml',
            'wizard/process_import_export.xml',
            'views/queue_job_view.xml',
            'report/sale_report_view.xml',
            'report/invoice_report_view.xml',
            'report/product_performance_report_view.xml',
            'views/operations.xml',
            'views/web_templates.xml',
            'wizard/res_config.xml',
            'data/magento_sequence.xml',
            'security/ir.model.access.csv',
            'views/product/product_export/magento_model_view.xml',
            'views/product/product_export/product_attribute_view.xml',
            'views/product/product_export/attribute_set_view.xml',
            'views/product/product_export/attribute_group_view.xml',
            'views/product/product_export/attribute_option_view.xml',
            'views/product/product_export/product_image_view.xml',
            #'wizard/open_product_by_attribute_set.xml',
            'wizard/export_multi_products_view.xml',
            'wizard/job_config.xml',
            
           
            ],
     
    'description': """
This module used to smoothly integrate your Magento2 with Odoo. \n

After installation of this module, there will be a rare need to login into Magento 2 admin panel for managing business operations. \n
  
Our module supports following features related to Magento2. \n

    * Multiple Magento instances together in One Odoo \n
    * Magento instance configurations and setup \n
    * Dashboard to Navigate all Magento Instances \n
    * Import customer groups, customers, product categories, products \n
    * Import attribute set, attribute group, attribute and attribute options \n
    * Import Orders with multi currency, Invoices and deliveries \n
    * Export Products and its Images \n
    * Export attribute set, attribute group, attribute and attribute options \n
    * Export product stock Manually / Automatically \n
    * Export Shipping Details with tracking no. and Invoices \n
    * Log details for every transaction between Odoo and Magento \n
    * Magento instance wise auto schedule Jobs configuration and setup \n
    * Magento website wise payment method and tax configuration \n
    * Automatic process configuration (workflow) \n

====================================================================

For support on this module contact us at info@emiprotechnologies.com \n

To subscribe our support packages visit following link, \n

http://www.emiprotechnologies.com/odoo/support \n 

Visit following link to find our other cool apps to shape your system . \n

https://www.odoo.com/apps/modules?author=Emipro%20Technologies%20Pvt.%20Ltd. \n

For more information about us, visit www.emiprotechnologies.com \n
    """,
    'images': ['static/description/main_screen.jpg'],
    'installable': True,
    'auto_install': False,
    'application' : True,
    'price': 450.00,
    'currency': 'EUR',
    
}
