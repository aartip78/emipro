# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: Guewen Baconnier
#    Copyright 2014 Camptocamp SA
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import models, api, workflow
from odoo.addons.odoo_magento1_ept.models.backend.session import ConnectorSession
from odoo.addons.odoo_magento1_ept.models.backend.event import on_picking_out_done

class StockMove(models.Model):
    _inherit = 'stock.move'

    @api.multi
    def assign_picking(self):
        res = super(StockMove,self).assign_picking()
        sale_obj = self.env['sale.order']
        groups = self.mapped('group_id')
        domain = [('procurement_group_id', 'in', groups.ids)]
        sales = sale_obj.search(domain)
        # If we have several sales orders in one procurement group,
        # we group them in one picking. The possibilities when we have
        # several orders for one picking are:
        # 1. take the workflow of the first sale order
        # 2. do not propagate the workflow at all
        # 3. propagate the workflow if all the workflows are the same
        # The solution 1. is bad, the 3. could be hard to understand and
        # unpredictable. The solution 2. takes no assumption on what is
        # expected.
        if sales and len(sales) == 1:
            workflow = sales.magento_workflow_process_id
            pickings = self.mapped('picking_id')
            pickings.write({'magento_workflow_process_id': workflow.id})
        return res
    
    def   _get_new_picking_values(self):
         
        res= super(StockMove,self)._get_new_picking_values()
#         moves=self.env['stock.move'].search([])
        for move in self:
            sale_order=move.procurement_id.sale_line_id.order_id
            if sale_order.magento_bind_ids:
            
                res.update({'magento_workflow_process_id':sale_order.magento_workflow_process_id.id})
        
        return res    
        
    @api.multi
    def action_done(self):
        fire_event = not self.env.context.get('__no_on_event_out_done')
        if fire_event:
            pickings = self.mapped('picking_id')
            states = {p.id: p.state for p in pickings}
        result = super(StockMove,self).action_done()
        if fire_event:
            session = ConnectorSession(self.env.cr,self.env.uid,
                                       context=self.env.context)
            for picking in pickings:
                if states[picking.id] != 'done' and picking.state == 'done':
                    if picking.picking_type_id.code != 'outgoing':
                        continue
                    # partial pickings are handled in
                    # StockPicking.do_transfer()
                    on_picking_out_done.fire(session,'stock.picking',
                                             picking.id, 'complete')
        return result

