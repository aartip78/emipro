# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: Joël Grand-Guillaume
#    Copyright 2013 Camptocamp SA
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import logging
import xmlrpclib
from odoo import models, fields,api
from odoo.tools.translate import _
from odoo.addons.odoo_magento1_ept.models.logs.job import job, related_action,unwrap_binding
from odoo.addons.odoo_magento1_ept.models.backend.exception import NothingToDoJob
from odoo.addons.odoo_magento1_ept.models.unit.synchronizer import Exporter
from odoo.addons.odoo_magento1_ept.models.backend.exception import IDMissingInBackend
from odoo.addons.odoo_magento1_ept.models.backend.event import on_picking_out_done,on_tracking_number_added,on_record_create
from odoo.addons.odoo_magento1_ept.models.unit.backend_adapter import GenericAdapter
from odoo.addons.odoo_magento1_ept.models.backend.connector import get_environment
from odoo.addons.odoo_magento1_ept.models.backend.backend import magento
from .stock_tracking import export_tracking_number
#from .related_action import unwrap_binding
from odoo.addons.odoo_magento1_ept.models.backend.session import ConnectorSession
from odoo.addons.odoo_magento1_ept.models.api_request import req
from odoo.addons.odoo_magento1_ept.models.search_criteria import create_search_criteria
from odoo.addons.odoo_magento1_ept.python_library.php import Php
_logger = logging.getLogger(__name__)


class MagentoStockPicking(models.Model):
    _name = 'magento.stock.picking'
    _inherit = 'magento.binding'
    _inherits = {'stock.picking': 'openerp_id'}
    _description = 'Magento Delivery Order'

    openerp_id = fields.Many2one(comodel_name='stock.picking',
                                 string='Stock Picking',
                                 required=True,
                                 ondelete='cascade')
    magento_order_id = fields.Many2one(comodel_name='magento.sale.order',
                                       string='Sale Order',
                                       ondelete='set null')
    picking_method = fields.Selection(selection=[('complete', 'Complete'),
                                                 ('partial', 'Partial')],
                                      string='Picking Method',
                                      required=True)


class StockPicking(models.Model):
    _inherit = 'stock.picking'
    
    @api.one
    @api.depends("group_id")
    def calc_magento_picking(self):
        if self.picking_type_id and self.picking_type_id.code=='outgoing' and self.group_id:
            sale_order = self.env['sale.order'].search([('procurement_group_id', '=', self.group_id.id)])
            magento_order=sale_order and self.env['magento.sale.order'].search([('openerp_id','=',sale_order.id)])
            if magento_order:
                self.is_magento_picking=True
            else:
                self.is_magento_picking=False    
     
    @api.multi
    @api.depends('magento_bind_ids')
    def set_magento_picking_count(self):
        for record in self :
            record.magento_stock_picking_count = len(record.magento_bind_ids) 
             
    @api.multi
    def _set_magento_info(self):
        for record in self :
            if record.sale_id.magento_bind_ids :
                record.website_id = record.sale_id.website_id
                record.store_id = record.sale_id.store_id
                record.storeview_id = record.sale_id.storeview_id     
                 
    is_magento_picking = fields.Boolean('Is Magento Picking',compute='calc_magento_picking',store=True)

    magento_bind_ids = fields.One2many(
        comodel_name='magento.stock.picking',
        inverse_name='openerp_id',
        string="Magento Shipment",
    )
    magento_stock_picking_count = fields.Integer(string="Magento Stock Picking count",compute="set_magento_picking_count",store=True)
#     
#     
    magento_workflow_process_id = fields.Many2one(comodel_name='magento.sale.workflow.process',
                                        string='Sale Workflow Process')
#     
#     related_backorder_ids = fields.One2many(
#         comodel_name='stock.picking',
#         inverse_name='backorder_id',
#         string="Related backorders",
#     )
#     
    website_id = fields.Many2one(compute="_set_magento_info",comodel_name="magento.website", store=True,readonly=True,string="Website")
    store_id = fields.Many2one(compute="_set_magento_info", comodel_name="magento.store", store=True,readonly=True,string="Store")
    storeview_id = fields.Many2one(compute="_set_magento_info", comodel_name="magento.storeview", store=True,readonly=True,string="Storeview")
    magento_order_status = fields.Char(related='sale_id.magento_order_status',string="Magento Order Status",readonly=True)
     
    @api.multi
    def write(self, vals):
        res = super(StockPicking, self).write(vals)
        if vals.get('carrier_tracking_ref'):
            session = ConnectorSession(self.env.cr, self.env.uid,
                                       context=self.env.context)
            for record_id in self.ids:
                on_tracking_number_added.fire(session,self._name,record_id)
        return res
 
    @api.multi
    def do_transfer(self):
        # The key in the context avoid the event to be fired in
        # StockMove.action_done(). Allow to handle the partial pickings
        self_context = self.with_context(__no_on_event_out_done=True)
        result = super(StockPicking, self_context).do_transfer()
        session = ConnectorSession(self.env.cr, self.env.uid,
                                   context=self.env.context)
        for picking in self:
            if picking.picking_type_id.code != 'outgoing':
                continue
            method = 'partial'
            on_picking_out_done.fire(session, 'stock.picking',
                                     picking.id, method)
 
        return result
 
     
#     def _create_invoice_from_picking(self, cr, uid, picking, vals,
#                                      context=None):
#         vals['magento_workflow_process_id'] = picking.magento_workflow_process_id.id
#         if picking.magento_workflow_process_id.invoice_date_is_order_date:
#             vals['date_invoice'] = picking.sale_id.date_order
#  
#         _super = super(StockPicking, self)
#         return _super._create_invoice_from_picking(cr, uid, picking, vals,
#                                                    context=context)
    @api.multi
    def validate_picking(self):
        self.force_assign()
        self.do_transfer()
        return True
     
    @api.multi
    def view_magento_stock_picking(self):
        magento_picking_ids = self.mapped('magento_bind_ids')
        xmlid=('odoo_magento1_ept','action_magento_stock_picking')
        action = self.env['ir.actions.act_window'].for_xml_id(*xmlid)
        action['domain']= "[('id','in',%s)]" % magento_picking_ids.ids
        if not magento_picking_ids : 
            return {'type': 'ir.actions.act_window_close'}
        return action
     
    @api.multi
    def get_magento_order_status(self):
        for picking in self:
            if picking.sale_id :
                picking.sale_id.get_magento_order_status()


@magento
class StockPickingAdapter(GenericAdapter):
    _model_name = 'magento.stock.picking'
    _magento_model = 'sales_order_shipment'
    _admin_path = 'sales_shipment/view/shipment_id/{id}'
    
    
    def _call(self, method, arguments):
        try:
            return super(StockPickingAdapter, self)._call(method, arguments)
        except xmlrpclib.Fault as err:
            # this is the error in the Magento API
            # when the shipment does not exist
            if err.faultCode == 100:
                raise IDMissingInBackend
            else:
                raise
    
    
    def create(self, order_id, items, comment, email, include_comment):
        """ Create a record on the external system """
        return self._call('%s.create' % self._magento_model,
                          [order_id, items, comment, email, include_comment])

    def add_tracking_number(self, magento_id, carrier_code,
                            tracking_title, tracking_number):
        """ Add new tracking number.

        :param magento_id: shipment increment id
        :param carrier_code: code of the carrier on Magento
        :param tracking_title: title displayed on Magento for the tracking
        :param tracking_number: tracking number
        """
        return self._call('%s.addTrack' % self._magento_model,
                          [magento_id, carrier_code,
                           tracking_title, tracking_number])

    def get_carriers(self, magento_id):
        """ Get the list of carrier codes allowed for the shipping.

        :param magento_id: order increment id
        :rtype: list
        """
        return self._call('%s.getCarriers' % self._magento_model,
                          [magento_id])
        
   
@magento
class MagentoPickingExporter(Exporter):
    _model_name = ['magento.stock.picking']

    def _get_args(self, picking, lines_info=None):
        if lines_info is None:
            lines_info = {}
        sale_binder = self.binder_for('magento.sale.order')
        magento_sale_id = sale_binder.to_backend(picking.magento_order_id.id)
        mail_notification = self._get_picking_mail_option(picking)
        return (magento_sale_id, lines_info,
                _("Shipping Created"), mail_notification, True)


    def _get_lines_info(self, picking):
        """
        Get the line to export to Magento. In case some lines doesn't have a
        matching on Magento, we ignore them. This allow to add lines manually.

        :param picking: picking is a record of a stock.picking
        :type picking: browse_record
        :return: dict of {magento_product_id: quantity}
        :rtype: dict
        """
        item_qty = {}
        # get product and quantities to ship from the picking
        for line in picking.move_lines:
            sale_line = line.procurement_id.sale_line_id
            if not sale_line.magento_bind_ids:
                continue
            magento_sale_line = next(
                (line for line in sale_line.magento_bind_ids
                 if line.backend_id.id == picking.backend_id.id),
                None
            )
            if not magento_sale_line:
                continue
            item_id = magento_sale_line.magento_id
            item_qty.setdefault(item_id, 0)
            item_qty[item_id] += line.product_qty
        return item_qty


    def _get_picking_mail_option(self, picking):
        """

        :param picking: picking is an instance of a stock.picking browse record
        :type picking: browse_record
        :returns: value of send_picking_done_mail chosen on magento shop
        :rtype: boolean
        """
        magento_shop = picking.sale_id.magento_bind_ids[0].store_id
        return magento_shop.send_picking_done_mail


    def run(self, binding_id):
        """
        Export the picking to Magento
        """
        picking = self.model.browse(binding_id)
        if picking.magento_id:
            return _('Already exported')
        picking_method = picking.picking_method
        if picking_method == 'complete':
            args = self._get_args(picking)
        elif picking_method == 'partial':
            lines_info = self._get_lines_info(picking)
            if not lines_info:
                raise NothingToDoJob(_('Canceled: the delivery order does not '
                                       'contain lines from the original '
                                       'sale order.'))
            args = self._get_args(picking, lines_info)
        else:
            raise ValueError("Wrong value for picking_method, authorized "
                             "values are 'partial' or 'complete', "
                             "found: %s" % picking_method)
        try:
            magento_id = self.backend_adapter.create(*args)
        except xmlrpclib.Fault as err:
            # When the shipping is already created on Magento, it returns:
            # <Fault 102: u"Impossible de faire
            # l\'exp\xe9dition de la commande.">
            if err.faultCode == 102:
                raise NothingToDoJob('Canceled: the delivery order already '
                                     'exists on Magento (fault 102).')
            else:
                raise
        else:
            self.binder.bind(magento_id, binding_id)
            # ensure that we store the external ID
            self.session.commit()


MagentoPickingExport = MagentoPickingExporter  # deprecated


@on_picking_out_done
def picking_out_done(session, model_name, record_id, picking_method):
    """
    Create a ``magento.stock.picking`` record. This record will then
    be exported to Magento.

    :param picking_method: picking_method, can be 'complete' or 'partial'
    :type picking_method: str
    """
    picking = session.env[model_name].browse(record_id)
    sale = picking.sale_id
    if not sale:
        return
    for magento_sale in sale.magento_bind_ids:
        session.env['magento.stock.picking'].create({
            'backend_id': magento_sale.backend_id.id,
            'openerp_id': picking.id,
            'magento_order_id': magento_sale.id,
            'picking_method': picking_method})


@on_record_create(model_names='magento.stock.picking')
def delay_export_picking_out(session, model_name, record_id, vals):
    if session.context.get('connector_no_export',False) :
        return
    binding = session.env[model_name].browse(record_id)
    # tracking number is sent when:
    # * the picking is exported and the tracking number was already
    #   there before the picking was done OR
    # * the tracking number is added after the picking is done
    # We have to keep the initial state of whether we had an
    # tracking number in the job kwargs, because if we read the
    # picking at the time of execution of the job, a tracking could
    # have been added and it would be exported twice.
    with_tracking = bool(binding.carrier_tracking_ref)
    export_picking_done.delay(session, model_name, record_id,
                              with_tracking=with_tracking)


@job(default_channel='root.magento')
@related_action(action=unwrap_binding)
def export_picking_done(session, model_name, record_id, with_tracking=True):
    """ Export a complete or partial delivery order. """
    # with_tracking is True to keep a backward compatibility (jobs that
    # are pending and miss this argument will behave the same, but
    # it should be called with True only if the carrier_tracking_ref
    # is True when the job is created.
    picking = session.env[model_name].browse(record_id)
    backend_id = picking.backend_id.id
    env = get_environment(session, model_name, backend_id)
    picking_exporter = env.get_connector_unit(MagentoPickingExporter)
    res = picking_exporter.run(record_id)
    if picking.openerp_id and picking.openerp_id.sale_id :
        picking.openerp_id.sale_id.get_magento_order_status()
    if with_tracking and picking.carrier_tracking_ref:
        export_tracking_number.delay(session, model_name, record_id)
    return res