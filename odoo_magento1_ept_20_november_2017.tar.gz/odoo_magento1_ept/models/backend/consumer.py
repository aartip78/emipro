# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: Guewen Baconnier
#    Copyright 2013 Camptocamp SA
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from odoo.addons.odoo_magento1_ept.models.backend.connector import Binder
from odoo.addons.odoo_magento1_ept.models.unit.export_synchronizer import export_record
from odoo.addons.odoo_magento1_ept.models.unit.delete_synchronizer import export_delete_record
from odoo.addons.odoo_magento1_ept.models.backend.connector import get_environment
from odoo.addons.odoo_magento1_ept.models.backend.event import (on_record_create,
                                                               on_record_write,
                                                               on_record_unlink
                                                               )


EXCLUDED_FIELDS_WRITING = {
    'product.product': ['magento_bind_ids', 'image_ids'],
    'product.category': ['magento_bind_ids',],
    'magento.product.category': ['magento_bind_ids',],
    'magento.product.product':['magento_product_image_ids','magento_qty'],
}

product_models = ['product.product','product.category']

def exclude_fields_from_synchro(model_name, vals):
    if vals and EXCLUDED_FIELDS_WRITING.get(model_name):
        fields = list(set(vals).difference(EXCLUDED_FIELDS_WRITING.get(model_name)))
        vals =  {key: value for key, value in vals.items() if key in fields}
    return vals
"""
@on_record_write(model_names=[
        'magento.product.category',
        'magento.product.product',
        'magento.product.attribute',
        'magento.attribute.group',
        #'magento.attribute.option',
        'magento.attribute.set',
        'magento.product.image',
    ])
"""

@on_record_create(model_names=[
        'magento.product.category',
        'magento.product.product',
        'magento.product.attribute',
        'magento.attribute.set',
        'magento.attribute.group',
#         'magento.attribute.option',
        'magento.product.image',
    ])
def delay_export(session, model_name, record_id, vals):
    """ Delay a job which export a binding record.

    (A binding record being a ``magento.res.partner``,
    ``magento.product.product``, ...)
    """
    vals = exclude_fields_from_synchro(model_name, vals)
    if vals :
        if session.context.get('connector_no_export'):
            return
        fields = vals.keys()
        if model_name in ['magento.product.product']:
            record = session.env['magento.product.product'].browse(record_id)
            if not record.backend_id.allow_product_export :
                return
        export_record.delay(session, model_name, record_id, fields=fields)
'''
@on_record_write(model_names=[
        'product.product',
        'product.category',
    ])
def delay_export_all_bindings(session, model_name, record_id, vals):
    """ Delay a job which export all the bindings of a record.

    In this case, it is called on records of normal models and will delay
    the export for all the bindings.
    """
    vals = exclude_fields_from_synchro(model_name, vals)
    if vals :
        if session.context.get('connector_no_export'):
            return
        record = session.env[model_name].browse(record_id)
        fields = vals.keys()
        for binding in record.magento_bind_ids:
            if model_name in product_models :
                allow_product_export = binding.backend_id and binding.backend_id.allow_product_export
                if not allow_product_export :
                    return 
            export_record.delay(session, binding._model._name, binding.id,
                                fields=fields)

@on_record_unlink(model_names=[
                               'magento.product.category',
                               'magento.attribute.set',
                               'magento.attribute.group',
        ])
def delay_unlink(session, model_name, record_id):
    """ Delay a job which delete a record on Magento.

    Called on binding records."""
    if session.context.get('connector_no_export'):
            return
    group_records = None
    record = session.env[model_name].browse(record_id)
    if model_name == 'magento.attribute.set' :
        group_records = session.env['magento.attribute.group'].search([('attribute_set_id','=',record.id)])
    env = get_environment(session, model_name, record.backend_id.id)
    binder = env.get_connector_unit(Binder)
    magento_id = binder.to_backend(record_id)
    if magento_id:
        export_delete_record.delay(session, model_name,
                                   record.backend_id.id, magento_id,)
    if group_records :
        group_records.with_context(connector_no_export=True).unlink()
        

@on_record_unlink(model_names=['magento.product.product'])
def delay_product_unlink(session, model_name, record_id):
    record = session.env[model_name].browse(record_id)
    env = get_environment(session, model_name, record.backend_id.id)
    binder = env.get_connector_unit(Binder)
    magento_id = binder.to_backend(record_id)
    if magento_id:
        export_delete_record.delay(session, model_name,
                                   record.backend_id.id, record.openerp_id.default_code)
    

@on_record_unlink(model_names=[        
        'magento.attribute.option',
    ])
def delay_option_unlink(session, model_name, record_id):
    magento_keys = {}
    model = session.pool.get('magento.attribute.option')
    record = model.browse(session.cr, session.uid,record_id, context=session.context)
    env = get_environment(session, 'magento.attribute.option',record.backend_id.id)
    binder = env.get_connector_unit(Binder)
    magento_keys.update({'option_mag_id':binder.to_backend(record_id)})
    magento_keys.update({'attribute_mag_id':record.attribute_id and record.attribute_id.magento_id or ''})
    if magento_keys.get('attribute_mag_id'):
        export_delete_record.delay(session, 'magento.attribute.option',record.backend_id.id, magento_keys)    


@on_record_unlink(model_names=['magento.product.image'])
def delay_image_unlink(session, model_name, record_id):
    record = session.env[model_name].browse(record_id)
    magento_keys = {}
    env = get_environment(session, 'magento.product.image',
                          record.backend_id.id)
    binder = env.get_connector_unit(Binder)
    if not binder.to_backend(record_id) :
        return 
    magento_keys.update({'id':binder.to_backend(record_id)})
    env = get_environment(session, 'magento.product.product',
                          record.backend_id.id)
    product_binder = env.get_connector_unit(Binder)
    if product_binder.to_backend(record.magento_product_id.openerp_id.id,wrap=True):
        magento_keys.update({'sku':record.magento_product_id.openerp_id.default_code})
    if magento_keys:
        export_delete_record.delay(session, 'magento.product.image',
                                   record.backend_id.id, magento_keys)

@on_record_unlink(model_names=['magento.product.attribute'])
def delay_attribute_unlink(session, model_name, record_id):
    if session.context.get('connector_no_export'):
            return
    record = session.env[model_name].browse(record_id)
    env = get_environment(session, model_name, record.backend_id.id)
    binder = env.get_connector_unit(Binder)
    magento_id = binder.to_backend(record_id)
    if magento_id:
        export_delete_record.delay(session, model_name,
                                   record.backend_id.id, record.attribute_code,)
'''