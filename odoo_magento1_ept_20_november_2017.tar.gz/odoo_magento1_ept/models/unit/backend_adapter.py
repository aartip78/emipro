# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: Guewen Baconnier
#    Copyright 2013 Camptocamp SA
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import socket
import logging
import xmlrpclib
import base64
import time
from odoo.addons.odoo_magento1_ept.python_library import magento as magentolib
from odoo.addons.odoo_magento1_ept.models.backend.exception import (NetworkRetryableError,
                                                RetryableJobError)
from odoo.addons.odoo_magento1_ept.models.api_request import req
from odoo.addons.odoo_magento1_ept.models.backend.session import ConnectorSession
from odoo.addons.odoo_magento1_ept.models.search_criteria import create_search_criteria
from odoo.addons.odoo_magento1_ept.models.backend.connector import ConnectorUnit
from odoo.addons.odoo_magento1_ept.python_library.php import Php
from datetime import datetime
import time
_logger = logging.getLogger(__name__)


#Magento 2 date format
MAGENTO_DATETIME_FORMAT ='%Y-%m-%d %H:%M:%S'


recorder = {}


def call_to_key(method, arguments):
    """ Used to 'freeze' the method and arguments of a call to Magento
    so they can be hashable; they will be stored in a dict.

    Used in both the recorder and the tests.
    """
    def freeze(arg):
        if isinstance(arg, dict):
            items = dict((key, freeze(value)) for key, value
                         in arg.iteritems())
            return frozenset(items.iteritems())
        elif isinstance(arg, list):
            return tuple([freeze(item) for item in arg])
        else:
            return arg

    new_args = []
    for arg in arguments:
        new_args.append(freeze(arg))
    return (method, tuple(new_args))


def record(method, arguments, result):
    """ Utility function which can be used to record test data
    during synchronisations. Call it from MagentoCRUDAdapter._call

    Then ``output_recorder`` can be used to write the data recorded
    to a file.
    """
    recorder[call_to_key(method, arguments)] = result


def output_recorder(filename):
    import pprint
    with open(filename, 'w') as f:
        pprint.pprint(recorder, f)
    _logger.debug('recorder written to file %s', filename)


class MagentoLocation(object):

    def __init__(self, location,api_username,api_password,
                 use_custom_api_path=False):
        self._location = location
        self.api_username= api_username
        self.api_password =api_password
        self.use_custom_api_path = use_custom_api_path

        self.use_auth_basic = False
        self.auth_basic_username = None
        self.auth_basic_password = None

    @property
    def location(self):
        location = self._location
        if not self.use_auth_basic:
            return location
        assert self.auth_basic_username and self.auth_basic_password
        replacement = "%s:%s@" % (self.auth_basic_username,
                                  self.auth_basic_password)
        location = location.replace('://', '://' + replacement)
        return location

class BackendAdapter(ConnectorUnit):
    """ Base Backend Adapter for the connectors """

    _model_name = None  # define in sub-classes


class CRUDAdapter(BackendAdapter):
    """ Base External Adapter specialized in the handling
    of records on external systems.

    Subclasses can implement their own implementation for
    the methods.
    """

    _model_name = None

    def search(self, *args, **kwargs):
        """ Search records according to some criterias
        and returns a list of ids """
        raise NotImplementedError

    def read(self, *args, **kwargs):
        """ Returns the information of a record """
        raise NotImplementedError

    def search_read(self, *args, **kwargs):
        """ Search records according to some criterias
        and returns their information"""
        raise NotImplementedError

    def create(self, *args, **kwargs):
        """ Create a record on the external system """
        raise NotImplementedError

    def write(self, *args, **kwargs):
        """ Update records on the external system """
        raise NotImplementedError

    def delete(self, *args, **kwargs):
        """ Delete a record on the external system """
        raise NotImplementedError


class MagentoCRUDAdapter(CRUDAdapter):
    """ External Records Adapter for Magento """

    def __init__(self, connector_env):
        """

        :param connector_env: current environment (backend, session, ...)
        :type connector_env: :class:`connector.connector.ConnectorEnvironment`
        """
        super(MagentoCRUDAdapter,self).__init__(connector_env)
        backend = self.backend_record
        magento = MagentoLocation(
            backend.location,
            backend.api_username,
            backend.api_password,
            use_custom_api_path=backend.use_custom_api_path)
        if backend.use_auth_basic:
            magento.use_auth_basic = True
            magento.auth_basic_username = backend.auth_basic_username
            magento.auth_basic_password = backend.auth_basic_password
        self.magento = magento


    def search(self, filters=None):
        """ Search records according to some criterias
        and returns a list of ids """
        raise NotImplementedError

    def read(self, id, attributes=None):
        """ Returns the information of a record """
        raise NotImplementedError

    def search_read(self, filters=None):
        """ Search records according to some criterias
        and returns their information"""
        raise NotImplementedError

    def create(self, data):
        """ Create a record on the external system """
        raise NotImplementedError

    def write(self, id, data):
        """ Update records on the external system """
        raise NotImplementedError

    def delete(self, id):
        """ Delete a record on the external system """
        raise NotImplementedError

    def get_job(self,job_uuid):
        """
        To Get job record from job_uuid
        """
        session = ConnectorSession(self.env.cr,
                                   self.env.uid,
                                   context=self.env.context)
        from odoo.addons.odoo_magento1_ept.models.logs.job import OpenERPJobStorage
        storage = OpenERPJobStorage(session)
        job = storage.db_record_from_uuid(job_uuid)
        return job
 
    def _prepare_attachment_vals(self,request_name):
        """prepare Dict for attacment for every job"""
        job_uuid = self.env.context.get('job_uuid','')
        job = self.get_job(job_uuid)
        attachment_vals = {}
        model_name = str(self._model_name).replace('.', '_')
        attach_file_name = model_name+'_'+request_name+''+'_request_response_'+time.strftime("%Y_%m_%d_%H%M%S")
        if job :
            attachment_vals = {'res_model':job._name,
                                'res_id':job.id,
                                'name':attach_file_name,
                                'type':'binary',
                                'datas_fname':attach_file_name,
                               
                            }
        return attachment_vals

    
    def _call(self,method,arguments):
        """
            Prepare Attachment Data which contain Request-Reponse content
            and create it when job is run
        
        """
        
        try:
            
            custom_url = self.magento.use_custom_api_path
            _logger.debug("Start calling Magento api %s", method)
            with magentolib.API(self.magento.location,
                                self.magento.api_username,
                                self.magento.api_password,
                                full_url=custom_url) as api:
                # When Magento is installed on PHP 5.4+, the API
                # may return garble data if the arguments contain
                # trailing None.
                if isinstance(arguments, list):
                    while arguments and arguments[-1] is None:
                        arguments.pop()
                start = datetime.now()
                try:
                    result = api.call(method,arguments)
                    backend_id=self.backend_record
                    if backend_id.create_attachment:

                        attach_data=''
                        attch_obj=self.env['ir.attachment']
                        attach_vals = self._prepare_attachment_vals(method)
                        if attach_vals:
                            attach_data += "Result : %s\n\n Method name: %s \n\n Argument : %s \n\n"%(result,method,arguments)
                            attach_vals.update({'datas':base64.b64encode(attach_data)})
                            attch_obj.create(attach_vals)
                except:
                    _logger.error("api.call(%s, %s) failed", method, arguments)
                    raise
                else:
                    _logger.debug("api.call(%s, %s) returned %s in %s seconds",
                                  method, arguments, result,
                                  (datetime.now() - start).seconds)
                # Uncomment to record requests/responses in ``recorder``
                # record(method, arguments, result)
                return result
        except (socket.gaierror, socket.error, socket.timeout) as err:
            raise NetworkRetryableError(
                'A network error caused the failure of the job: '
                '%s' % err)
        except xmlrpclib.ProtocolError as err:
            if err.errcode in [502,   # Bad gateway
                               503,   # Service unavailable
                               504]:  # Gateway timeout
                raise RetryableJobError(
                    'A protocol error caused the failure of the job:\n'
                    'URL: %s\n'
                    'HTTP/HTTPS headers: %s\n'
                    'Error code: %d\n'
                    'Error message: %s\n' %
                    (err.url, err.headers, err.errcode, err.errmsg))
            else:
                raise
    

class GenericAdapter(MagentoCRUDAdapter):

    _model_name = None
    _magento_model = None
    _admin_path = None

    def search(self,filters=None):
        """ Search records according to some criterias
        and returns a list of ids

        :rtype: list
        """
        result=self._call('%s.search' % self._magento_model,
                          [filters] if filters else [{}])
        return result

    def read(self, id, attributes=None):
        """ Returns the information of a record

        :rtype: dict
        """
        arguments = [int(id)]
        if attributes:
            # Avoid to pass Null values in attributes. Workaround for
            # https://bugs.launchpad.net/openerp-connector-magento/+bug/1210775
            # When Magento is installed on PHP 5.4 and the compatibility patch
            # http://magento.com/blog/magento-news/magento-now-supports-php-54
            # is not installed, calling info() with None in attributes
            # would return a wrong result (almost empty list of
            # attributes). The right correction is to install the
            # compatibility patch on Magento.
            arguments.append(attributes)
        return self._call('%s.info' % self._magento_model,
                          arguments)

    def search_read(self, filters=None):
        """ Search records according to some criterias
        and returns their information"""
        return self._call('%s.list' % self._magento_model, [filters])

    def create(self,data):
        """ Create a record on the external system """
        return self._call('%s.create' % self._magento_model, [data])

    def write(self,id,data):
        """ Update records on the external system """
        return self._call('%s.update' % self._magento_model,
                          [int(id),data])

    def delete(self,id):
        """ Delete a record on the external system """
        return self._call('%s.delete' % self._magento_model, [int(id)])

    def admin_url(self,id):
        """ Return the URL in the Magento admin for a record """
        if self._admin_path is None:
            raise ValueError('No admin path is defined for this record')
        backend = self.backend_record
        url = backend.admin_location
        if not url:
            raise ValueError('No admin URL configured on the backend.')
        path = self._admin_path.format(model=self._magento_model,
                                       id=id)
        url = url.rstrip('/')
        path = path.lstrip('/')
        url = '/'.join((url, path))
        return url
