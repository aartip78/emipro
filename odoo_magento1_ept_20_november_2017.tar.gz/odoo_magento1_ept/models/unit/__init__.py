# -*- coding: utf-8 -*-

# ConnectorUnit needs to be registered
import synchronizer
import mapper
import binder
import import_synchronizer
import export_synchronizer
import delete_synchronizer
import backend_adapter
import sale_order_onchange
