# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: Joël Grand-Guillaume, Guewen Baconnier
#    Copyright 2013 Camptocamp SA
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging
import xmlrpclib
from odoo import models, fields, api, _
from odoo.addons.odoo_magento1_ept.models.logs.job import job, related_action
from odoo.addons.odoo_magento1_ept.models.unit.synchronizer import Exporter
from odoo.addons.odoo_magento1_ept.models.backend.event import (on_record_create,
                                                       on_invoice_paid,
                                                      on_invoice_validated)
from odoo.addons.odoo_magento1_ept.models.unit.backend_adapter import GenericAdapter
from odoo.addons.odoo_magento1_ept.models.backend.connector import get_environment
from odoo.addons.odoo_magento1_ept.models.backend.backend import magento
from odoo.addons.odoo_magento1_ept.models.backend.related_action import unwrap_binding
from odoo.addons.odoo_magento1_ept.models.backend.session import ConnectorSession
from odoo.addons.odoo_magento1_ept.models.api_request import req
from odoo.addons.odoo_magento1_ept.models.sale.sale import SaleOrderAdapter
from odoo.addons.odoo_magento1_ept.models.search_criteria import create_search_criteria
import odoo.addons.decimal_precision as dp
from odoo.addons.odoo_magento1_ept.models.backend.exception import (                                                                  
                                                                   FailedJobError,
                                                                   )
from requests.exceptions import HTTPError
_logger = logging.getLogger(__name__)


class MagentoAccountInvoice(models.Model):
    """ Binding Model for the Magento Invoice """
    _name = 'magento.account.invoice'
    _inherit = 'magento.binding'
    _inherits = {'account.invoice': 'openerp_id'}
    _description = 'Magento Invoice'

    openerp_id = fields.Many2one(comodel_name='account.invoice',
                                 string='Invoice',
                                 required=True,
                                 ondelete='cascade')
    magento_order_id = fields.Many2one(comodel_name='magento.sale.order',
                                       string='Magento Sale Order',
                                       ondelete='set null')

    _sql_constraints = [
        ('openerp_uniq', 'unique(backend_id, openerp_id)',
         'A Magento binding for this invoice already exists.'),
    ]


class AccountInvoice(models.Model):
    """ Adds the ``one2many`` relation to the Magento bindings
    (``magento_bind_ids``)
    """
    _inherit = 'account.invoice'
    
    @api.multi
    @api.returns('account.move.line')
    def _get_payment(self):
        self.ensure_one()
        if self.type == "out_invoice" and self.sale_id:
            return self.sale_id.payment_ids
        return self.env['account.move.line'].browse()

    @api.multi
    def _can_be_reconciled(self):
        self.ensure_one()
        payments = self._get_payment()
        if not (payments and self.move_id):
            return False
        # Check currency
        company_currency = self.company_id.currency_id
        for payment in payments:
            currency = payment.currency_id or company_currency
            if currency != self.currency_id:
                return False
        return True

    @api.model
    def _get_sum_invoice_move_line(self, move_lines, invoice_type):
        if invoice_type in ['in_refund', 'out_invoice']:
            line_type = 'debit'
        else:
            line_type = 'credit'
        return self._get_sum_move_line(move_lines, line_type)

    @api.model
    def _get_sum_payment_move_line(self, move_lines, invoice_type):
        if invoice_type in ['in_refund', 'out_invoice']:
            line_type = 'credit'
        else:
            line_type = 'debit'
        return self._get_sum_move_line(move_lines, line_type)

    @api.model
    def _get_sum_move_line(self, move_lines, line_type):
        res = {
            'max_date': False,
            'lines': self.env['account.move.line'].browse(),
            'total_amount': 0,
            'total_amount_currency': 0,
        }
        for move_line in move_lines:
            if move_line[line_type] > 0 and not move_line.reconciled:
                if move_line.date > res['max_date']:
                    res['max_date'] = move_line.date
                res['lines'] += move_line
                res['total_amount'] += move_line[line_type]
                res['total_amount_currency'] += move_line.amount_currency
        return res

    @api.multi
    def _prepare_write_off(self, res_invoice, res_payment):
        self.ensure_one()
        if res_invoice['total_amount'] - res_payment['total_amount'] > 0:
            writeoff_type = 'expense'
        else:
            writeoff_type = 'income'
        writeoff_info = self.company_id.get_write_off_information
        account_id, journal_id = writeoff_info('exchange', writeoff_type)
        max_date = max(res_invoice['max_date'], res_payment['max_date'])
        ctx_vals = {'p_date': max_date}
        period_model = self.env['account.period'].with_context(**ctx_vals)
        period = period_model.find(max_date)[0]
        return {
            'type': 'auto',
            'writeoff_acc_id': account_id,
            'writeoff_period_id': period.id,
            'writeoff_journal_id': journal_id,
            'context_vals': ctx_vals,
        }
   
    @api.multi
    @api.depends('currency_id')
    def is_company_cur_invoice(self):
        for obj in self:
            obj.company_cur_invoice = False
            if obj.currency_id.id == obj.company_id.currency_id.id:
                obj.company_cur_invoice = True
    
    @api.multi
    @api.depends('magento_bind_ids')
    def set_magento_invoice_count(self):
        for record in self :
            record.magento_invoice_count = len(record.magento_bind_ids)
            
    @api.multi
    @api.depends('sale_id')
    def _compute_is_magento_invoice(self):
        for record in self:
            record.is_magento_invoice = False
            if record.sale_id and record.sale_id.magento_bind_ids:
                record.is_magento_invoice = True
        
    company_cur_invoice = fields.Boolean('Is Company Currency Invoice?', compute='is_company_cur_invoice', store=True)
    
    magento_bind_ids = fields.One2many(
        comodel_name='magento.account.invoice',
        inverse_name='openerp_id',
        string='Magento Bindings',
    )
    magento_invoice_count = fields.Integer(string="Magento Invoice count",compute="set_magento_invoice_count",store=True)
    
    magento_workflow_process_id = fields.Many2one(comodel_name='magento.sale.workflow.process',
                                          string='Sale Workflow Process')
    magento_payment_method_id = fields.Many2one(comodel_name='magento.payment.method.ept',string="Magento Payment Method")
    sale_id  = fields.Many2one('sale.order',string="Sale order")
    magento_order_status = fields.Char(related='sale_id.magento_order_status',string="Magento Order Status",readonly=True)
    is_magento_invoice = fields.Boolean(compute='_compute_is_magento_invoice',string="Is Magento Invoice?")
    
    @api.multi
    def action_invoice_paid(self):
        res = super(AccountInvoice, self).action_invoice_paid()
        session = ConnectorSession(self.env.cr, self.env.uid,
                                   context=self.env.context)
        for record_id in self.ids:
            on_invoice_paid.fire(session, self._name, record_id)
        return res

    @api.multi
    def invoice_validate(self):
        res = super(AccountInvoice, self).invoice_validate()
        session = ConnectorSession(self.env.cr, self.env.uid,
                                   context=self.env.context)
        for record_id in self.ids:
            on_invoice_validated.fire(session, self._name, record_id)
        currency_obj = self.pool.get('res.currency')
        for obj in self:
            if obj.sale_id and obj.sale_id.magento_bind_ids and obj.sale_id.is_paid_in_magento :
                amount = obj.move_id.amount
                journal = obj.magento_payment_method_id.journal_id
                if journal.currency_id and journal.currency_id.id != obj.company_currency_id.id :
                    amount =  sum(line.amount_currency for line in obj.move_id.line_ids if line.debit > 0)
                    currency = journal.currency_id
                else :
                    currency = obj.company_currency_id
                                
                vals = {
                        'invoice_ids':[(6,0,[obj.id])],
                        'amount':amount,
                        }
                obj.sale_id.account_payment_id.write(vals)
        return res
    
#     @api.v7
#     def copy_data(self, cr, uid, id, default=None, context=None):
#         default = default or {}
#         default.update({'base_total_amount' : 0.0, })
#         return super(AccountInvoice,self).copy_data(cr, uid, id, default=default, context=context)
    
    @api.multi
    def view_magento_invoice(self):
        magento_invoice_ids = self.mapped('magento_bind_ids')
        xmlid=('odoo_magento1_ept','action_magento_account_invoice')
        action = self.env['ir.actions.act_window'].for_xml_id(*xmlid)
        action['domain']= "[('id','in',%s)]" % magento_invoice_ids.ids
        if not magento_invoice_ids : 
            return {'type': 'ir.actions.act_window_close'}
        return action
    
    @api.multi
    def get_magento_order_status(self):
        for invoice in self:
            if invoice.sale_id :
                invoice.sale_id.get_magento_order_status()
                
@magento
class AccountInvoiceAdapter(GenericAdapter):
    """ Backend Adapter for the Magento Invoice """
    _model_name = 'magento.account.invoice'
    _magento_model = 'sales_order_invoice'
    _admin_path = 'sales_invoice/view/invoice_id/{id}'
    _path = "/V1/invoices"
    
    
    def _call(self, method, arguments):
        try:
            return super(AccountInvoiceAdapter, self)._call(method, arguments)
        except xmlrpclib.Fault as err:
            # this is the error in the Magento API
            # when the invoice does not exist
            if err.faultCode == 100:
                raise IDMissingInBackend
            else:
                raise

    def create(self, order_increment_id, items, comment, email,
               include_comment):
        """ Create a record on the external system """
        record= self._call('%s.create' % self._magento_model,
                          [order_increment_id,items,comment,
                           email,include_comment])
        return record
    
    
    def search_read(self, filters=None, order_id=None):
        """ Search records according to some criterias
        and returns their information

        :param order_id: 'order_id' field of the magento sale order, this
                         is not the same field than 'increment_id'
        """
        if filters is None:
            filters = {}
        if order_id is not None:
            filters['order_id'] = {'eq':order_id}
            
        record=super(AccountInvoiceAdapter,self).search_read(filters=filters)
        return record

@magento
class MagentoInvoiceExporter(Exporter):
    """ Export invoices to Magento """
    _model_name = ['magento.account.invoice']

    def _export_invoice(self, magento_id, lines_info, mail_notification):
        if not lines_info: # invoice without any line for the sale order
            
            return
        return self.backend_adapter.create(magento_id,
                                           lines_info,
                                           _("Invoice Created"),
                                           mail_notification,
                                           False)
        

    def _get_lines_info(self, invoice):
        """
        Get the line to export to Magento. In case some lines doesn't have a
        matching on Magento, we ignore them. This allow to add lines manually.

        :param invoice: invoice is an magento.account.invoice record
        :type invoice: browse_record
        :return: dict of {magento_product_id: quantity}
        :rtype: dict
        """
        item_qty = {}
        # get product and quantities to invoice
        # if no magento id found, do not export it
        order = invoice.magento_order_id
        for line in invoice.invoice_line_ids:
            product = line.product_id
            # find the order line with the same product
            # and get the magento item_id (id of the line)
            # to invoice
            order_line = next((line for line in order.magento_order_line_ids
                               if line.product_id.id == product.id),
                              None)
            if order_line is None:
                continue

            item_id = order_line.magento_id
            item_qty.setdefault(item_id, 0)
            item_qty[item_id] += line.quantity
        return item_qty

    def run(self, binding_id):
        """ Run the job to export the validated/paid invoice """
        invoice = self.model.browse(binding_id)

        magento_order = invoice.magento_order_id
        magento_store = magento_order.store_id
        mail_notification = magento_store.send_invoice_paid_mail
        
        lines_info = self._get_lines_info(invoice)
        magento_id = None
        try:
            magento_id = self._get_existing_invoice(magento_order)
            if not magento_id :
                magento_id = self._export_invoice(magento_order.magento_id,
                                              lines_info,
                                              mail_notification)
        except HTTPError as err:
            # When the invoice is already created on Magento, it returns:
            # status_code = 400 and response 
            # {u'message': u'The order does not allow an invoice to be created.'}
            # We'll search the Magento invoice ID to store it in OpenERP
            response = err.response
            status_code = response.pop('status_code')
            if status_code == 400 and response.get('message','') == 'The order does not allow an invoice to be created.' :
                _logger.debug('The order does not allow an invoice to be created for Magento order %s '%(magento_order.openerp_id.name))
                magento_id = self._get_existing_invoice(magento_order)
                if magento_id is None:
                    # In that case, we let the exception bubble up so
                    # the user is informed of the 102 error.
                    # We couldn't find the invoice supposedly existing
                    # so an investigation may be necessary.
                    raise
            else:
                raise FailedJobError('Invoice Export job failed with status %s : %s'%(status_code,response))
        # When the invoice already exists on Magento, it may return
        # a 102 error (handled above) or return silently without ID
        if not magento_id:
            # If Magento returned no ID, try to find the Magento
            # invoice, but if we don't find it, let consider the job
            # as done, because Magento did not raised an error
            magento_id = self._get_existing_invoice(magento_order)

        if magento_id:
            self.binder.bind(magento_id, binding_id)

    def _get_existing_invoice(self,magento_order):
        
        sale_adapter=self.unit_for(SaleOrderAdapter,'magento.sale.order')
        invoices =sale_adapter.get_invoice_ids(magento_order.magento_id)

        print "invoices",invoices
        
        if not invoices:
            return
        if len(invoices) > 1:
            return
        return invoices[0]


MagentoInvoiceSynchronizer = MagentoInvoiceExporter  # deprecated


@on_invoice_validated
@on_invoice_paid
def invoice_create_bindings(session, model_name, record_id):
    """
    Create a ``magento.account.invoice`` record. This record will then
    be exported to Magento.
    """
    invoice = session.env[model_name].browse(record_id)
    # find the magento store to retrieve the backend
    # we use the shop as many sale orders can be related to an invoice
    for sale in invoice.sale_id:
        for magento_sale in sale.magento_bind_ids:
            binding_exists = False
            for mag_inv in invoice.magento_bind_ids:
                if mag_inv.backend_id.id == magento_sale.backend_id.id:
                    binding_exists = True
                    break
            if binding_exists:
                continue
            # Check if invoice state matches configuration setting
            # for when to export an invoice
            magento_store = magento_sale.store_id
            payment_method = sale.payment_method_id
            if payment_method and payment_method.create_invoice_on:
                create_invoice = payment_method.create_invoice_on
            else:
                create_invoice = magento_store.create_invoice_on
            
            if create_invoice != 'na' :
                if create_invoice == invoice.state:
                    session.env['magento.account.invoice'].create({
                                                                   'backend_id': magento_sale.backend_id.id,
                                                                   'openerp_id': invoice.id,
                                                                   'magento_order_id': magento_sale.id})




@on_record_create(model_names='magento.account.invoice')
def delay_export_account_invoice(session, model_name, record_id, vals):
    """
    Delay the job to export the magento invoice.
    """
    export_invoice.delay(session, model_name, record_id)


@job(default_channel='root.magento')
@related_action(action=unwrap_binding)
def export_invoice(session, model_name, record_id):
    """ Export a validated or paid invoice. """
    invoice = session.env[model_name].browse(record_id)
    backend_id = invoice.backend_id.id
    env = get_environment(session, model_name, backend_id)
    invoice_exporter = env.get_connector_unit(MagentoInvoiceExporter)
    return invoice_exporter.run(record_id)