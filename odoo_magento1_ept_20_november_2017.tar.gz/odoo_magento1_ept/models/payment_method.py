# -*- coding: utf-8 -*-
##############################################################################
#
#   sale_quick_payment for OpenERP
#   Copyright (C) 2011 Akretion Sébastien BEAU <sebastien.beau@akretion.com>
#   Copyright 2013 Camptocamp SA (Guewen Baconnier)
#
#   This program is free software: you can redistribute it and/or modify
#   it under the terms of the GNU Affero General Public License as
#   published by the Free Software Foundation, either version 3 of the
#   License, or (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU Affero General Public License for more details.
#
#   You should have received a copy of the GNU Affero General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
from odoo import models, api, fields


class MagentoPaymentMethod(models.Model):
    _name = "magento.payment.method.ept"
    _description = "Magento Payment Method"
    _inherit = ['mail.thread']

    @api.model
    @api.returns('res.company')
    def _default_company_id(self):
        return self.env['res.company']._company_default_get('magento.payment.method.ept')
    
    @api.model
    def _get_import_rules(self):
        return [('always', 'Always'),
                ('never', 'Never'),
                ('paid', 'Paid'),
                ('authorized', 'Authorized'),
                ]

    name = fields.Char(required=True,
                       help="The name of the method on the backend")
    journal_id = fields.Many2one(
        comodel_name='account.journal',
        copy=False,
        string='Journal',
        help="If a journal is selected, when a payment is recorded "
             "on a backend, payment entries will be created in this "
             "journal.",
    )
    invoice_journal_id=fields.Many2one('account.journal',string='journal')
    payment_term_id = fields.Many2one(
        comodel_name='account.payment.term',
        string='Payment Term',
        help="Default payment term of a sale order using this method.",
    )
    company_id = fields.Many2one(
        comodel_name='res.company',
        string='Company',
        default=_default_company_id,
    )

    magento_workflow_process_id = fields.Many2one(comodel_name='magento.sale.workflow.process',
                                          string='Automatic Workflow')
    create_invoice_on = fields.Selection(
        selection=[('open', 'Validate'),
                   ('paid', 'Paid'),
                   ('na','N/A')],
        string='Create Invoice on action',
        default="na",
        help="Should the invoice be created in Magento "
             "when it is validated or when it is paid in OpenERP?\n"
             "If nothing is set, the option falls back to the same option "
             "on the Magento store related to the sales order.",
    )
    website_id = fields.Many2one(
                                 comodel_name='magento.website',
                                 string='Website',
                                 copy=False,
                                 )
    
    days_before_cancel = fields.Integer(
        string='Days before cancel',
        default=30,
        help="After 'n' days, if the 'Import Rule' is not fulfilled, the "
             "import of the sales order will be canceled.",
    )
    import_rule = fields.Selection(selection='_get_import_rules',
                                   string="Import Rule",
                                   default='always',
                                   required=True)
    
    register_payment = fields.Selection(selection=[('advance_payment','Advance Payment'),
                                                   ('invoice_payment','Payment Against Invoice')],
                                        string="Register Payment As",
                                        default = 'invoice_payment'
                                        )

    
    _sql_constraints = [
                ('unique_website_payment_method', 'unique(name, website_id)',
                 'There is already record exists for same magento website and payment method.')
            ]
    
    
    @api.model
    def get_or_create_payment_method(self, payment_method):
        """ Try to get a payment method or create if it doesn't exist

        :param payment_method: payment method like PayPal, etc.
        :type payment_method: str
        :return: required payment method
        :rtype: recordset
        """
        domain = [('name', '=ilike', payment_method)]
        method = self.search(domain, limit=1)
        if not method:
            method = self.create({'name': payment_method})
        return method