from odoo import models,fields,api
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
import time
import ast

class magento_operations_ept(models.Model):
    _name="magento.operations.ept"
    _order = "sequence,id"
    
    @api.model
    def find_magento_cron(self,action_id):
        
        cron_ids = []
        backends = self.env['magento.backend'].search([])
        for backend in backends :
            import_order_cron = self.env.ref('odoo_magento1_ept.ir_cron_import_sale_orders_backend_%s'%backend.id,raise_if_not_found=False)
            import_customer_group_cron = self.env.ref('odoo_magento1_ept.ir_cron_import_customer_groups_backend_%s'%backend.id,raise_if_not_found=False)
            import_customer_cron = self.env.ref('odoo_magento1_ept.ir_cron_import_customers_backend_%s'%backend.id,raise_if_not_found=False)
            import_category_cron = self.env.ref('odoo_magento1_ept.ir_cron_import_product_categories_backend_%s'%backend.id,raise_if_not_found=False)
            import_product_cron = self.env.ref('odoo_magento1_ept.ir_cron_import_products_backend_%s'%backend.id,raise_if_not_found=False)
            export_stock_cron = self.env.ref('odoo_magento1_ept.ir_cron_update_product_stock_qty_backend_%s'%backend.id,raise_if_not_found=False)
            if import_order_cron:
                cron_ids.append(import_order_cron.id)
            if import_customer_group_cron:
                cron_ids.append(import_customer_group_cron.id)
            if export_stock_cron:
                cron_ids.append(export_stock_cron.id)
            if import_customer_cron:
                cron_ids.append(import_customer_cron.id)
            if import_category_cron:
                cron_ids.append(import_category_cron.id)
            if import_product_cron:
                cron_ids.append(import_product_cron.id)        
        return cron_ids
            
    @api.one
    def _count_operations(self):
        if self.action_id and self.display_record_count:
            domain =[]
            if self.action_id.res_model == 'ir.cron':
                cron_ids = self.find_magento_cron(self.action_id)
                self.count_record = len(cron_ids) or 0  
            else:    
                if self.action_id.domain:
                    domain = eval(self.action_id.domain)
                count = self.env[self.action_id.res_model].search_count(domain)
                self.count_record = count or 0
            
    @api.multi
    def count_all(self):
        picking_obj=self.env['stock.picking']
        sale_order_obj=self.env['sale.order']
        invoice_obj=self.env['account.invoice']
        job_obj = self.env['queue.job']
        for record in self:
            if record.use_delivery_orders:
                pickings=picking_obj.search([('is_magento_picking','=',True),('state','=','confirmed')])
                record.count_picking_confirmed=len(pickings.ids)
                pickings=picking_obj.search([('is_magento_picking','=',True),('state','=','assigned')])
                record.count_picking_assigned=len(pickings.ids)
                pickings=picking_obj.search([('is_magento_picking','=',True),('state','=','partially_available')])
                record.count_picking_partial=len(pickings.ids)
                pickings=picking_obj.search([('is_magento_picking','=',True),('state','=','done')])
                record.count_picking_done=len(pickings.ids)
            
                count_picking_late=[('min_date', '<', time.strftime(DEFAULT_SERVER_DATETIME_FORMAT)), ('state', 'in', ('assigned', 'waiting', 'confirmed', 'partially_available')),('is_magento_picking','=',True)]
                count_picking_backorders=[('backorder_id', '!=', False), ('state', 'in', ('confirmed', 'assigned', 'waiting', 'partially_available')),('is_magento_picking','=',True)]
                count_picking=[('state', 'in', ('assigned', 'waiting', 'confirmed', 'partially_available')),('is_magento_picking','=',True)]
                
                count_picking=picking_obj.search(count_picking)
                count_picking_late=picking_obj.search(count_picking_late)
                count_picking_backorders=picking_obj.search(count_picking_backorders)
                
                if count_picking:
                    record.rate_picking_late=len(count_picking_late.ids)*100/len(count_picking.ids)
                    record.rate_picking_backorders=len(count_picking_backorders.ids)*100/len(count_picking.ids)
                else:
                    record.rate_picking_late=0
                    record.rate_picking_backorders=0
                record.count_picking_late=len(count_picking_late.ids)
                record.count_picking_backorders=len(count_picking_backorders.ids)
            
            orders=sale_order_obj.search([('magento_bind_ids.backend_id','in',[record.backend_id.id]),('state','in',['draft','sent','cancel'])])
            record.count_quotations=len(orders.ids)
            if record.use_quotations:
                
                orders=sale_order_obj.search([('magento_bind_ids','!=',False),('state','not in',['draft','sent','cancel'])])
                record.count_orders=len(orders.ids)
            
            if record.use_invoices:
                invoices=invoice_obj.search([('sale_id.magento_bind_ids','!=',False),('state','=','open'),('type','=','out_invoice')])
                record.count_open_invoices = len(invoices.ids)
    
                invoices=invoice_obj.search([('sale_id.magento_bind_ids','!=',False),('state','=','paid'),('type','=','out_invoice')])
                record.count_paid_invoices = len(invoices.ids)
            
            if record.use_job:
                job_pending = job_obj.search([('state','=','pending')])
                record.count_pending_job = len(job_pending)
                job_enqueued = job_obj.search([('state','=','enqueued')])
                record.count_enqueued_job = len(job_enqueued)
                job_started = job_obj.search([('state','=','started')])
                record.count_started_job = len(job_started)    
                job_failed = job_obj.search([('state','=','failed')])
                record.count_failed_job = len(job_failed)
                job_done = job_obj.search([('state','=','done')])
                record.count_done_job = len(job_done)
                
    @api.multi
    @api.depends('backend_id.name')
    def _get_backend_name(self):
        for record in self :
            record.name = record.backend_id and record.backend_id.name or False
                                   
    action_id = fields.Many2one('ir.actions.act_window',string='Action')
    url = fields.Char('Image URL')
    sequence = fields.Integer('Sequence')
    color = fields.Integer('Color')
    name = fields.Char('Name', translate=True, compute="_get_backend_name",store=True)
    backend_id = fields.Many2one('magento.backend',string="Global")
    
    count_record = fields.Integer(compute=_count_operations, string='# Record')
    display_inline_image = fields.Boolean('Display Number of records in Kanban ?')
    display_outline_image = fields.Boolean('Display Number of records in Kanban ?')
    display_record_count = fields.Boolean('Display Number of records in Kanban ?')
    
    use_quotations = fields.Boolean('Quotations', help="Check this box to manage quotations")
    use_products = fields.Boolean("Products",help="Check this box to manage Products")
    use_invoices = fields.Boolean("Invoices",help="Check This box to manage Invoices")
    use_delivery_orders = fields.Boolean("Delivery Orders",help="Check This box to manage Delivery Orders")
    use_log = fields.Boolean("Use Log",help="Check this box to manage Magento Log")
    use_job = fields.Boolean("Use Jobs")
    
    count_pending_job = fields.Integer(string="Count Picking Waiting",compute="count_all")
    count_enqueued_job = fields.Integer(string="Count Picking Waiting",compute="count_all")
    count_started_job = fields.Integer(string="Count Picking Waiting",compute="count_all")
    count_failed_job = fields.Integer(string="Count Picking Waiting",compute="count_all")
    count_done_job = fields.Integer(string="Count Picking Waiting",compute="count_all")
    
    count_quotations = fields.Integer("Count Sales Quotations",compute="count_all")
    count_orders = fields.Integer("Count Sales Orders",compute="count_all")
    
    count_exported_products = fields.Integer("Count Exported Products",compute="count_all")
    count_ready_products = fields.Integer("Count Exported Products",compute="count_all")
    
    count_picking_confirmed = fields.Integer(string="Count Picking Confirmed",compute="count_all")
    count_picking_assigned = fields.Integer(string="Count Picking Assigned",compute="count_all")
    count_picking_partial = fields.Integer(string="Count Picking Partial",compute="count_all")
    count_picking_done = fields.Integer(string="Count Picking Done",compute="count_all")
    
    count_open_invoices = fields.Integer(string="Count Open Invoices",compute="count_all")
    count_paid_invoices = fields.Integer(string="Count Paid Invoices",compute="count_all")
    count_refund_invoices = fields.Integer(string="Count Refund Invoices",compute="count_all")

    rate_picking_late = fields.Integer(string="Count Rate Pickings",compute="count_all")
    rate_picking_backorders = fields.Integer(string="Count Back Orders",compute="count_all")
    count_picking_late = fields.Integer(string="Count Rate Pickings",compute="count_all")
    count_picking_backorders = fields.Integer(string="Count Back Orders",compute="count_all")

    @api.multi
    def view_data(self):
        result = {}
        if self.action_id:
            result = self.action_id and self.action_id.read()[0] or {}
            if self.action_id.res_model == 'ir.cron':
                cron_ids = self.find_magento_cron(self.action_id)
                result['domain'] = "[('id','in',[" + ','.join(map(str, cron_ids)) + "])]"        
            else:
                result = self.action_id and self.action_id.read()[0] or {}
        return result    
    
    @api.multi
    def get_action_perform_oprations(self):
        return self._get_action("odoo_magento1_ept.action_wizard_magento_import_export_operations") 
    
    @api.multi
    def get_magento_pending_orders(self):
        return self._get_action('odoo_magento1_ept.magento_action_quotations_ept')
    
    @api.multi
    def get_magento_sales_orders(self):
        return self._get_action('odoo_magento1_ept.magento_action_sale_orders_ept')
    
    @api.multi
    def get_magento_canceled_in_magento_orders(self):
        return self._get_action('odoo_magento1_ept.magento_action_canceled_in_magento_orders_ept')
    
    @api.multi
    def get_magento_waiting_shipments(self):
        return self._get_action('odoo_magento1_ept.magento_action_picking_view_confirm_ept')
    
    @api.multi
    def get_magento_ready_shipments(self):
        return self._get_action('odoo_magento1_ept.magento_action_picking_view_assigned_ept')
    
    @api.multi
    def get_magento_transfered_shipments(self):
        return self._get_action('odoo_magento1_ept.magento_action_picking_view_done_ept')
    
    @api.multi
    def get_magento_open_invoices(self):
        return self._get_action('odoo_magento1_ept.action_open_invoice_tree_magento_invoices')
    
    @api.multi
    def get_magento_paid_invoices(self):
        return self._get_action('odoo_magento1_ept.action_paid_invoice_tree_magento_invoices')
    
    @api.multi
    def get_magento_customers(self):
        return self._get_action('odoo_magento1_ept.action_magento_partner_form')
    
    @api.multi
    def get_magento_products(self):
        return self._get_action('odoo_magento1_ept.magento_product_normal_action_sell_ept')
    
    @api.multi
    def get_magento_websites(self):
        return self._get_action('odoo_magento1_ept.action_magento_website')
    
    @api.multi
    def get_magento_stores(self):
        return self._get_action('odoo_magento1_ept.action_magento_store')
    
    @api.multi
    def get_magento_storeviews(self):
        return self._get_action('odoo_magento1_ept.action_magento_storeview')
    @api.multi
    def get_magento_backend(self):
        return self._get_action('odoo_magento1_ept.action_magento_backend')
    
    @api.multi
    def _get_action(self, action):
        action = self.env.ref(action) or False
        result = action.read()[0] or {}
        domain = result.get('domain') and ast.literal_eval(result.get('domain')) or []
        if action.res_model in ['sale.order','res.partner','product.product'] :
            if ('magento_bind_ids','!=',False) in domain :
                domain.remove(('magento_bind_ids','!=',False))
            domain.append(('magento_bind_ids.backend_id','in',[self.backend_id.id]))
        if action.res_model in ['account.invoice','stock.picking'] :
            if ('sale_id.magento_bind_ids','!=',False) in domain :
                domain.remove(('sale_id.magento_bind_ids','!=',False))
            domain.append(('sale_id.magento_bind_ids.backend_id','in',[self.backend_id.id]))
        if action.res_model in ['magento.website','magento.store','magento.storeview']:
            domain.append(('backend_id','=',self.backend_id.id))
        if action.res_model in ['magento.backend']:            
            view_xmlid = 'odoo_magento1_ept.view_magento_backend_form'
            view = self.env.ref(view_xmlid)
            result['views'] = [(view.id if view else False, 'form')]
            result['res_id'] = self.backend_id.id
        result['domain'] = domain
        return result
         