import  xmlrpclib
from lxml import etree
from odoo import models, fields, api, _
from odoo.addons.odoo_magento1_ept.models.unit.backend_adapter import GenericAdapter
from odoo.addons.odoo_magento1_ept.models.unit.delete_synchronizer import MagentoDeleter
from odoo.addons.odoo_magento1_ept.models.unit.export_synchronizer import MagentoExporter
from odoo.addons.odoo_magento1_ept.models.unit.mapper import (ExportMapper,
                                                             mapping,
                                                             )
from odoo.addons.odoo_magento1_ept.models.backend.backend import magento
from odoo.addons.odoo_magento1_ept.models.api_request import req
from odoo.addons.odoo_magento1_ept.models.backend.exception import FailedJobError


class AttributeOption(models.Model):
    _name = "attribute.option"
    _description = "Attribute Option"
    _order="sequence"

    @api.multi
    def _get_model_list(self):
        model_pool = self.env['ir.model']
        res = model_pool.search([])        
        return [(r.model, r.name) for r in res]

    
    name=fields.Char(string='Name',size=128,translate=True,required=True)
    value_ref=fields.Reference(string='Reference',selection="_get_model_list",size=128)
    attribute_id=fields.Many2one(comodel_name='attribute.attribute',string='Product Attribute',required=True)
    sequence=fields.Integer('Sequence')    
    magento_bind_ids=fields.One2many('magento.attribute.option','openerp_id',string='Magento Bindings')
    is_default=fields.Boolean(string='Is default',default=False)
    system_option=fields.Boolean(string='System Option',default=False)
    
    
    @api.multi
    def name_change(self,name,relation_model_id):
        if relation_model_id:
            warning = {'title': _('Error!'),
                       'message': _("Use the 'Load Options' button "
                                    "instead to select appropriate "
                                    "model references'")}
            return {"value": {"name":False}, "warning":warning}
        else:
            return True
        
    @api.model
    def create(self,vals):
        if not self._context:
            self._context = {}
        attribute_option=super(AttributeOption,self).create(vals)
        if attribute_option.attribute_id:
            magento_id = self._context.get('magento_id')
            for backend in attribute_option.attribute_id.magento_bind_ids:
                check = self.env['magento.attribute.option'].search([('name','=',attribute_option.name),
                                                                     ('attribute_id', '=', backend.id),
                                                                     ('backend_id', '=',backend.backend_id.id),
                                                                     ('magento_id','=',magento_id)])
                if check :
                    check.with_context(self._context).write({'openerp_id':attribute_option.id})
                if not check:
                    self.env['magento.attribute.option'].create({'openerp_id': attribute_option.id,
                                                                 'attribute_id': backend.id,
                                                                 'backend_id': backend.backend_id.id,
                                                                 'name': attribute_option.name,
                                                                 'is_default': attribute_option.is_default,
                                                                 'system_option': attribute_option.system_option})
        return attribute_option
        
    @api.multi
    def unlink(self):
        for option in self:
            if not option.system_option:
                for magento_option in option.magento_bind_ids:
                #self.env['magento.attribute.option'].unlink(cr, uid, magento_option.id)
                    magento_option.unlink()
            else:
                raise Warning('You can not delete default Magento Attribute option')
        return super(AttributeOption, self).unlink()

    @api.multi
    def write(self,vals):
        for option in self:
            if not option.system_option:
                for magento_option in option.magento_bind_ids:
                    check_default = vals.get('is_default',None)
                    if vals.get('name') or check_default is not None:
                        name = vals.get('name', option.name)
                        if check_default is not None:
                            is_default = vals.get('is_default')
                        else:
                            is_default = option.is_default
#                         self.env['magento.attribute.option'].write(cr, uid, magento_option.id,
#                                                                     {'name': name, 'is_default': is_default})
                        magento_option.write({'name': name, 'is_default': is_default})
            else:
                raise Warning('You can not update default Magento Attribute option')
        return super(AttributeOption, self).write(vals)

        
class MagentoAttributeOption(models.Model):
    _name = 'magento.attribute.option'
    _description = ""
    _inherit = 'magento.binding'

    
    openerp_id=fields.Many2one('attribute.option',string='Odoo Attribute option',ondelete='cascade')
    name=fields.Char(string='Name',size=64,required=True)
    is_default=fields.Boolean(string='Is default',default=True)
    attribute_id=fields.Many2one('magento.product.attribute',string='Product Attribute',ondelete='cascade')
    magento_id=fields.Char(string='ID on Magento', size=255)
    system_option=fields.Boolean(string='System Option',default=False)
    
    @api.onchange('attribute_id')
    def onchange_attribute_id(self):
        return {'domain':{'backend_id':[('id','in',[self.attribute_id.backend_id.id])]}}

    _sql_constraints = [
        ('magento_uniq', 'unique(backend_id,magento_id,attribute_id)',
         'An attribute option with the same ID on Magento already exists.'),
        ('openerp_uniq', 'unique(backend_id, openerp_id)',
         'An attribute option can not be bound to several records on the same backend.'),
    ]
    
    @api.multi
    def unlink(self):
        if not self.env.context.get('connector_no_export',False):
            for option in self:
                if option.system_option:
                    raise Warning('You can not delete default Magento Attribute option')
                
        return super(MagentoAttributeOption, self).unlink()

    @api.multi
    def write(self,vals):
        if not self.env.context.get('connector_no_export',False):
            for option in self:
                if option.system_option:
                    raise Warning('You can not update default Magento Attribute option')
                
        return super(MagentoAttributeOption, self).write(vals)


@magento
class AttributeOptionAdapter(GenericAdapter):
    _model_name = 'magento.attribute.option'
    _magento_model = 'oerp_product_attribute'
    _path = "/V1/products/attributes/{attributeCode}/options"


    def create(self, data):
        attribute_id = data.pop('attribute')
        if not attribute_id :
            job = self.env['queue.job'].search([('model_name','=','magento.attribute.option'),('state','=','started')])
            job.requeue()
        
        raise FailedJobError(("Attribute not found for attribute option : %s")% data.get('label'))
        data={
              'option':data
            }
          
        path = self._path.format(attributeCode=attribute_id)
        result = req(self.backend_record,path,method="POST",data=data)
        if result == True :
            path = self._path.format(attributeCode=attribute_id)
            options = req(self.backend_record,path,method="GET")
            for option in options :
                if option.get('label')==data['option'].get('label'):
                    return option.get('value')
        res = self._call('product_attribute.addOption',[attribute_id, data])
        return res

    def delete(self, vals):
        """ Delete a record on the external system """
        option_id = vals.get('option_mag_id','')
        attribute_id=vals.get('attribute_mag_id','')
        path = str(self._path+"/{option_id}").format(attributeCode=attribute_id,option_id=option_id)
        result = req(self.backend_record,path,method="DELETE")
        return result

    def read(self, id, attribute_id=None):
        """ Returns the information of a record
        :rtype: dict
        """
        try:
            id = int(id)
            
        except (ValueError,xmlrpclib.Fault) as e :
            
            if e.faultcode in [3]:
                
                raise FailedJobError('Installation Missing!\n\n Magento plugin seems missing on Magento, Please install plugin on Magento and try again.')
            
            return self._call('ol_catalog_product_attribute.infoOption' % self._magento_model,
                                  [int(attribute_id),id])
            #over

@magento
class AttributeOptionDeleteSynchronizer(MagentoDeleter):
    _model_name = ['magento.attribute.option']
    #added by krishna
    def run(self,vals):
        self.backend_adapter.delete(vals)
        return _('Record %s deleted on Magento') % vals.get('option_id','')

@magento
class AttributeOptionExporter(MagentoExporter):
    _model_name = ['magento.attribute.option']
    
    def _should_import(self):
        return False
    
    def _export_dependencies(self):
        attribute = self.binding_record.attribute_id
        if not attribute.magento_id :
            self._export_dependency(attribute,'magento.product.attribute')
    
@magento
class AttributeOptionExportMapper(ExportMapper):
    _model_name = 'magento.attribute.option'

    direct = []

    @mapping
    def label(self, record):
        storeviews = self.env['magento.storeview'].search([('backend_id','=',self.backend_record.id)])
        storeview_label = []
        for storeview in storeviews:
            name = record.name
            storeview_label.append({
                'store_id': storeview.magento_id,
                'label': name
                })
        label = record.name
        return {'label': label,'store_labels':storeview_label}

    @mapping
    def attribute(self, record):
        #binder = self.get_binder_for_model('magento.product.attribute')
        #magento_attribute_id = binder.to_backend(record.openerp_id.attribute_id.id, wrap=True)
        magento_attribute_id = record.attribute_id and record.attribute_id.magento_id
        return {'attribute': magento_attribute_id}

    @mapping
    def order(self, record):
        #TODO FIXME
        return {'sort_order': record.openerp_id.sequence + 1 }

    @mapping
    def is_default(self, record):
        return {'is_default': record.is_default}



class attribute_option_wizard(models.TransientModel):
    _name = "attribute.option.wizard"
    _rec_name = 'attribute_id'

    
    attribute_id=fields.Many2one(comodel_name='attribute.attribute',string='Product Attribute',required=True,default= lambda self, cr, uid, context:context.get('attribute_id',False))
    @api.one
    def validate(self):
        return True

    @api.model
    def create(self,vals):
        attr_obj = self.env["attribute.attribute"]
        attr = attr_obj.browse(vals['attribute_id'])
        op_ids = [op.id for op in attr.option_ids]
        opt_obj = self.env["attribute.option"]
        opt_obj.unlink( op_ids)
        for op_id in (vals.get("option_ids") and vals['option_ids'][0][2] or []):
            model = attr.relation_model_id.model
            name = self.env[model].search([('id','=',op_id)]).name_get()[0][1]
            opt_obj.create( {
                'attribute_id': vals['attribute_id'],
                'name': name,
                'value_ref': "%s,%s" % (attr.relation_model_id.model, op_id)
            })
        res = super(attribute_option_wizard, self).create( vals)
        return res

    @api.multi
    def fields_view_get(self, view_id=None, view_type='form',
                         toolbar=False, submenu=False):
        context=self._context
        res = super(attribute_option_wizard, self).fields_view_get(
             view_id, view_type, toolbar, submenu)
        if view_type == 'form' and context and context.get("attribute_id"):
            attr_obj = self.env["attribute.attribute"]
            model_id = attr_obj.read([context.get("attribute_id")],
                            ['relation_model_id'])[0]['relation_model_id'][0]
            #relation = self.pool.get("ir.model").read(cr, uid, [model_id],
#                                                      ["model"])[0]["model"]
            relation = self.env["ir.model"].browse([model_id])
            relation=relation[0]["model"]
            
            res['fields'].update({'option_ids': {
                            'domain': [],
                            'string':"Options",
                            'type': 'many2many',
                            'relation':relation,
                            'required': True,
                            }
                        })
            eview = etree.fromstring(res['arch'])
            options = etree.Element('field', name='option_ids', colspan='6')
            placeholder = eview.xpath("//separator[@string='options_placeholder']")[0]
            placeholder.getparent().replace(placeholder, options)
            res['arch'] = etree.tostring(eview, pretty_print=True)
        return res

