import logging
from odoo import models, fields, api
from odoo.tools.translate import _
from odoo.addons.odoo_magento1_ept.models.backend.backend import magento
from odoo.addons.odoo_magento1_ept.models.unit.binder import MagentoModelBinder
from odoo.addons.odoo_magento1_ept.models.unit.export_synchronizer import MagentoExporter
from odoo.addons.odoo_magento1_ept.models.unit.import_synchronizer import MagentoImportSynchronizer
from odoo.addons.odoo_magento1_ept.models.unit.mapper import (mapping,
                                                             ImportMapper,
                                                             ExportMapper,
                                                             )
from odoo.addons.odoo_magento1_ept.models.backend.exception import (FailedJobError,
                                                                   IDMissingInBackend
                                                                   )
from odoo.addons.odoo_magento1_ept.models.unit.import_synchronizer import IMPORT_DELTA_BUFFER,MagentoImportSynchronizer
from odoo.addons.odoo_magento1_ept.models.product.product import  ProductProductAdapter

_logger = logging.getLogger(__name__)


def chunks(items,length):
    for index in xrange(0, len(items),length):
        yield items[index:index + length]


class ProductWebsitePrice(models.Model):
       
        _name="magento.product.price"
        _inherit='magento.binding'
        _description="For Magento Website wise price"
        
        _sql_constraints = [
        ('magento_uniq', 'unique(backend_id, magento_id,website_id)',
         "Product price already exists with the same Website and Magento ID.")]
        
#         _sql_constraints = [
#         ('magento_product_price_uniq', 'unique((backend_id, magento_id,website_id))',
#          "Product price already exists with the same Website and Magento ID.")]

        product_id = fields.Many2one('magento.product.product', string='Product',ondelete='cascade')
        website_id = fields.Many2one("magento.website",string="Website")     
        currency_id = fields.Many2one('res.currency',help='Utility field to express amount currency')
        price=fields.Float(string="Price")  
      
        
@magento    
class ProductPriceImporter(MagentoImportSynchronizer):   
       
    _model_name = ['magento.product.price']
           
    def _get_magento_data(self):
        """ Return the raw Magento data for ``self.magento_id`` """
     
        product_importer = self.unit_for(ProductProductAdapter,'magento.product.product')
         
        storeview_id=self.env['magento.storeview'].search([('website_id','=',self.website_id)],limit=1)
         
        if not storeview_id:
          
            raise FailedJobError("Job is failed because could not find storeview for these website")   
        return product_importer.read(self.magento_id,storeview_id.magento_id)
     
    def _create_data(self, map_record, **kwargs):
        return super(ProductPriceImporter, self)._create_data(
            map_record,
            website_id = self.website_id,
            **kwargs)
         
    def _update_data(self, map_record, **kwargs):
        return super(ProductPriceImporter, self)._update_data(
            map_record,
            website_id = self.website_id,
            **kwargs)
         
#     def run(self, magento_id, binding_id):
#         return True
    def run(self,magento_id,website_id,force=False):
        """ Run the synchronization
        :param magento_id: identifier of the record on Magento
        """
        self.magento_id =magento_id # pass this
        self.website_id=website_id
        res=super(ProductPriceImporter,self).run(self.magento_id,self.website_id)
         
         
    def _get_binding(self):
        bindings = self.model.with_context(active_test=False).search([('magento_id','=',self.magento_id),('backend_id','=',self.backend_record.id),('website_id','=',self.website_id)])
        if  bindings:
            assert len(bindings) == 1, "Several records found: %s" % (bindings,)         
            return bindings
        else:
            return self.model.browse()    
         
         
@magento
class ProductPriceImportMapper(ImportMapper):    
    _model_name ='magento.product.price'
      
    direct=[('price','price')]
     
    @mapping
    def website_id(self,record):
        return {'website_id':self.options.website_id}
     
    @mapping
    def magento_id(self,record):
        return {'magento_id':record['product_id']}
     
    @mapping    
    def backend_id(self,record):
        return{'backend_id':self.backend_record.id} 
      
    #added by arti    
    @mapping
    def  product_id(self,record):       
        products=record.get('product_id')
        binder = self.binder_for('magento.product.product')
        product_id = binder.to_openerp(products)
        return{'product_id':product_id}
         
    @mapping
    def currency_id(self,record):
        website_id=self.options.website_id
        website=self.env['magento.website'].browse(website_id)
        if website.pricelist_id:            
            return {'currency_id':website.pricelist_id.currency_id.id}
        else:
            raise FailedJobError(
                "\nThe configuration is missing for the PriceList in website '%s'.\n\n"
                "Resolution:\n"
                "- Go to Your "
                "'Magento >> Settings >> Websites'"
                "- Select Website '%s' \n"
                "- Set PriceList  " % (website.name,website.name))
            

@magento
class ProductPriceExporter(MagentoExporter):
    _model_name = 'magento.product.price'
    
    def _export_dependencies(self):
        product = self.binding_record.product_id
        self._export_dependency(product,'magento.product.product')
    
    def _should_import(self):
        return False
        
    def get_storeview(self):
        return self.env['magento.storeview'].search([('website_id','=',self.website_id)],limit=1)
        
    def _run(self,fields=None):
        """ Flow of the synchronization, implemented in inherited classes"""
        
        assert self.binding_id
        assert self.binding_record
        self.website_id = self.binding_record.website_id.id
        assert self.website_id     
        
        if not self.magento_id:
            fields = None  # should be created with all the fields

        if self._has_to_skip():
            return
        
        # export the missing linked resources
        self._export_dependencies()

        # prevent other jobs to export the same record
        # will be released on commit (or rollback)
        self._lock()
        
        storeview = self.get_storeview()
        map_record = self._map_data()
        if storeview :
            record = self._create_data(map_record,fields=fields)
            if not record:
                return _('Nothing to export.')
            product = record.get('product_id')
            self.magento_id = product
            product_adapter = self.unit_for(ProductProductAdapter,'magento.product.product')
            product_adapter.write(product,record,storeview.code)
        else :
            raise FailedJobError("Storeview not found to export Product Price Website wise for product : %s"%self.binding_record.product_id.default_code)
        return _('Record exported with ID %s on Magento.') % self.magento_id
    
@magento
class ProductPriceExportMapper(ExportMapper):
    _model_name = 'magento.product.price'
     
    direct=[('price','price')] 
    
    @mapping
    def product_id(self,record):
        binder=self.binder_for('magento.product.product')
        magento_product_id=binder.to_backend(record.product_id.id)
        return {'product_id':magento_product_id}