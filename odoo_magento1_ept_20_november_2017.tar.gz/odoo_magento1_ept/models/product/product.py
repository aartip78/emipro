# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: Guewen Baconnier, David Beal
#    Comodelsright 2013 Camptocamp SA
#    Comodelsright 2013 Akretion
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a comodels of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging
import urllib2
import base64
import xmlrpclib
import sys
from datetime import datetime, timedelta
from collections import defaultdict
from odoo import models, fields, api, tools, _
from odoo.exceptions import (ValidationError,Warning)
from odoo.addons.odoo_magento1_ept.models.logs.job import job, related_action,unwrap_binding
from odoo.addons.odoo_magento1_ept.models.backend.event import (on_record_write,
                                                               on_product_price_changed)
from odoo.addons.odoo_magento1_ept.models.unit.synchronizer import (Importer,
                                                        Exporter,
                                                        )
from odoo.addons.odoo_magento1_ept.models.unit.export_synchronizer import MagentoExporter
from odoo.addons.odoo_magento1_ept.models.unit.delete_synchronizer import MagentoDeleter
from odoo.addons.odoo_magento1_ept.models.backend.exception import (MappingError,
                                                InvalidDataError,
                                                IDMissingInBackend,
                                                FailedJobError,
                                                RetryableJobError
                                                )
from odoo.addons.odoo_magento1_ept.models.unit.mapper import (mapping,
                                                             normalize_datetime,
                                                             ImportMapper,
                                                             ExportMapper,
                                                             changed_by,
                                                             only_create,
                                                  )
from odoo.addons.odoo_magento1_ept.models.unit.backend_adapter import (GenericAdapter,
                                   MAGENTO_DATETIME_FORMAT,
                                   )
from odoo.addons.odoo_magento1_ept.models.unit.import_synchronizer import (DelayedBatchImporter,
                                       MagentoImporter,
                                       TranslationImporter,
                                       )
from odoo.addons.odoo_magento1_ept.models.backend.connector import get_environment
from odoo.addons.odoo_magento1_ept.models.backend.backend import magento
#from .related_action import unwrap_binding
from odoo.addons.odoo_magento1_ept.models.api_request import req
from odoo.addons.odoo_magento1_ept.models.search_criteria import create_search_criteria
#from odoo.addons.odoo_magento1_ept.modelsthon_library.php import Php
from odoo.addons.odoo_magento1_ept.models.backend.session import ConnectorSession
import odoo.addons.decimal_precision as dp
from lxml import etree
from odoo.addons.odoo_magento1_ept.models.unit.import_synchronizer import (IMPORT_DELTA_BUFFER,MagentoImportSynchronizer)
from odoo.addons.odoo_magento1_ept.models.product.product_attribute import field_mapping


_logger = logging.getLogger(__name__)


def chunks(items, length):
    for index in xrange(0, len(items),length):
        yield items[index:index + length]


class MagentoProductProduct(models.Model):
    _name = 'magento.product.product'
    _inherit = 'magento.binding'
    _inherits = {'product.product': 'openerp_id'}
    _description = 'Magento Product'

    @api.model
    def product_type_get(self):
        return [
            ('simple', 'Simple Product'),
            ('configurable', 'Configurable Product'),
            ('giftvoucher','Gift Card')
            # XXX activate when supported
            # ('grouped', 'Grouped Product'),
            # ('virtual', 'Virtual Product'),
            # ('bundle', 'Bundle Product'),
            # ('downloadable', 'Downloadable Product'),
        ]

    openerp_id = fields.Many2one(comodel_name='product.product', string='Product', required=True, ondelete='restrict')
    # XXX website_ids can be computed from categories
    """
    website_ids = fields.Many2many(comodel_name='magento.website',
                                   string='Websites',
                                   readonly=True)
    """
    website_ids = fields.Many2many(comodel_name='magento.website',string='Websites',readonly=False, domain="[('backend_id','=',backend_id)]")
    created_at = fields.Date('Created At')
    updated_at = fields.Date('Updated At')
    product_type = fields.Selection(selection='product_type_get', string='Product Type', default='simple', required=True)
    manage_stock = fields.Selection(
        selection=[('use_default', 'Use Default Config'),
                   ('no', 'Do Not Manage Stock'),
                   ('yes', 'Manage Stock')],
        string='Manage Stock Level',default='use_default',required=True,)
    backorders = fields.Selection(
        selection=[('use_default', 'Use Default Config'),
                   ('no', 'No Sell'),
                   ('yes', 'Sell Quantity < 0'),
                   ('yes-and-notification', 'Sell Quantity < 0 and '
                                            'Use Customer Notification')],
        string='Manage Inventory Backorders',
        default='use_default',
        required=True,
    )
    magento_qty = fields.Float(string='Computed Quantity', help="Last computed quantity to send on Magento.")
    no_stock_sync = fields.Boolean(
        string='No Stock Synchronization',
        required=False,
        help="Check this to exclude the product "
             "from stock synchronizations.",
    )
    export_stock_type = fields.Selection(selection=[('fixed','Export Fixed Qty'),
                                                    ('actual','Export Actual Stock')],
                                         string="Export Stock Type",
                                         default='actual')
    export_fix_value = fields.Float(string="Fixed Stock Quantity",digits=dp.get_precision("Product UoS"))
    magento_product_price_ids=fields.One2many('magento.product.price',inverse_name="product_id",string="Magento Product Price")   
    RECOMPUTE_QTY_STEP = 1000  # products at a time


    @api.multi
    def recompute_magento_qty(self):
        """ Check if the quantity in the stock location configured
        on the backend has changed since the last export.

        If it has changed, write the updated quantity on `magento_qty`.
        The write on `magento_qty` will trigger an `on_record_write`
        event that will create an export job.

        It groups the products by backend to avoid to read the backend
        informations for each product.
        """
        # group products by backend
        backends = defaultdict(self.browse)
        for product in self:
            backends[product.backend_id] |= product

        for backend, products in backends.iteritems():
            #group products by export stock type
            stock_type_products = defaultdict(self.browse)
            for product in products:
                stock_type_products[product.export_stock_type] |= product
            for stock_type,type_products in stock_type_products.iteritems():
                if not backend.warehouse_ids:
                    raise Warning("Warehouses not set in Magento Global, \n You should select warehouses from global to export quantity")
                if stock_type == 'fixed':
                    for product in type_products :
                        if product.export_fix_value < 0:
                            product.magento_qty=0.0
                        else:    
                            product.magento_qty = product.export_fix_value
                if stock_type == 'actual':
                    
                    self._recompute_magento_qty_backend(backend,type_products)
        return True
    
    #changed by arti
    #to calculate multiple warehouse stock    
    @api.multi
    def _recompute_magento_qty_backend(self, backend, products,
                                       read_fields=None):
        """ Recompute the products quantity for one backend.

        If field names are passed in ``read_fields`` (as a list), they
        will be read in the product that is used in
        :meth:`~._magento_qty`.

        """
                    
        if backend.product_stock_field_id:
            stock_field = backend.product_stock_field_id.name
        else:
            stock_field = 'virtual_available'
        locations=[]    
        for warehouse in backend.warehouse_ids: 
            if warehouse.lot_stock_id :
                locations.append(warehouse.lot_stock_id.id)
                
        product_fields = ['magento_qty', stock_field]
        if read_fields:
            product_fields += read_fields

        self_with_location = self.with_context(location=locations)
        for chunk_ids in chunks(products.ids, self.RECOMPUTE_QTY_STEP):
            records = self_with_location.browse(chunk_ids)
            for product in records.read(fields=product_fields):
                new_qty = self._magento_qty(product,
                                            backend,
                                            locations,
                                            stock_field)
                if new_qty < 0:
                    self.browse(product['id']).magento_qty = 0.0
                    
                else:
                    if new_qty != product['magento_qty']:
                        self.browse(product['id']).magento_qty = new_qty

    @api.multi
    def _magento_qty(self, product, backend, location, stock_field):
        """ Return the current quantity for one product.

        Can be inherited to change the way the quantity is computed,
        according to a backend / location.

        If you need to read additional fields on the product, see the
        ``read_fields`` argument of :meth:`~._recompute_magento_qty_backend`

        """
        return product[stock_field]
    
    @api.model
    def create(self,vals):
        if vals.get('openerp_id') :
            product = self.env['product.product'].browse(vals.get('openerp_id'))
            if product.attribute_set_id :
                vals.update(product.set_default_values_in_magento_attribute_if_not_set())
        record = super(MagentoProductProduct,self).create(vals)
        record.create_update_magento_website_price()
        return record
    
    @api.multi
    def write(self,vals):
        result = super(MagentoProductProduct,self).write(vals)
        if vals.get('website_ids'):
            self.create_update_magento_website_price()
        return result
    
    @api.multi
    def create_update_magento_website_price(self):
        website_price_obj = self.env['magento.product.price']
        for record in self :
            need_to_delete_websites = record.magento_product_price_ids.mapped('website_id')-record.website_ids
            need_to_delete_website_ids = need_to_delete_websites and need_to_delete_websites.ids or []
            need_to_delete_website_prices = record.magento_product_price_ids.filtered(lambda p : p.website_id.id in need_to_delete_website_ids)
            if need_to_delete_website_prices :
                need_to_delete_website_prices.unlink()
            for website in record.website_ids :
                website_pricelist = website.pricelist_id
                if website_pricelist :
                    website_price = record.magento_product_price_ids.filtered(lambda p:p.website_id.id == website.id)
                    if website_price :
                        website_price.write({
                                             'price':website_pricelist.price_get(record.openerp_id.id,1.0,partner=False)[website_pricelist.id],
                                             'currency_id':website_pricelist.currency_id.id,
                                             'backend_id':record.backend_id.id,
                                             'magento_id':record.magento_id,
                                             })
                    else : 
                        website_price_obj.create({
                                                  'product_id':record.id,
                                                  'backend_id':record.backend_id.id,
                                                  'website_id':website.id,
                                                  'currency_id':website_pricelist.currency_id.id,
                                                  'price':website_pricelist.price_get(record.openerp_id.id,1.0,partner=False)[website_pricelist.id],
                                                  'magento_id':record.magento_id,
                                                  })

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    attribute_set_id=fields.Many2one(comodel_name='attribute.set',string='Attribute Set')
    categ_id = fields.Many2one(string='Pricing/Primary Category')
    categ_ids = fields.Many2many(
        comodel_name='product.category', relation='product_categ_rel',
        column1='product_id', column2='categ_id', string='Product Categories')

    '''
    @api.multi
    def _price_changed(self, vals):
        """ Fire the ``on_product_price_changed`` on all the variants of
        the template if the price of the product could have changed.

        If one of the field used in a sale pricelist item has been
        modified, we consider that the price could have changed.

        There is no guarantee that's the price actually changed,
        because it depends on the pricelists.
        """
        type_model = self.env['product.price.type']
        price_fields = type_model.sale_price_fields()
        # restrict the fields to the template ones only, so if
        # the write has been done on product.product, we won't
        # update all the variants if a price field of the
        # variant has been changed
        tmpl_fields = [field for field in vals if field in self._fields]
        if any(field in price_fields for field in tmpl_fields):
            product_model = self.env['product.product']
            session = ConnectorSession(self.env.cr, self.env.uid,
                                       context=self.env.context)
            products = product_model.search(
                [('product_tmpl_id', 'in', self.ids)]
            )
            # when the write is done on the product.product, avoid
            # to fire the event 2 times
            if self.env.context.get('from_product_ids'):
                from_product_ids = self.env.context['from_product_ids']
                remove_products = product_model.browse(from_product_ids)
                products -= remove_products
            for product in products:
                on_product_price_changed.fire(session,
                                              product_model._name,
                                              product.id)
    '''

    @api.multi
    def write(self, vals):
        result = super(ProductTemplate, self).write(vals)
        #self._price_changed(vals)
        return result


class ProductProduct(models.Model):
    _inherit = 'product.product'
    
    @api.multi
    def _attr_grp_ids(self):
        for obj in self:
            obj.attribute_group_ids = obj.attribute_set_id.attribute_group_ids.ids
    
    @api.one
    @api.constrains('magento_bind_ids')
    def _check_magento_product_exist(self):
        #This constaint is for product will bind with only one magento product
        if len(self.magento_bind_ids) > 1 :
            raise ValidationError(_('Product already have Magento product.'))
        
    @api.one
    @api.constrains('magento_bind_ids','attribute_set_id')
    def _check_magento_product_and_attribute_set(self):
        if self.magento_bind_ids and (self.attribute_set_id.magento_bind_ids and not self.attribute_set_id.magento_bind_ids[0].backend_id.id == self.magento_bind_ids[0].backend_id.id ):
            raise ValidationError(_('Please select attribute set from proper Magento Global for product'))
    
    magento_bind_ids = fields.One2many(comodel_name='magento.product.product',inverse_name='openerp_id',string='Magento Product',)
    attribute_group_ids=fields.Many2many('attribute.group',compute=_attr_grp_ids, string='Groups')
    image_ids=fields.One2many(comodel_name='product.image',inverse_name='product_id',string='Product Images')
    
    @api.multi
    def export_stock_magento(self):
        for product in self:
            if product.magento_bind_ids :
                for magento_product in product.magento_bind_ids :
                    magento_product.recompute_magento_qty()
    
    @api.multi
    def write(self, vals):
        self_context = self.with_context(from_product_ids=self.ids)
        if vals.get('attribute_set_id') :
            #to do : if self have multiple products then need to check this
            #if self have only one product then it is ok.
            attribute_set = self.env['attribute.set'].browse(vals['attribute_set_id'])
            groups = attribute_set.attribute_group_ids.ids
            vals.update(self.with_context(group_ids=groups).set_default_values_in_magento_attribute_if_not_set())
        result = super(ProductProduct, self_context).write(vals)
        return result
    
    @api.model
    def create(self, vals):
        attribute_set_id = vals.get('attribute_set_id',False)
        if attribute_set_id :
            vals.update(self.set_default_values_in_all_magento_attributes(attribute_set_id,vals))
        product = super(ProductProduct, self).create(vals) 
        return product
        
    @api.multi
    def set_default_values_in_magento_attribute_if_not_set(self):
        self.ensure_one()
        groups = self.attribute_group_ids or self.env['attribute.group'].browse(self._context.get('group_ids')) 
        default_vals = {}
        option_obj = self.env['attribute.option']
        for group in groups :
            for attribute in group.attribute_ids :
                odoo_attribute = attribute.attribute_id
                magento_attribute = odoo_attribute.magento_bind_ids and odoo_attribute.magento_bind_ids[0] or False
                if magento_attribute and magento_attribute.default_value :
                    if not self[odoo_attribute.field_id.name] :
                        default_value = magento_attribute.default_value
                        if odoo_attribute.ttype in ('many2one','many2many') :
                            default_value = default_value.split(',')
                            options = option_obj.search([('magento_bind_ids.magento_id','in',default_value),('attribute_id','=',odoo_attribute.id),('magento_bind_ids.backend_id','=',magento_attribute.backend_id.id)])
                            if options :
                                if odoo_attribute.ttype == 'many2one' :
                                    default_vals[odoo_attribute.field_id.name] = len(options) == 1 and options.id or options[0].id
                                if odoo_attribute.ttype == 'many2many':
                                    default_vals[odoo_attribute.field_id.name] = [[6,0,options.ids]]
                                    
                        else :
                            default_vals.update({odoo_attribute.field_id.name:default_value})
        return default_vals
        
    
    @api.multi
    def set_default_values_in_all_magento_attributes(self,attribute_set_id,product_vals):
        attribute_set = self.env['attribute.set'].browse(attribute_set_id)
        vals = {}
        if attribute_set :
            backend = attribute_set.magento_bind_ids[0].backend_id
            option_obj = self.env['attribute.option']
            attrib_default_val = self.env['magento.product.attribute'].search([('default_value','!=',False),('backend_id','=',backend.id)])
            for attrib in attrib_default_val :
                if attrib.type == 'select':
                    options = option_obj.search([('magento_bind_ids.magento_id','=',attrib.default_value),('attribute_id.magento_bind_ids','in',[attrib.id])],limit=1)
                    value = options.id
                else :
                    value = attrib.default_value
                vals.update({attrib.openerp_id.field_id.name:value})
            default_vals = {k:v for k,v in vals.iteritems() if k not in product_vals}
        return default_vals
    
    @api.multi
    def _fix_size_bug(self,result):
    #When created a field text dynamicaly, its size is limited to 64 in the view.
    #The bug is fixed but not merged
    #https://code.launchpad.net/~openerp-dev/openerp-web/6.1-opw-579462-cpa/+merge/128003
    #TO remove when the fix will be merged
        for field in result['fields']:
            if result['fields'][field]['type'] == 'text':
                if 'size' in result['fields'][field]: del result['fields'][field]['size']
        return result
    
    @api.multi
    def open_attributes(self):
        ir_model_data_obj = self.env['ir.model.data']
        ir_model_data_obj = ir_model_data_obj.search([['model', '=', 'ir.ui.view'], ['name', '=', 'product_attributes_form_view']])
        #if ir_model_data_id:
            #res_id = ir_model_data_obj.read(cr, uid, ir_model_data_id, fields=['res_id'])[0]['res_id']
        res_id =ir_model_data_obj and ir_model_data_obj[0]['res_id'] or False
        attr_grp = self.read(['attribute_group_ids'])
        grp_ids=attr_grp and attr_grp[0] and attr_grp[0]['attribute_group_ids'] or []#[self.ids[0]]
        ctx = {'open_attributes': True, 'attribute_group_ids': grp_ids}
        return {
            'name': 'Product Attributes',
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': [res_id],
            'res_model': self._name,
            'context': ctx,
            'type': 'ir.actions.act_window',
            'nodestroy': True,
            'target': 'new',
            'res_id': self.ids and self.ids[0] or False,
        }

    @api.one
    def save_and_close_product_attributes(self):
        return {'type': 'ir.actions.act_window_close'}
    
    @api.model
    def fields_view_get(self, view_id=None, view_type='form', toolbar=False, submenu=False):
        context=dict(self._context) or {}     
        result = super(ProductProduct, self).fields_view_get(view_id=view_id,view_type=view_type,toolbar=toolbar, submenu=submenu)
        if view_type == 'form' and context.get('attribute_group_ids'):
            eview = etree.fromstring(result['arch'])
            #hide button under the name
            button = eview.xpath("//button[@name='open_attributes']")
            if button:
                button = button[0]
                button.getparent().remove(button)
            attributes_notebook, toupdate_fields = self.env['attribute.attribute']._build_attributes_notebook( context['attribute_group_ids'])
            result['fields'].update(self.fields_get( toupdate_fields))
            if context.get('open_attributes'):
                placeholder = eview.xpath("//separator[@string='attributes_placeholder']")[0]
                placeholder.getparent().replace(placeholder, attributes_notebook)
            elif context.get('open_product_by_attribute_set'):
                main_page = etree.Element('page', string=_('Custom Attributes'))
                main_page.append(attributes_notebook)
                info_page = eview.xpath("//page[@string='%s']" % (_('Information'),))[0]
                info_page.addnext(main_page)
            result['arch'] = etree.tostring(eview, pretty_print=True)
            result = self._fix_size_bug(result)
        return result
    

@magento
class ProductProductAdapter(GenericAdapter):
    _model_name = 'magento.product.product'
    _magento_model = 'catalog_product'
    _admin_path = '/{model}/edit/id/{id}'
#     _path = "/V1/products"
    _sku = {}
       
    def _call(self,method,arguments):
        try:
            return super(ProductProductAdapter, self)._call(method,arguments)
        except xmlrpclib.Fault as err:
            # this is the error in the Magento API
            # when the product does not exist
            raise
        
        
    def search(self, filters=None,from_date=None,to_date=None):
        """ Search records according to some criteria
        and returns a list of ids

        :rtype: list
        """
        if filters is None:
            filters = {}
        dt_fmt = MAGENTO_DATETIME_FORMAT
        if from_date is not None:
            filters.setdefault('updated_at', {})
            filters['updated_at']['from'] = from_date.strftime(dt_fmt)
        if to_date is not None:
            filters.setdefault('updated_at', {})
            filters['updated_at']['to'] = to_date.strftime(dt_fmt)
        # TODO add a search entry point on the Magento API
        result = [int(row['product_id']) for row
                in self._call('%s.list' % self._magento_model,
                              [filters] if filters else [{}])]
        return result
    
#     def _get_sku(self,id):
#         id = int(id)
#         backend = self.backend_record.id
#         sku = self._sku.get(backend) and self._sku[backend].get(id)
#         if not sku :
#             binder = self.binder_for()
#             product = binder.to_openerp(id,unwrap=True,browse=True)
#             sku = product and product.default_code or False
#         if not sku :
#             filters = {'entity_id':id}
#             self.search(filters)
#             sku = self._sku.get(backend) and self._sku[backend].get(id)
#         if not sku :
#             raise RetryableJobError("SKU not found for product id : %s"%(id))
#         return sku
    
    
    def read(self,id,storeview_id=None,attributes=None):
        """ Returns the information of a record
        :rtype: dict
        """
#         result = self._call('catalog_product.info',
#                           [int(id),storeview_id, attributes,'id'])
#         return result
        try:   
            result = self._call('catalog_product.info',
                                  [int(id),storeview_id,attributes,'id'])
            
        except xmlrpclib.Fault as err:
             
            if err.faultCode in[101]:
                raise FailedJobError(
                "%s \nProduct Id: %s.\n"%(err.faultString,id))
        if result.get('product_id'):
            return result
        else:
            raise RetryableJobError("Product read fail for product id :%s"%(id))
    #Changed by Dimpal : 26 june 2017 
    def create(self,data):
        try:
            
            res =  self._call('ol_catalog_product.create',[data.get('type_id'),data.get('attribute_set_id'),data.get('sku'),data])
            return res
        except xmlrpclib.Fault as err:   
                 
            if err.faultCode in[3]:
                
                raise FailedJobError(" Installation Missing! \n\nMagento plugin seems missing on Magento, Please install plugin on Magento and try again.")

        return True
        
    def write(self, id, data, storeview_id=None):
        
        return self._call('ol_catalog_product.update',
                          [int(id), data, storeview_id, 'id'])

    def get_images(self, id, storeview_id=None):
        
        try:
            return self._call('product_media.list', [int(id), storeview_id, 'id'])
        
        except xmlrpclib.Fault as err:   
            if err.faultCode in[3]:
                
                raise FailedJobError(" Installation Missing! \n\nMagento plugin seems missing on Magento, Please install plugin on Magento and try again.")

    
    def read_image(self, id, image_name, storeview_id=None):
        
        try:
            return self._call('product_media.info',
                              [int(id), image_name, storeview_id, 'id'])
        except xmlrpclib.Fault as err:   
            if err.faultCode in[3]:
                
                raise FailedJobError(" Installation Missing! \n\nMagento plugin seems missing on Magento, Please install plugin on Magento and try again.")

        
    def update_inventory(self, id, data):
        # product_stock.update is too slow
        try:
            return self._call('oerp_cataloginventory_stock_item.update',
                              [int(id), data])
        except xmlrpclib.Fault as err:   
            if err.faultCode in[3]:
                
                raise FailedJobError(" Installation Missing! \n\nMagento plugin seems missing on Magento, Please install plugin on Magento and try again.")

        
    def delete(self,sku):
        sku = urllib2.quote(sku)
        url = self._path+"/%s"%sku
        res = super(ProductProductAdapter,self).delete(sku)
        return res
    
    # Dimpal
    def website_link(self,sku,website_id):
        try:
            data = {
                       'website_id':website_id
                    }
            return self._call('ol_catalog_product.update',
                              [int(id), data])
        except xmlrpclib.Fault as err:   
            if err.faultCode in[3]:
                
                raise FailedJobError(" Installation Missing! \n\nMagento plugin seems missing on Magento, Please install plugin on Magento and try again.")

    
@magento
class ProductBatchImporter(DelayedBatchImporter):
    """ Import the Magento Products.

    For every product category in the list, a delayed job is created.
    Import from a date
    """
    _model_name = ['magento.product.product']


    def run(self, filters=None):
        """ Run the synchronization """
        from_date = filters.pop('from_date', None)
        to_date = filters.pop('to_date', None)
        record_ids = self.backend_adapter.search(filters,
                                                 from_date=from_date,
                                                 to_date=to_date)
        _logger.info('search for magento products %s returned %s',
                     filters, record_ids)
        #Dimpal
        import_start_time = to_date or datetime.now()
        next_time = import_start_time - timedelta(seconds=IMPORT_DELTA_BUFFER)
        next_time = fields.Datetime.to_string(next_time)
        self.backend_record.write({'import_products_from_date': next_time})
        for record_id in record_ids:
            self._import_record(record_id)

ProductBatchImport = ProductBatchImporter  # deprecated

# @magento
# class CatalogImageImporter(Importer):
#     """ Import images for a record.
#  
#     Usually called from importers, in ``_after_import``.
#     For instance from the products importer.
#     """
#  
#     _model_name = ['magento.product.product',
#                    ]
#  
#     def _get_images(self, storeview_id=None):
#         return self.backend_adapter.get_images(self.magento_id, storeview_id)
#  
#     def _sort_images(self, images):
#         """ Returns a list of images sorted by their priority.
#         An image with the 'image' type is the the primary one.
#         The other images are sorted by their position.
#  
#         The returned list is reversed, the items at the end
#         of the list have the higher priority.
#         """
#         if not images:
#             return {}
#         # place the images where the type is 'image' first then
#         # sort them by the reverse priority (last item of the list has
#         # the the higher priority)
#  
#         def priority(image):
#             primary = 'image' in image['types']
#             try:
#                 position = int(image['position'])
#             except ValueError:
#                 position = sys.maxint
#             return (primary, -position)
#         return sorted(images, key=priority)
#  
#     def _get_binary_image(self, image_data):
#         url = image_data['url'].encode('utf8')
#         try:
#             request = urllib2.Request(url)
#             if self.backend_record.auth_basic_username \
#                     and self.backend_record.auth_basic_password:
#                 base64string = base64.encodestring(
#                     '%s:%s' % (self.backend_record.auth_basic_username,
#                                self.backend_record.auth_basic_password))
#                 request.add_header("Authorization", "Basic %s" % base64string)
#             binary = urllib2.urlopen(request)
#         except urllib2.HTTPError as err:
#             if err.code == 404:
#                 # the image is just missing, we skip it
#                 return
#             else:
#                 # we don't know why we couldn't download the image
#                 # so we propagate the error, the import will fail
#                 # and we have to check why it couldn't be accessed
#                 raise
#         else:
#             return binary.read()
#  
#     def run(self, magento_id, binding_id):
#         self.magento_id = magento_id
#         images = self._get_images()
#         images = self._sort_images(images)
#         binary = None
#         while not binary and images:
#             binary = self._get_binary_image(images.pop())
#         if not binary:
#             return
#         model = self.model.with_context(connector_no_export=True)
#         binding = model.browse(binding_id)
#         binding.write({'image': base64.b64encode(binary)})

@magento
class MagentoImageImporter(MagentoImportSynchronizer):
    """ Import images for a record.

    Usually called from importers, in ``_after_import``.
    For instance from the products importer.
    """

    _model_name = ['magento.product.image']
    # added by krishna , To every time create image of product in ERP, No updation .
   
    def _get_magento_data(self):
        """ Return the raw Magento data for ``self.magento_id`` """
    
        return self.backend_adapter.read(self.magento_id,self.file_name)

#     def run(self, magento_id, binding_id):
#         return True
    def run(self,magento_id,file_name=False,force=False):
        """ Run the synchronization

        :param magento_id: identifier of the record on Magento
        """
        self.magento_id = magento_id # pass this
        self.file_name=file_name
        try:
            self.magento_record = self._get_magento_data()
        except IDMissingInBackend:
            return _('Record does no longer exist in Magento')
        self.magento_id=self.file_name
#         self.magento_id=filename
#         self.magento_record.get('file')    
        binding_id = self._get_binding()

        if not force and self._is_uptodate(binding_id):
            return _('Already up-to-date.')               

        map_record = self._map_data()
        binder = self.binder_for('magento.product.product')
        magento_product= binder.to_openerp(magento_id,browse=True)
        
        if binding_id:
            record = self._update_data(map_record)           
            record.update({'product_id':magento_product.openerp_id.id,'magento_product_id':magento_product.id})            
            self._update(binding_id,record)
        else:
            record = self._create_data(map_record)
            record.update({'product_id':magento_product.openerp_id.id,'magento_product_id':magento_product.id})
            binding_id = self._create(record)

        self.binder.bind(self.magento_id,binding_id)
        return binding_id

@magento
class BundleImporter(Importer):
    """ Can be inherited to change the way the bundle products are
    imported.

    Called at the end of the import of a product.

    Example of action when importing a bundle product:
        - Create a bill of material
        - Import the structure of the bundle in new objects

    By default, the bundle products are not imported: the jobs
    are set as failed, because there is no known way to import them.
    An additional module that implements the import should be installed.

    If you want to create a custom importer for the bundles, you have to
    declare the ConnectorUnit on your backend::

        @magento_custom
        class XBundleImporter(BundleImporter):
            _model_name = 'magento.product.product'

            # implement import_bundle

    If you want to create a generic module that import bundles, you have
    to replace the current ConnectorUnit::

        @magento(replacing=BundleImporter)
        class XBundleImporter(BundleImporter):
            _model_name = 'magento.product.product'

            # implement import_bundle

    And to add the bundle type in the supported product types::

        class magento_product_product(orm.Model):
            _inherit = 'magento.product.product'

            def product_type_get(self, cr, uid, context=None):
                types = super(magento_product_product, self).product_type_get(
                    cr, uid, context=context)
                if 'bundle' not in [item[0] for item in types]:
                    types.append(('bundle', 'Bundle'))
                return types

    """
    _model_name = 'magento.product.product'

    def run(self, binding_id, magento_record):
        """ Import the bundle information about a product.

        :param magento_record: product information from Magento
        """


@magento
class ProductImportMapper(ImportMapper):
    _model_name = 'magento.product.product'
    # TODO :     categ, special_price => minimal_price
    direct= [('name', 'name'),
              ('weight', 'weight'),
              ('sku', 'default_code'),
              ('type_id', 'product_type'),
              (normalize_datetime('created_at'), 'created_at'),
              (normalize_datetime('updated_at'), 'updated_at'),
              ('description', 'description'),
              ('short_description', 'description_sale'),
              ]
    
    @mapping
    def standard_price(self,record):
        if record :
            return {'standard_price':record.get('price')}
        return 
        
    @mapping
    def magento_id(self, record):
            return {'magento_id': record['product_id']}
           
    @mapping
    def website_ids(self, record):
        website_ids = []
        binder = self.binder_for('magento.website')
        for mag_website_id in record['websites']:
            website_id = binder.to_openerp(mag_website_id)
            website_ids.append((4, website_id))
        return {'website_ids':website_ids}
        
    
    @mapping
    def is_active(self, record):
        mapper = self.unit_for(IsActiveProductImportMapper)
        return mapper.map_record(record).values(**self.options)

    @mapping
    def price(self, record):
        """ The price is imported at the creation of
        the product, then it is only modified and exported
        from OpenERP """
        return {'list_price': record.get('price', 0.0)}

    @mapping
    def type(self, record):
        if record['type_id'] == 'simple':
            return {'type': 'product'}
        if record['type_id'] == 'giftvoucher' :
            return {'type':'service'}
        return

    @mapping
    def categories(self, record):
        mag_categories = record.get('category_ids',[]) 
        binder = self.binder_for('magento.product.category')

        category_ids = []
        main_categ_id = None

        for mag_category_id in mag_categories:
            cat_id = binder.to_openerp(mag_category_id, unwrap=True)
            if cat_id is None:
                raise MappingError("The product category with "
                                   "magento id %s is not imported." %
                                   mag_category_id)

            category_ids.append(cat_id)

        if category_ids:
            main_categ_id = category_ids.pop(0)

        if main_categ_id is None:
            default_categ = self.backend_record.default_category_id
            if default_categ:
                main_categ_id = default_categ.id

        result = {'categ_ids': [(6, 0, category_ids)]}
        if main_categ_id:  # OpenERP assign 'All Products' if not specified
            result['categ_id'] = main_categ_id
        return result

    @mapping
    def backend_id(self, record):
        return {'backend_id': self.backend_record.id}

    @mapping
    def bundle_mapping(self, record):
        if record['type_id'] == 'bundle':
            bundle_mapper = self.unit_for(BundleProductImportMapper)
            return bundle_mapper.map_record(record).values(**self.options)
    

    @mapping
    def attribute_set(self,record):
        result = {}
        binder = self.binder_for('magento.attribute.set')
        set_id = binder.to_openerp(record.get('set'), unwrap=True)
        if set_id:
            result.update({'attribute_set_id':set_id})
        return result
    
    @mapping
    def custom_attributes(self,record):
        set_binder = self.binder_for('magento.attribute.set')
        attr_binder = self.binder_for('magento.product.attribute')
        option_binder = self.binder_for('magento.attribute.option')
        result = {}
        mag_set_id = set_binder.to_openerp(record.get('attribute_set_id'))
        attribute_groups = self.env['magento.attribute.group'].search([('attribute_set_id','in',[mag_set_id])])
        attributes = {}
        for group in attribute_groups :
            attributes.update({attribute.attribute_code:attribute.id for attribute in group.magento_attribute_ids})
        custom_attributes = record.get('custom_attributes')
        if not custom_attributes:
            custom_attributes={}
        for attribute in custom_attributes:
            attr_value = custom_attributes[attribute]
            #openerp_field_name = "x_%s"%attribute
            attr_record = self.env['magento.product.attribute'].search([('backend_id','=',self.backend_record.id),
                                                          ('attribute_code','=',str(attribute))],limit=1)
            attr_record = attr_binder.to_openerp(attr_record.magento_id,browse=True)
            openerp_field_name = attr_record.openerp_id.field_id.name
            if attr_record :
                if attr_record.openerp_id.ttype == 'many2one':
                    magento_option = self.env['magento.attribute.option'].search([('magento_id','=',attr_value),('attribute_id.attribute_code','=',attribute)],limit=1)
                    option_id=magento_option.openerp_id and magento_option.openerp_id.id or False
                    result.update({openerp_field_name:option_id})
                elif attr_record.openerp_id.ttype== 'many2many':
                    if attr_record.attribute_code == 'category_ids' :
                        continue
                    magento_attribute_option_domain = [('attribute_id.attribute_code','=',attribute)]
                    if isinstance(attr_value,basestring) :
                        attr_value = attr_value.split(',')
                    magento_attribute_option_domain.append(('magento_id','in',attr_value))
                    magento_options = self.env['magento.attribute.option'].search(magento_attribute_option_domain)
                    option_ids = [magento_option.openerp_id.id for magento_option in magento_options if magento_option.openerp_id]
                    if option_ids:
                        result.update({openerp_field_name:[(4,option_ids)]})
                elif attr_record.openerp_id.ttype=='boolean':
                    if attr_value and int(attr_value) :
                        result.update({openerp_field_name:True})
                    else :
                        result.update({openerp_field_name:False})
                else :
                    result.update({openerp_field_name:attr_value})
                    
            if attributes.get(attribute):
                del attributes[attribute]
        response_fields = record.keys()
        response_fields = list(set(response_fields)-set(field_mapping.keys()))
        for attribute in attributes :
                if attribute in response_fields :
                    openerp_field_name = "x_%s"%attribute
                    attr_value = record[attribute]
                    
                    attr_record = self.env['magento.product.attribute'].search([('backend_id','=',self.backend_record.id),
                                                          ('attribute_code','=',str(attribute))],limit=1)
                    attr_record = attr_binder.to_openerp(attr_record.magento_id,browse=True)
                    openerp_field_name = attr_record.openerp_id.field_id.name
                    #attr_record = attr_binder.to_openerp(attribute,browse=True)
                    if attr_record:
                        if attr_record.openerp_id.ttype=='many2one':
                            magento_option = self.env['magento.attribute.option'].search([('magento_id','=',attr_value),('attribute_id.attribute_code','=',attribute)],limit=1)
                            option_id=magento_option.openerp_id and magento_option.openerp_id.id or False
                            result.update({openerp_field_name:option_id})
                        elif attr_record.openerp_id.ttype== 'many2many':
                            option_ids = []
                            if isinstance(attr_value,basestring) :
                                attr_value = attr_value.split(',')
                            magento_attribute_option_domain.append(('magento_id','in',attr_value))
                            magento_options = self.env['magento.attribute.option'].search(magento_attribute_option_domain)
                            option_ids = [magento_option.openerp_id.id for magento_option in magento_options if magento_option.openerp_id]
                            if option_ids:
                                result.update({openerp_field_name:[(4,option_ids)]})
                        elif attr_record.openerp_id.ttype=='boolean':
                            if attr_value and int(attr_value) :
                                result.update({openerp_field_name:True})
                            else :
                                result.update({openerp_field_name:False})
                        else :
        
                            result.update({openerp_field_name:attr_value})
                            
        return result
                      
@magento
class ProductImporter(MagentoImporter):
    _model_name = ['magento.product.product']

    _base_mapper = ProductImportMapper

    def _import_bundle_dependencies(self):
        """ Import the dependencies for a Bundle """
        bundle = self.magento_record['_bundle_data']
        for option in bundle['options']:
            for selection in option['selections']:
                self._import_dependency(selection['product_id'],
                                        'magento.product.product')

#     def _import_dependencies(self):
#         """ Import the dependencies for the record"""
#         record = self.magento_record
#         #import related attributes 
#         attributes = record.keys()
#         for mag_attribute_code in attributes :
#             attribute = self.env['magento.product.attribute'].search([('backend_id','=',self.backend_record.id),
#                                                           ('attribute_code','=',str(mag_attribute_code))])
#             if not attribute :
#                 self._import_dependency(mag_attribute_code,'magento.product.attribute')
#         record.update({'category_ids':record.get('custom_attributes').pop('category_ids')})
#         #import attribute set
#         self._import_dependency(record.get('mag_category_id'),'magento.attribute.set')       
#         # import related categories
#         for mag_category_id in record['category_ids']:
#             self._import_dependency(mag_category_id,
#                                     'magento.product.category')
#         if record['type_id'] == 'bundle':
#             self._import_bundle_dependencies()

    def _import_dependencies(self):
        """ Import the dependencies for the record"""
        record = self.magento_record
        self._import_dependency(record.get('attribute_set_id'),'magento.attribute.set') 
        set_binder = self.binder_for('magento.attribute.set')     
        magento_attribute_set_id=set_binder.to_openerp(record.get('set'),browse=True)
        #ADDED BY AARTI
        magento_product_groups_ids=magento_attribute_set_id.magento_group_ids
        magento_custom_attribute={}
        for groups in magento_product_groups_ids:
            for group_attributes in groups.magento_attribute_ids:
                custom_attributes={}
                magento_custom_attribute.update({group_attributes.attribute_code:record.get(group_attributes.attribute_code)})
        self.magento_record.update({'custom_attributes':magento_custom_attribute})
        
                    
#         attributes = record['custom_attributes'].keys()
#         for mag_attribute_code in attributes:
#             attribute = self.env['magento.product.attribute'].search([('backend_id','=',self.backend_record.id),
#                                                           ('attribute_code','=',str(mag_attribute_code))])
#             if not attribute :
#                 self._import_dependency(mag_attribute_code,'magento.product.attribute')
        #import attribute set
        # import related categories
            
        for mag_category_id in record.get('category_ids',[]):
            self._import_dependency(mag_category_id,
                                    'magento.product.category')
        if record['type_id'] == 'bundle':
            self._import_bundle_dependencies()
            
            
    def _validate_product_type(self, data):
        """ Check if the product type is in the selection (so we can
        prevent the `except_orm` and display a better error message).
        """
        product_type = data['product_type']
        product_model = self.env['magento.product.product']
        types = product_model.product_type_get()
        available_types = [typ[0] for typ in types]
        if product_type not in available_types:
            raise InvalidDataError("The product type '%s' is not "
                                   "yet supported in the connector." %
                                   product_type)

    def _must_skip(self):
        """ Hook called right after we read the data from the backend.

        If the method returns a message giving a reason for the
        skipping, the import will be interrupted and the message
        recorded in the job (if the import is called directly by the
        job, not by dependencies).

        If it returns None, the import will continue normally.

        :returns: None | str | unicode
        """
        if self.magento_record['type_id'] == 'configurable':
            return _('The configurable product is not imported in OpenERP, '
                     'because only the simple products are used in the sales '
                     'orders.')

    def _validate_data(self,data):
        """ Check if the values to import are correct

        Pro-actively check before the ``_create`` or
        ``_update`` if some fields are missing or invalid

        Raise `InvalidDataError`
        """
        self._validate_product_type(data)
        
        
    def _check_existing_product(self,data):
        sku = data.get('default_code')

        #product = self.env['product.product'].search([('default_code','=',sku),('magento_bind_ids.backend_id','=',data.get('backend_id'))],limit=1)
        products = self.env['product.product'].search([('default_code','=',sku)])
        vals = {}
        for product in products :
            if not product.magento_bind_ids :
                vals = {
                        'magento_id':data.get('magento_id'),
                        'backend_id':data.get('backend_id'),
                        'created_at':data.get('created_at'),
                        'updated_at':data.get('updated_at'),
                        'openerp_id':product.id,
                        'attribute_set_id':data.get('attribute_set_id'),
                        }
                break
            """
            if product.magento_bind_ids :
                for magento_product in product.magento_bind_ids:
                    if magento_product.backend_id.id == data.get('backend_id'):
                        vals = {
                                'magento_id':data.get('magento_id'),
                                'backend_id':data.get('backend_id'),
                                'created_at':data.get('created_at'),
                                'updated_at':data.get('updated_at'),
                                'openerp_id':product.id
                        }
                        break
            """
        data = vals and vals or data
        return data

    def _create(self, data):
        """ Create the OpenERP record """
        # special check on data before import
        self._validate_data(data)
        data = self._check_existing_product(data)
        model = self.model.with_context(connector_no_export=True)
        binding = model.create(data)
        _logger.debug('%d created from magento %s', binding, self.magento_id)
        return binding

    def _after_import(self,binding_id):
        """ Hook called at the end of the import """
        translation_importer = self.unit_for(TranslationImporter,self.model._name)
        translation_importer.run(self.magento_id, binding_id.id,
                                  mapper_class=ProductImportMapper)
        image_importer = self.unit_for(MagentoImageImporter,'magento.product.image') # image_importer : <openerp.addons.magentoerpconnect.product.CatalogImageImporter object at 0xac3186c>
        all_images = self.backend_adapter.get_images(self.magento_id)
        if all_images:
            for one_image in all_images: 
                image_importer.run(self.magento_id,one_image.get('file',''))
                binder = self.binder_for('magento.product.product')
                openerp_id = binder.to_openerp(self.magento_id,unwrap=True)
        #For Price Import website wise
        from odoo.addons.odoo_magento1_ept.models.product.product_price import ProductPriceImporter
        productpriceimporter = self.unit_for(ProductPriceImporter,'magento.product.price')  
        for website in binding_id.website_ids:
                productpriceimporter.run(self.magento_id,website.id)   
                
ProductImport = ProductImporter  # deprecated

@magento
class IsActiveProductImportMapper(ImportMapper):
    _model_name = 'magento.product.product'

    @mapping
    def is_active(self,record):
        """Check if the product is active in Magento
        and set active flag in OpenERP
        status == 1 in Magento means active"""
        return {'active': (record.get('status') == '1')}

@magento
class BundleProductImportMapper(ImportMapper):
    _model_name = 'magento.product.product'


@magento
class ProductInventoryExporter(Exporter):
    _model_name = ['magento.product.product']

    _map_backorders = {'use_default': 0,
                       'no': 0,
                       'yes': 1,
                       'yes-and-notification': 2,
                       }

    def _get_data(self, product, fields):
        result = {}
        if 'magento_qty' in fields:
            result.update({
                'qty': product.magento_qty,
                # put the stock availability to "out of stock"
                'is_in_stock': int(product.magento_qty > 0)
            })
        if 'manage_stock' in fields:
            manage = product.manage_stock
            result.update({
                'manage_stock': int(manage == 'yes'),
                'use_config_manage_stock': int(manage == 'use_default'),
            })
        if 'backorders' in fields:
            backorders = product.backorders
            result.update({
                'backorders': self._map_backorders[backorders],
                'use_config_backorders': int(backorders == 'use_default'),
            })
        return result

    def run(self, binding_id, fields):
        """ Export the product inventory to Magento """
        product = self.model.browse(binding_id)
        magento_id = self.binder.to_backend(product.id)
        data = self._get_data(product, fields)
        self.backend_adapter.update_inventory(magento_id, data)


ProductInventoryExport = ProductInventoryExporter  # deprecated

@magento
class ProductProductDeleter(MagentoDeleter):
    """ product deleter for Magento """
    _model_name = ['magento.product.product']

           
@magento
class ProductExporter(MagentoExporter):
    _model_name = 'magento.product.product'
    
    def _export_dependencies(self):
        attribute_set = self.binding_record.attribute_set_id
        vals = {
               'attribute_set_name':attribute_set.name,
                }
        self._export_dependency(attribute_set,'magento.attribute.set',binding_extra_vals=vals)
        for group in attribute_set.attribute_group_ids :
            for attribute in group.attribute_ids :
                self._export_dependency(attribute.attribute_id,'magento.product.attribute')
        product_categs = self.binding_record.categ_ids
        #product_categs += self.binding_record.categ_id
        for product_categ in product_categs :
            self._export_dependency(product_categ,'magento.product.category')
        
    
    def _create(self, data):
        """ Create the Magento record """
        if  not data.get('sku',False):
            raise FailedJobError("SKU not found.")
        filters = {'sku':data.get('sku','')}
        magento_ids = self.backend_adapter.search(filters=filters)
        if magento_ids:
            res = self.backend_adapter.write(magento_ids[0],data)
            return magento_ids[0]
        else:
            res = self.backend_adapter.create(data) 
        return res
    
    def _after_export(self):
        website_prices = self.binding_record.magento_product_price_ids
        #For Price export website wise
        from odoo.addons.odoo_magento1_ept.models.product.product_price import ProductPriceExporter
        PriceExporter = self.unit_for(ProductPriceExporter,'magento.product.price')
        
        if website_prices :
            for website_price in website_prices :
                if website_price.backend_id.id == self.backend_record.id :
                    PriceExporter.run(website_price.id)
                    

@magento
class ProductProductExportMapper(ExportMapper):
    _model_name = 'magento.product.product'

    #TODO FIXME
    direct = [('name', 'name'),
              ('weight', 'weight'),
              ('list_price', 'price'),
              ('default_code', 'sku'),
#             ('created_at', 'created_at'),
#             ('updated_at', 'updated_at'),
              ]
    

    @mapping
    def sku(self, record):
        sku = record.default_code
        if not sku:
            raise MappingError("The product attribute default code cannot be empty.")
        return {'sku': sku}
    
    @changed_by('attribute_set_id')    
    @mapping
    def attribute_set(self, record):
        binder = self.binder_for('magento.attribute.set')
        binding_id = binder.to_backend(record.attribute_set_id.id, wrap=True)
        return {'attribute_set_id': binding_id}
    
    #Dimpal 29 june 2017    
    @mapping
    def website_ids(self, record):
        website_ids = []
        for website_id in record.website_ids:
            magento_id = website_id.magento_id
            website_ids.append(magento_id)
        return {'website_ids': website_ids}
     
    # Dimpal 29 june 2017 
    @mapping
    def category(self, record):
        categ_ids = []
        """
        if record.categ_id:
            for m_categ in record.categ_id.magento_bind_ids:
                if m_categ.backend_id.id == self.backend_record.id:
                    categ_ids.append(m_categ.magento_id)
        """
        for categ in record.categ_ids:
            for m_categ in categ.magento_bind_ids:
                if m_categ.backend_id.id == self.backend_record.id:
                    categ_ids.append(m_categ.magento_id)
        return {'categories': categ_ids}
        
    @mapping
    def get_product_attribute_option(self, record):
        result = {}
        fields = self.options.get('fields',[])
        for_create = self.options.get('for_create',False)
        custom_attributes = []
        option_binder = self.binder_for('magento.attribute.option')
        categ_binder = self.binder_for('magento.product.category')
        for group in record.attribute_group_ids:
            for attribute in group.attribute_ids:
                magento_attribute = None
                #TODO maybe adding a get_bind function can be better
                for bind in attribute.magento_bind_ids:
                    if bind.backend_id.id == self.backend_record.id:
                        magento_attribute = bind
                if not magento_attribute:
                    continue
                odoo_field_name = magento_attribute.openerp_id and magento_attribute.openerp_id.field_id and magento_attribute.openerp_id.field_id.name or None
                #if for_create is true then pass all fields to Magento otherwise only updated fields will be pass to Magento
                
                if not for_create and odoo_field_name not in fields :
                    continue
                if attribute.ttype == 'many2one':
                    option = record[attribute.name]
                    if option:
                        result[magento_attribute.attribute_code] = \
                            option_binder.to_backend(option.id, wrap=True)
                    elif magento_attribute.default_value : 
                        result[magento_attribute.attribute_code]=magento_attribute.default_value
                    else:
                        continue
                elif attribute.ttype == 'many2many':
                    if magento_attribute.attribute_code == 'category_ids' :
                        binder = categ_binder
                    else :
                        binder = option_binder
                    options = record[attribute.name]
                    if options:
                        result[magento_attribute.attribute_code] = \
                            [binder.to_backend(option.id, wrap=True) for option in options]
                    else:
                        continue
                    
                elif attribute.ttype == 'boolean':
                    if record[attribute.name] :
                        result[magento_attribute.attribute_code]=1
                    else :
                        result[magento_attribute.attribute_code]=0
                elif magento_attribute.attribute_code == 'special_price' and not record[attribute.name]:
                    #to do not export to special 0 because if special price is 0 then in order item price display 0.
                    continue
                else:
                    #TODO add support of lang
                    if not record[attribute.name] and magento_attribute.default_value :
                        result[magento_attribute.attribute_code] = magento_attribute.default_value
                    else :
                        if attribute.ttype in ('text','char') :
                            result[magento_attribute.attribute_code] = record[attribute.name] or ''
                        else :
                            result[magento_attribute.attribute_code] = record[attribute.name]
        #main_attrs = ["sku","name","attribute_set_id","price","status","visibility","type_id","created_at","updated_at","weight"]
        #custom_attrs_list = set(result.keys()).difference(main_attrs)
        for attribute in result:
            if result[attribute]==None:
                del result[attribute]
        return result

    def finalize(self, map_record, values):
        # Here Needs to map all fields which will not take data from attribute struture. like mapped sku with default_code etc..
        #fields = self.options.get('fields',[])
        for_create = self.options.get('for_create',False)
        if for_create :
            record=map_record.source
            values['name']= values.get('name') or  record.name
            values['sku'] = values.get('sku') or  record.default_code
            values['weight'] = values.get('weight',0.0) or  record.weight        
            values.update({                
                    'price': record.list_price and record.list_price or values.get('price',0.0),
                    'type_id': record.product_type,                
                    })
        return values

# fields which should not trigger an export of the products
# but an export of their inventory
INVENTORY_FIELDS = ('manage_stock',
                    'backorders',
                    'magento_qty',
                    )
@on_record_write(model_names='magento.product.product')
def magento_product_modified(session, model_name, record_id, vals):
    if session.context.get('connector_no_export'):
        return
    if session.env[model_name].browse(record_id).no_stock_sync:
        return
    '''
    if 'website_ids' in vals :
        export_product_website_link.delay(session,model_name,record_id,priority=10)
    '''
    inventory_fields = list(set(vals).intersection(INVENTORY_FIELDS))
    if inventory_fields:
        export_product_inventory.delay(session, model_name,
                                       record_id, fields=inventory_fields,
                                       priority=20)


@job(default_channel='root.magento')
@related_action(action=unwrap_binding)
def export_product_inventory(session, model_name, record_id, fields=None):
    """ Export the inventory configuration and quantity of a product. """
    product = session.env[model_name].browse(record_id)
    backend_id = product.backend_id.id
    env = get_environment(session, model_name, backend_id)
    inventory_exporter = env.get_connector_unit(ProductInventoryExporter)
    return inventory_exporter.run(record_id, fields)
'''
@magento
class ProductWebsiteLinkExporter(Exporter):
    _model_name='magento.product.product'
    
    def run(self,binding_id):
        product = self.model.browse(binding_id)
        magento_id = self.binder.to_backend(product.id)
        sku = product.default_code
        if magento_id :
            for website in product.website_ids :
                self.backend_adapter.website_link(sku,website.magento_id)


@job(default_channel='root.magento')
@related_action(action=unwrap_binding)
def export_product_website_link(session, model_name, record_id):
    """ Export the product website link configuration of a product. """
    product = session.env[model_name].browse(record_id)
    backend_id = product.backend_id.id
    env = get_environment(session, model_name, backend_id)
    website_link_exporter = env.get_connector_unit(ProductWebsiteLinkExporter)
    return website_link_exporter.run(record_id)
'''