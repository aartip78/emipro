# -*- coding: utf-8 -*-
##############################################################################
#
#    Author: Guewen Baconnier
#    Copyright 2013 Camptocamp SA
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

import logging
import xmlrpclib
from datetime import datetime, timedelta
from odoo import models, fields,api,_
from odoo.exceptions import ValidationError
from odoo.addons.odoo_magento1_ept.models.unit.mapper import (mapping,
                                                  ImportMapper,
                                                  ExportMapper,
                                                  )
from odoo.addons.odoo_magento1_ept.models.backend.exception import (IDMissingInBackend,
                                                MappingError,
                                                )
from odoo.addons.odoo_magento1_ept.models.unit.backend_adapter import (GenericAdapter,
                                   MAGENTO_DATETIME_FORMAT,
                                   )
from odoo.addons.odoo_magento1_ept.models.unit.import_synchronizer import (DelayedBatchImporter,
                                       MagentoImporter,
                                       TranslationImporter,
                                       )
from odoo.addons.odoo_magento1_ept.models.unit.delete_synchronizer import MagentoDeleter
from odoo.addons.odoo_magento1_ept.models.unit.export_synchronizer import MagentoExporter
from odoo.addons.odoo_magento1_ept.models.backend.backend import magento
from odoo.addons.odoo_magento1_ept.models.api_request import req
from odoo.addons.odoo_magento1_ept.models.search_criteria import create_search_criteria
import urllib2
import base64
from odoo.addons.odoo_magento1_ept.models.backend.magento_model import IMPORT_DELTA_BUFFER
from odoo.addons.odoo_magento1_ept.models.product.product_attribute import field_mapping
from odoo.addons.odoo_magento1_ept.models.backend.exception import FailedJobError


_logger = logging.getLogger(__name__)



class MagentoProductCategory(models.Model):
    _name = 'magento.product.category'
    _inherit = 'magento.binding'
    _inherits = {'product.category': 'openerp_id'}
    _description = 'Magento Product Category'
    MAGENTO_HELP = "This field is a technical / configuration field for " \
                   "the category on Magento. \nPlease refer to the Magento " \
                   "documentation for details. "
                   
    def get_custom_design(self):
        return [
                ('1','Magento Blank'),
                ('2','Magento Luma')
            ]


    @api.multi
    def _get_custom_design(self):
        return self.get_custom_design()

    @api.multi
    def get_page_layout(self):
        return [
            ('empty', 'Empty'),
            ('one_column', '1 colmun'),
            ('two_columns_left', '2 columns with left bar'),
            ('two_columns_right', '2 columns with right bar'),
            ('three_columns', '3 columns'),
            ]

    @api.multi
    def _get_page_layout(self):
        return self.get_page_layout()


    openerp_id = fields.Many2one(comodel_name='product.category',string='Product Category',required=True,ondelete='cascade')
    description = fields.Text(translate=True)
    magento_parent_id = fields.Many2one(comodel_name='magento.product.category',string='Magento Parent Category',ondelete='cascade',)
    magento_child_ids = fields.One2many(comodel_name='magento.product.category',inverse_name='magento_parent_id',string='Magento Child Categories',)
    #==== General Information ====
    thumbnail_like_image=fields.Boolean(string='Thumbnail like main image',default=True)
    thumbnail_binary=fields.Binary(string='Thumbnail')
    thumbnail=fields.Char(string='Thumbnail name',size=100, help=MAGENTO_HELP)
    image_binary=fields.Binary(string='Image')
    image=fields.Char(string='Image name', size=100, help=MAGENTO_HELP)
    meta_title=fields.Char(string='Title (Meta)', size=75, help=MAGENTO_HELP)
    meta_keywords=fields.Text(string='Meta Keywords', help=MAGENTO_HELP)
    meta_description=fields.Text(string='Meta Description', help=MAGENTO_HELP)
    url_key=fields.Char(string='URL-key', size=100, readonly="True")
        #==== Display Settings ====
    display_mode=fields.Selection([
                                   ('PRODUCTS', 'Products Only'),
                                   ('PAGE', 'Static Block Only'),
                                   ('PRODUCTS_AND_PAGE', 'Static Block & Products')],
                                  string='Display Mode', required=True, help=MAGENTO_HELP,default='PRODUCTS')
    
    is_anchor=fields.Boolean(string='Anchor?', help=MAGENTO_HELP,default=True)
    use_default_available_sort_by=fields.Boolean(string='Default Config For Available Sort By', help=MAGENTO_HELP,default=True)

   #TODO use custom attribut for category

        #'available_sort_by': fields.sparse(
        #    type='many2many',
        #    relation='magerp.product_category_attribute_options',
        #    string='Available Product Listing (Sort By)',
        #    serialization_field='magerp_fields',
        #    domain="[('attribute_name', '=', 'sort_by'), ('value', '!=','None')]",
        #    help=MAGENTO_HELP),
        #filter_price_range landing_page ?????????????
    default_sort_by=fields.Selection([
                    ('_', 'Config settings'), #?????????????
                    ('position', 'Best Value'),
                    ('name', 'Name'),
                    ('price', 'Price')],
                    string='Default sort by', required=True, help=MAGENTO_HELP,default='_')

        #==== Custom Design ====
    custom_apply_to_products=fields.Boolean(string='Apply to products', help=MAGENTO_HELP)
    custom_design=fields.Selection( _get_custom_design,string='Custom design',help=MAGENTO_HELP)
    custom_design_from=fields.Date(string='Active from', help=MAGENTO_HELP)
    custom_design_to=fields.Date(string='Active to', help=MAGENTO_HELP)
    custom_layout_update=fields.Text(string='Layout update', help=MAGENTO_HELP)
    page_layout=fields.Selection(_get_page_layout,string='Page layout', help=MAGENTO_HELP)
    is_active= fields.Boolean(string="Is Active",help=MAGENTO_HELP,default=True)


    #Changed by Dimpal : 22 june 2017
    include_in_menu = fields.Boolean("Include in Navigation Menu",default=True)
    
    _sql_constraints = [
        ('magento_img_uniq', 'unique(backend_id, image)',
         "'Image file name' already exists : must be unique"),
        ('magento_thumb_uniq', 'unique(backend_id, thumbnail)',
         "'thumbnail name' already exists : must be unique"),
    ]



class ProductCategory(models.Model):
    _inherit = 'product.category'

    @api.multi
    def _get_parent_magento_backend(self):
        for record in self:
            magento_backend = False
            if record.parent_id and record.parent_id.magento_bind_ids:
                magento_backend = record.parent_id.magento_bind_ids[0].backend_id.id
            record.parent_backend_id = magento_backend

    @api.one
    @api.constrains('magento_bind_ids')
    def _check_magento_product_category_exist(self):
        #This constaint is for product category will bind with only one magento product category
        if len(self.magento_bind_ids) > 1 :
            raise ValidationError(_('Product Category already have Magento product category.'))

    magento_bind_ids = fields.One2many(comodel_name='magento.product.category',inverse_name='openerp_id',string="Magento Product Category",)
    parent_backend_ids = fields.Many2many('magento.backend')
    
    @api.onchange('parent_id')
    def onchange_parent_id(self):
        magento_backends = self.env['magento.backend'].search([])
        parent_backend_ids = magento_backends.ids
        if self.parent_id and self.parent_id.magento_bind_ids :
            parent_backend_ids =  [self.parent_id.magento_bind_ids[0].backend_id.id]
        self.parent_backend_ids = parent_backend_ids

@magento
class ProductCategoryAdapter(GenericAdapter):
    _model_name = 'magento.product.category'
    _magento_model = 'catalog_category'
    _admin_path = '/{model}/index/'
    _path = '/V1/categories'

    def _call(self, method, arguments):
        try:
            return super(ProductCategoryAdapter, self)._call(method, arguments)
        except xmlrpclib.Fault as err:
            # 101 is the error in the Magento API
            # when the category does not exist
            if err.faultCode == 102:
                raise IDMissingInBackend
            else:
                raise
    
    def search(self, filters=None, from_date=None, to_date=None):
        """ Search records according to some criteria and return a
        list of ids

        :rtype: list
        """
        try:
            if filters is None:
                filters = {}
    
            dt_fmt = MAGENTO_DATETIME_FORMAT
            if from_date is not None:
                filters.setdefault('updated_at', {})
                # updated_at include the created records
                filters['updated_at']['from'] = from_date.strftime(dt_fmt)
            if to_date is not None:
                filters.setdefault('updated_at', {})
                filters['updated_at']['to'] = to_date.strftime(dt_fmt)
            result= self._call('oerp_catalog_category.search',
                              [filters] if filters else [{}])
            
            return result    
        except xmlrpclib.Fault as err:   
                 
            if err.faultCode in[3]:
                
                raise FailedJobError(" Installation Missing!\n Magento plugin seems missing on Magento, Please install plugin on Magento and try again.")
                 

        return True
                 

        
        
    def tree(self, parent_id=None, storeview_id=None):
        """ Returns a tree of product categories

        :rtype: dict
        """
        def filter_ids(tree):
            children = {}
            if tree['children']:
                for node in tree['children']:
                    children.update(filter_ids(node))
            category_id = {tree['category_id']: children}
            return category_id
        if parent_id:
            parent_id = int(parent_id)
        tree = self._call('%s.tree' % self._magento_model,
                          [parent_id, storeview_id])
    
        return filter_ids(tree)   
    
    def read(self, id, storeview_id=None, attributes=None):
        """ Returns the information of a record

        :rtype: dict
        """
        result= self._call('%s.info' % self._magento_model,
                          [int(id), storeview_id, attributes])
       
        return  result
    # changed by Dimpal : 22 june 2017
    
    def create(self,data):
#         data = {
#                 'category':data
#                 }
#         res = super(ProductCategoryAdapter,self).create(data)
        res = self._call('catalog_category.create', [data.get('parent_id'),data])
        
        return res
#         return res.get('id')
    
    def write(self,magento_id,data):
        data = {
                'category':data
                }
        content = super(ProductCategoryAdapter,self).write(magento_id,data)
        
        return

    def move(self, categ_id, parent_id, after_categ_id=None):
        result= self._call('%s.move' % self._magento_model,
                          [categ_id, parent_id, after_categ_id])
        print"move",result
        return result
    
    def get_assigned_product(self, categ_id):
        result= self._call('%s.assignedProducts' % self._magento_model,
                          [categ_id])
        print "get_assigned_product",result
        return result
    
    def assign_product(self, categ_id, product_id, position=0):
        result= self._call('%s.assignProduct' % self._magento_model,
                          [categ_id, product_id, position, 'id'])
        return result
        
    def update_product(self, categ_id, product_id, position=0):
        result= self._call('%s.updateProduct' % self._magento_model,
                          [categ_id, product_id, position, 'id'])
        return result
       
    def remove_product(self, categ_id, product_id):
        result= self._call('%s.removeProduct' % self._magento_model,
                          [categ_id, product_id, 'id'])
        return result

@magento
class ProductCategoryBatchImporter(DelayedBatchImporter):
    """ Import the Magento Product Categories.

    For every product category in the list, a delayed job is created.
    A priority is set on the jobs according to their level to rise the
    chance to have the top level categories imported first.
    """
    _model_name = ['magento.product.category']

    def _import_record(self, magento_id, priority=None):
        """ Delay a job for the import """
        super(ProductCategoryBatchImporter, self)._import_record(
            magento_id, priority=priority)

    def run(self, filters=None):
        """ Run the synchronization """
        from_date = filters.pop('from_date', None)
        to_date = filters.pop('to_date', None)
        if from_date or to_date:
            updated_ids = self.backend_adapter.search(filters,
                                                      from_date=from_date,
                                                      to_date=to_date)
        else:
            updated_ids = None

        base_priority = 10

        def import_nodes(tree, level=0):
            for node_id, children in tree.iteritems():
                # By changing the priority, the top level category has
                # more chance to be imported before the childrens.
                # However, importers have to ensure that their parent is
                # there and import it if it doesn't exist
                if updated_ids is None or node_id in updated_ids:
                    self._import_record(node_id, priority=base_priority+level)
                import_nodes(children, level=level+1)
        tree = self.backend_adapter.tree()
        import_start_time = to_date or datetime.now()
        next_time = import_start_time - timedelta(seconds=IMPORT_DELTA_BUFFER)
        next_time = fields.Datetime.to_string(next_time)
        self.backend_record.write({'import_categories_from_date': next_time})
        import_nodes(tree)


ProductCategoryBatchImport = ProductCategoryBatchImporter  # deprecated


@magento
class ProductCategoryImporter(MagentoImporter):
    _model_name = ['magento.product.category']

    def _import_dependencies(self):
        """ Import the dependencies for the record"""
        record = self.magento_record
        # import parent category
        # the root category has a 0 parent_id
        if record.get('parent_id'):
            parent_id = record['parent_id']
            if self.binder.to_openerp(parent_id) is None:
                importer = self.unit_for(MagentoImporter)
                importer.run(parent_id)

    def _after_import(self, binding):
        """ Hook called at the end of the import """
        translation_importer = self.unit_for(TranslationImporter)
        translation_importer.run(self.magento_id, binding.id)


ProductCategoryImport = ProductCategoryImporter  # deprecated


@magento
class ProductCategoryImportMapper(ImportMapper):
    _model_name = 'magento.product.category'

    direct = [
        ('description', 'description'),
        ('meta_title','meta_title'),
        ('meta_keywords','meta_keywords'),
        ('meta_description','meta_description'),
        ('image','image'),
        ('url_key','url_key'),
        ('is_anchor','is_anchor'),
        ('custom_apply_to_products','custom_apply_to_products'),
        ('custom_design_from','custom_design_from'),
        ('custom_design_to','custom_design_to'),
        ('custom_layout_update','custom_layout_update'),
        ('page_layout','page_layout')
    ]

    @mapping
    def name(self, record):
        """
        if record['level'] == '0':  # top level category; has no name
            return {'name': self.backend_record.name}
        #level=0 is int and has name also so removed this.
        """
        if record['name']:  # may be empty in storeviews
            return {'name': record['name']}
        
    @mapping
    def magento_id(self, record):
        return {'magento_id': record['category_id']}

    @mapping
    def backend_id(self, record):
        return {'backend_id': self.backend_record.id}

    @mapping
    def parent_id(self, record):
        if not record.get('parent_id'):
            return
        binder = self.binder_for()
        category_id = binder.to_openerp(record['parent_id'], unwrap=True)
        mag_cat_id = binder.to_openerp(record['parent_id'])

        if category_id is None:
            raise MappingError("The product category with "
                               "magento id %s is not imported." %
                               record['parent_id'])
        return {'parent_id': category_id, 'magento_parent_id': mag_cat_id}
    
    @mapping
    def display_mode(self,record):
        if record.get('display_mode'):
            return {'display_mode':record.get('display_mode')}
        return 
    
    @mapping
    def boolean_field(self,record):
        res = {}
        fields = ['is_anchor','custom_apply_to_products']
        for field in fields :
            if record.get(field)=='0':
                res.update({field:False})
            if not record.get('is_anchor'):
                res.update({'is_anchor':True})
        return res
    
    @mapping
    def image(self,record):
        url = record.get('image')
        base_media_url = ''
        if url :
            backend_id = self.backend_record.id
            storeviews = self.env['magento.storeview'].search([('backend_id','=',backend_id)])
            for storeview in storeviews:
                if storeview.base_media_url :
                    base_media_url = storeview.base_media_url
                    break
            if not base_media_url :
                base_media_url = "%s/media"%(self.backend_record.location)
            url = "%s/catalog/category/%s"%(base_media_url,url)
            response = urllib2.urlopen(url)
            binary = base64.b64encode(response.read())
            return {'image_binary':binary}
        return
    
    @mapping
    def default_sort_by(self,record):
        if record.get('default_sort_by'):
            return {'default_sort_by':record['default_sort_by']}

@magento
class ProductCategoryDeleteSynchronizer(MagentoDeleter):
    """ Product category deleter for Magento """
    _model_name = ['magento.product.category']


@magento
class ProductCategoryExporter(MagentoExporter):
    _model_name = ['magento.product.category']
 
    def _export_dependencies(self):
        """Export parent of the category"""
        #TODO FIXME
        env = self.environment
        record = self.binding_record
        binder = self.get_binder_for_model()
        if record.magento_parent_id:
            mag_parent_id = record.magento_parent_id.id
            if binder.to_backend(mag_parent_id) is None:
                exporter = env.get_connector_unit(ProductCategoryExporter)
                exporter.run(mag_parent_id)
        elif record.openerp_id.parent_id:
            parent = record.openerp_id.parent_id
            self._export_dependency(parent,'magento.product.category')
            """
            if binder.to_backend(parent.id, wrap=True) is None:
                exporter = env.get_connector_unit(ProductCategoryExporter)
                exporter.run(parent.magento_parent_id.id)
            """
        
        return True
    
    def create_custom_attribute_vals(self,data):
        custom_attributes = ['description','meta_title','meta_keywords','meta_description','is_anchor','image','url_key','custom_design','display_mode','custom_design_from','custom_design_to','custom_layout_update','page_layout','default_sort_by']
        attributes = []
        for attribute in custom_attributes :
            if data.has_key(attribute) :
                attributes.append({'attribute_code':attribute,'value':data.pop(attribute)})
        if attributes :
            data.update({'custom_attributes':attributes})
        return data
    
#     Changed by Dimpal 23 june 2017
    def _create(self, data):
        #data = self.create_custom_attribute_vals(data)
        return super(ProductCategoryExporter,self)._create(data)
    
    def _update(self, data):
        #data = self.create_custom_attribute_vals(data)
        return super(ProductCategoryExporter,self)._update(data)
    
    
        
    
@magento
class ProductCategoryExportMapper(ExportMapper):
    _model_name = 'magento.product.category'

    direct = [('description', 'description'),
              #change that to mapping top level category has no name
              ('is_active', 'is_active'),
              ('meta_title', 'meta_title'),
              ('meta_keywords', 'meta_keywords'),
              ('meta_description', 'meta_description'),
              ('display_mode', 'display_mode'),
              ('is_anchor', 'is_anchor'),
              #('use_default_available_sort_by', 'use_default_available_sort_by'),
              ('custom_design', 'custom_design'),
              ('custom_design_from', 'custom_design_from'),
              ('custom_design_to', 'custom_design_to'),
              ('custom_layout_update', 'custom_layout_update'),
              ('page_layout', 'page_layout'),
              ('include_in_menu','include_in_menu'),
             ]

    @mapping
    def sort(self, record):
        return {'default_sort_by':'price', 'available_sort_by': ['price']}


    @mapping
    def parent(self, record):
        """ Magento root category's Id equals 1 """
        if not record.magento_parent_id:
            openerp_parent = record.parent_id
            binder = self.get_binder_for_model('magento.product.category')
            parent_id = binder.to_backend(openerp_parent.id, wrap=True)
        else:
            parent_id = record.magento_parent_id.magento_id
        if not parent_id:
            parent_id = 1
        return {'parent_id':parent_id}
    
    @mapping
    def name(self,record):
        return {'name':record.name}

    @mapping
    def image(self, record):
        res = {}
        if record.image_binary:
            res.update({'image': record.image,
                        #'image_binary': record.image_binary
                        })
        #if record.thumbnail_like_image == True :
        #    res.update({'thumbnail': record.image,})
        #elif record.thumbnail:
        #    res.update({'thumbnail': record.thumbnail,
        #                'thumbnail_binary': record.thumbnail_binary})
        return res

    """
    @mapping
    def country_id(self, record):
        result = {'applicable_countries':0,'spcific_countries':[]}
        if len(record.country_id) > 0:
            result['applicable_countries'] = 1
            result['spcific_countries'] = [x.code for x in record.country_id]
                
        return result
    """