import xmlrpclib
from odoo import models,fields,api    
from odoo.addons.odoo_magento1_ept.models.backend.backend import magento
from odoo.addons.odoo_magento1_ept.models.unit.backend_adapter import GenericAdapter
from odoo.addons.odoo_magento1_ept.models.unit.import_synchronizer import (DelayedBatchImporter,
                                                                          MagentoImporter)
from odoo.addons.odoo_magento1_ept.models.unit.mapper import (ExportMapper,
                                                             ImportMapper,
                                                             mapping)
from odoo.addons.odoo_magento1_ept.models.unit.delete_synchronizer import MagentoDeleter
from odoo.addons.odoo_magento1_ept.models.unit.export_synchronizer import MagentoExporter
from odoo.addons.odoo_magento1_ept.models.backend.exception import FailedJobError
from odoo.addons.odoo_magento1_ept.models.backend.connector import get_environment
from odoo.addons.odoo_magento1_ept.models.backend.session import ConnectorSession
from odoo.addons.odoo_magento1_ept.models.api_request import req
from odoo.addons.odoo_magento1_ept.models.search_criteria import create_search_criteria
from odoo.addons.odoo_magento1_ept.python_library.php import Php
import logging
from odoo.addons.odoo_magento1_ept.models.backend.exception import FailedJobError

_logger = logging.getLogger(__name__)
    
class attribute_set(models.Model):
    _name = "attribute.set"
    _description = "Attribute Set"
    _rec_name = "display_name"
    
    name=fields.Char(string='Name',size=128,required=True,translate=True)
    attribute_group_ids=fields.One2many('attribute.group','attribute_set_id',string='Attribute Groups')
    model_id=fields.Many2one(comodel_name='ir.model',string='Model',default="_get_default_model",required=True)
    magento_bind_ids=fields.One2many(comodel_name='magento.attribute.set',inverse_name='openerp_id',string='Magento Bindings')
    display_name = fields.Char('Name', compute='_get_display_name')
        
    @api.model
    def _get_default_model(self):
        context=dict(self._context) or {}
        if context and context.get('force_model'):
            model_id = self.env['ir.model'].search( [['model', '=', context['force_model']]])
            if model_id:
                return model_id[0]
        return None
    
    @api.multi
    def _get_display_name(self):
        for attribute_set in self:
            magento = attribute_set.magento_bind_ids and attribute_set.magento_bind_ids[0].backend_id.name or ''
            attribute_set.display_name = "%s - %s" % (
                attribute_set.name,magento)

class MagentoAttributeSet(models.Model):
    _name = 'magento.attribute.set'
    _description ="Magento attribute set"
    _inherit = 'magento.binding'
    _rec_name = 'attribute_set_name'

    openerp_id=fields.Many2one('attribute.set',string='Attribute set',ondelete='cascade')
    attribute_set_name=fields.Char(string='Name',size=64,required=True)
    sort_order=fields.Integer(string='Sort order',readonly=True)
    attribute_list=fields.Text(string="Attribute List")
    group_list=fields.Text(string="Group List")
    magento_group_ids=fields.One2many('magento.attribute.group','attribute_set_id')
    
    @api.multi
    def name_get(self):
        res = []
        for elm in self.read(['attribute_set_name']):
            res.append((elm['id'], elm['attribute_set_name']))
        return res

    _sql_constraints = [
        ('magento_uniq', 'unique(backend_id, openerp_id)',
         "An 'Attribute set' with the same ID on this Magento backend "
         "already exists"),
        ('unique_backend_magento_attribute_set', 'unique(attribute_set_name, backend_id)',
                 'There is already record exists for same magento attribute set and magento instance.')
                        ]

    @api.multi
    def create_new_field(self):
        ctx=self.env.context.copy()
        ctx.update({'connector_no_export': True})
        for attributeset in self:
            product_template_models = self.env['ir.model'].search([('model', '=', 'product.product')])
            product_template_model_id=[x.id for x in product_template_models]
            if not attributeset.openerp_id:
                new_set = self.env['attribute.set'].with_context(ctx).create({'model_id': product_template_model_id[0],
                                                                          'name': attributeset.attribute_set_name})
                new_set=new_set.id
                attributeset.with_context(ctx).write({'openerp_id': new_set})
            else:
                new_set = attributeset.openerp_id.id
            groups = self.env['magento.attribute.group'].search([('attribute_set_id', '=', attributeset.id)])

            for group in groups: 
                group_check = self.env['attribute.group'].search([('name', '=', group.name),('attribute_set_id', '=', new_set),
                                                                                ('model_id', '=',product_template_model_id[0])])
                group_check_id=[x.id for x in group_check]
                if group_check_id:
                    new_group_id = group_check_id[0]
                else:
                    new_group = self.env['attribute.group'].with_context(ctx).create({'name': group.name,
                                                                         'attribute_set_id': new_set,
                                                                         'sequence': group.sort_order,
                                                                         'model_id': product_template_model_id[0]})
                    new_group_id=new_group.id
                group.with_context(ctx).write({'openerp_id': new_group_id})

                if group.attribute_list:
                    check_attribute = eval(group.attribute_list)
                else:
                    check_attribute = {}
                attribute_ids = []
                for key in check_attribute.keys():
                    openerp_attribute_list = self.env['magento.product.attribute'].search([('backend_id','=',attributeset.backend_id.id),('magento_id', '=', key)])
                    for openerp_attribute in openerp_attribute_list: 
                        openerp_attribute.create_new_field()
                    for attribute in openerp_attribute_list:
                        if attribute.openerp_id:
                            check = self.env['attribute.location'].search([('attribute_id', '=', attribute.openerp_id.id),('attribute_group_id', '=', new_group_id)])
                            sequence = check_attribute.get(key)
                            if isinstance(sequence, list) :
                                sequence = 0                            
                            if not check:
                                self.env['attribute.location'].with_context(ctx).create({'attribute_id': attribute.openerp_id.id,
                                                                            'attribute_group_id': new_group_id,
                                                                            'sequence': sequence
                                                                            
                                                                           })
                            else :
                                check.write({'sequence': sequence})
                        attribute_ids.append(attribute.id)
                group.with_context(ctx).write({'magento_attribute_ids':[(6,0,attribute_ids)]})
        return True

@magento
class AttributeSetAdapter(GenericAdapter):
    _model_name = 'magento.attribute.set'
    _magento_default_model ='product_attribute_set'
    _magento_model = 'ol_catalog_product_attributeset'
#     _path="/V1/products/attribute-sets"
     
    def update(self, id, attribute_id):
        """ Add an existing attribute to an attribute set on the external system
        :rtype: boolean
        """
        return self._call('%s.attributeAdd' % self._magento_default_model,
                          [str(attribute_id),str(id)])
        
    def search(self, filters=None):
        """ Search records according and returns a list of ids
        :rtype: list
        """
#         filters = create_search_criteria(filters)
        try:    
            result=self._call('%s.list' % self._magento_model,[])
            set_id_list=[]
            for attributes in result:
                    
                set_id_list.append(attributes['attribute_set_id'])
            return set_id_list
        
        except xmlrpclib.Fault as err:   
                 
            if err.faultCode in[3]:
                
                raise FailedJobError(" Installation Missing! Magento plugin seems missing on Magento, Please install plugin on Magento and try again.")
            
    def read(self, id,storeview_id=None, attributes=None):
        """ Returns the information of a record
        :rtype: dict
        """
        try:   
            set_attribute_list = {}
            results = self._call('%s.list' % self._magento_model,[])
            groups = self._call('ol_catalog_product_attribute_group.list',[{'attribute_set_id': int(id)}])
            attribute_list = self._call('ol_catalog_product_attribute.list', [int(id)])
            result_groups = []
            for result in results:
                if result.get('attribute_set_id')==id:
                    for item in groups:
                        if item.get('attribute_set_id') == id:
                            group_attribute_list = {}
                            
                            for attribute in attribute_list:
                                if attribute['attribute_set_info'][result.get('attribute_set_id')].get('group_id') == item.get('attribute_group_id'):
                                    group_attribute_list[attribute.get('attribute_id')] = attribute.get('attribute_set_info').get(id).get('sort')
                            item['attribute_list'] = group_attribute_list
                            set_attribute_list.update(group_attribute_list)
                            result_groups.append(item)
                    result.update({'group_list':result_groups}) 
                    result.update({'attribute_list':set_attribute_list})
                    return result
              
                else :
                    continue
                return 
        
        except xmlrpclib.Fault as err:   
                 
            if err.faultCode in[3]:
                
                raise UserError(" Installation Missing! Magento plugin seems missing on Magento, Please install plugin on Magento and try again.")

       
    def create(self,data):
        return self._call('%s.create' % self._magento_default_model,
        [data['attribute_set_name'], data['skeletonSetId']])

    
#     def write(self,set_id,data):
#         skeleton_id = data.pop('skeletonSetId')
#          data = {
#                  'attributeSet':data
#                  }
#         content = self._call()
#         return content


@magento
class AttributeSetDelayedBatchImporter(DelayedBatchImporter):
    _model_name = ['magento.attribute.set']


@magento
class AttributeSetImporter(MagentoImporter):
    _model_name = ['magento.attribute.set']
    
    def _import_dependencies(self):
        record = self.magento_record
        if record.get('attribute_list',{}):
            for attribute_code in record['attribute_list'].keys():
                attribute = self.env['magento.product.attribute'].search([('backend_id','=',self.backend_record.id),
                                                          ('magento_id','=',str(attribute_code))])
                if not attribute :
                    self._import_dependency(attribute_code,'magento.product.attribute')
            
    
    def _create(self, data):
        """ Create the OpenERP record """
        model = self.model.with_context(connector_no_export=True)
        group_obj = self.env['magento.attribute.group'].with_context(connector_no_export=True)
        binding = model.create(data)
        option_list = []
        if data.get('group_list') :
            for item in data.get('group_list'):
                check = group_obj.search([('magento_id', '=', item.get('attribute_group_id')),
                                          ('backend_id', '=', data.get('backend_id'))])
                if not check :
                    group = group_obj.create({'magento_id': item.get('attribute_group_id'),
                                                'sort_order': item.get('sort_order'),
                                                'attribute_list': item.get('attribute_list'),
                                                'attribute_set_id': binding.id,
                                                'backend_id': data.get('backend_id'),
                                                'name': item.get('attribute_group_name'), })
                else :
                    group = check[0]
                    group.with_context(connector_no_export=True).write({'magento_id': item.get('attribute_group_id'),
                                                                        'sort_order': item.get('sort_order'),
                                                                        'attribute_list': item.get('attribute_list'),
                                                                        'attribute_set_id': binding.id,
                                                                        'backend_id': data.get('backend_id'),
                                                                        'name': item.get('attribute_group_name')})
                option_list.append(group.id)
            check_link = group_obj.search([('id', 'not in', option_list),
                                            ('attribute_set_id', '=', binding.id),
                                            ('backend_id', '=',data.get('backend_id'))])
            check_link.with_context(connector_no_export=True).unlink()
        binding.create_new_field()
        _logger.debug('%s %d created from magento %s',
                      self.model._name, binding.id, self.magento_id)
        return binding


    def _update(self, binding, data):
        binding.with_context(connector_no_export=True).write(data)
        group_obj = self.env['magento.attribute.group']
        option_list = []
        if data.get('group_list'):
            for item in data.get('group_list'):
                check = group_obj.search([('magento_id','=',item.get('attribute_group_id')),
                                                                     ('attribute_set_id','=',binding.id),
                                                                     ('backend_id','=',data.get('backend_id'))])
                if not check:
                    group = group_obj.with_context(connector_no_export=True).create({
                                                                                     'magento_id':item.get('attribute_group_id'),
                                                                                     'sort_order':item.get('sort_order'),
                                                                                     'attribute_list': item.get('attribute_list'),
                                                                                     'attribute_set_id':binding.id,
                                                                                     'backend_id':data.get('backend_id'),
                                                                                     'name':item.get('attribute_group_name')
                                                                                     })
                else:
                    group = check[0]
                    group.with_context(connector_no_export=True).write({
                                                                        'magento_id':item.get('attribute_group_id'),
                                                                        'sort_order':item.get('sort_order'),
                                                                        'attribute_list': item.get('attribute_list'),
                                                                        'attribute_set_id':binding.id,
                                                                        'backend_id':data.get('backend_id'),
                                                                        'name':item.get('attribute_group_name')
                                                                        })
                option_list.append(group.id)
            check_link = group_obj.search([('id','not in',option_list),
                                           ('attribute_set_id','=',binding.id),
                                           ('backend_id','=',data.get('backend_id'))])
            check_link.with_context(connector_no_export=True).unlink()
            binding.create_new_field()
        _logger.debug('%s %d created from magento %s',
                      self.model._name, binding.id, self.magento_id)
        return binding

@magento
class AttributeSetImportMapper(ImportMapper):
    _model_name = 'magento.attribute.set'

    direct = [
        ('attribute_set_name', 'attribute_set_name'),
        ('attribute_set_id', 'magento_id'),
        ('sort_order', 'sort_order'),
        ('group_list', 'group_list'),
        ('attribute_list', 'attribute_list')]
         

    @mapping
    def backend_id(self, record):
        return {'backend_id': self.backend_record.id}


@magento
class AttributeSetDeleteSynchronizer(MagentoDeleter):
    _model_name = ['magento.attribute.set']


@magento
class AttributeSetExporter(MagentoExporter):
    _model_name = ['magento.attribute.set']
        
    def _should_import(self):
        "Attributes in magento doesn't retrieve infos on dates"
        return False
    
    #17th June 2017 : Ekta : Comment because of write api is not in product attribute set
#     def _after_export(self):
#         backend = self.binding_record.backend_id
#         session = ConnectorSession(self.env.cr, self.env.uid,
#                                    context=self.env.context)
#         env = get_environment(session, 'magento.attribute.set', backend.id)
#         importer = env.get_connector_unit(AttributeSetImporter)
#         importer.run(self.magento_id)  


@magento
class AttributeSetExportMapper(ExportMapper):
    _model_name = 'magento.attribute.set'

    direct = [
        ('attribute_set_name', 'attribute_set_name'),
    ]
    
    @mapping
    def sort_order(self,record):
        result = {}
        if record.sort_order :
            result.update({'sort_order':1})
        else :
            result.update({'sort_order':0})
        return result
            
    @mapping
    def skeletonSetId(self, record):
        tmpl_set_id = self.backend_record.attribute_set_tpl_id.id
        if tmpl_set_id:
            binder = self.get_binder_for_model('magento.attribute.set')
            magento_tpl_set_id = binder.to_backend(tmpl_set_id)
        else:
            raise FailedJobError((
                "\n\n'Attribute set template' field must be define on "
                "the Magento Global.\n\n"
                "Resolution: \n"
                "- Go to Magento > Settings > Globals > '%s'\n"
                "- Set the field Attribte set Tempalte\n"
                )% self.backend_record.name)
        return {'skeletonSetId': magento_tpl_set_id}
    
    @mapping
    def entity_type_id(self,record):
        """To create product type attribute set.""" 
        return {'entity_type_id':4}

class attribute_location(models.Model):
    _name = "attribute.location"
    _description = "Attribute Location"
    _order="sequence"
    _inherits = {'attribute.attribute': 'attribute_id'}

    
#     @api.multi
#     #@api.depends('attribute_group_id','attribute_set_id')
#     def _get_attribute_loc_from_group(self):
#         return self.env['attribute.location'].search([('attribute_group_id', 'in', self.ids)])

    attribute_id=fields.Many2one('attribute.attribute',string='Product Attribute',required=True,ondelete="cascade")
    attribute_set_id=fields.Many2one('attribute.set',related="attribute_group_id.attribute_set_id",string='Attribute Set',readonly=True,store=True)
    attribute_group_id=fields.Many2one(comodel_name='attribute.group',string='Attribute Group',required=True)
    sequence=fields.Integer(string='Sequence')
        
