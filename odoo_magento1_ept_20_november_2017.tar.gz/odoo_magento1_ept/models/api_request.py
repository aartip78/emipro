from openerp.addons.odoo_magento1_ept.python_library import oauth2 as oauth
import json
import socket
import requests
import logging
from openerp.addons.odoo_magento1_ept.models.backend.exception import (
                                                                   NetworkRetryableError,
                                                                   FailedJobError,
                                                                   )
from requests.exceptions import HTTPError
_logger = logging.getLogger(__name__)

def setup(backend):
    consumer = oauth.Consumer(key=backend.customer_key, secret=backend.customer_secret)
    token = oauth.Token(key=backend.token, secret=backend.secret)
        
    client = oauth.Client(consumer, token)
    return client

def req(backend,path,method='GET',data=None):
    client = setup(backend)
    api_url =  '%s%s'%(backend.location,path)
    headers = {'Accept': '*/*', 'Content-Type': 'application/json','Authorization':'Bearer %s'%backend.token}
    try :
        
        #resp, content = client.request(api_url,method=method, body=json.dumps(data),headers=headers)
       
        _logger.info('Data pass to Magento : %s'%data)
        if method == 'GET' :
            resp = requests.get(api_url,headers=headers,verify=False)
        elif method == 'POST':
            resp = requests.post(api_url,headers=headers,data=json.dumps(data),verify=False)
        elif method == 'DELETE':
            resp = requests.delete(api_url,headers=headers,verify=False)
        elif method == 'PUT' :
            resp = requests.put(api_url,headers=headers,data=json.dumps(data),verify=False)
        else :
            resp = requests.get(api_url,headers=headers,verify=False)
        content = resp.content
        _logger.info('Response status code from Magento : %s',
                     resp.status_code)
        print content
        print api_url
        print resp.status_code
        
        #if resp.status == 401 :
        if resp.status_code == 401:
            raise Warning('Given Credentials is incorrect, please provide correct Credentials.')
        if not resp.ok :
            if resp.headers.get('content-type').split(';')[0] == 'text/html' :
                raise FailedJobError("Content-type is not JSON \n %s : %s \n %s \n %s"%(resp.status_code,resp.reason,path,resp.content))
            else :
                response = json.loads(resp.content)
                response.update({'status_code':resp.status_code})
                raise HTTPError(str(response),response=response)      
                
        """
        if resp.status == 404:
            content_type=resp.get('content-type').split(';')[0]
            if content_type == "application/json" :
                raise FailedJobError(content)
            else :
                raise FailedJobError("%s : %s \n %s"%(resp.status,resp.reason,path)) 
        """
    except (socket.gaierror, socket.error, socket.timeout) as err :
        raise NetworkRetryableError(
                'A network error caused the failure of the job: '
                '%s' % err)
    return json.loads(content)