
from odoo import models, fields, api, _


class ir_model_fields(models.Model):

    _inherit = "ir.model.fields"
    
    field_description=fields.Char(string='Field Label',required=True,size=256,translate=True)