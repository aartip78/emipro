from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import datetime

class export_multi_products(models.TransientModel):
    _name = 'export.multi.products'
    _description = 'Wizard to export multiple products'
    
    @api.model
    def _get_product_ids(self):
        context=self.env.context or {}
        
        res = False
        if (context.get('active_model') == 'product.product' and
                context.get('active_ids')):
            res = context['active_ids']
        return res

             
    @api.model
    def _product_type_get(self):
        return [
            ('simple', 'Simple Product'),
            #('configurable', 'Configurable Product'),
            # XXX activate when supported
            # ('grouped', 'Grouped Product'),
            # ('virtual', 'Virtual Product'),
            # ('bundle', 'Bundle Product'),
            # ('downloadable', 'Downloadable Product'),
        ]


    product_ids=fields.Many2many('product.product', string='Jobs',default=_get_product_ids)   
    product_type = fields.Selection(_product_type_get, 'Magento Product Type',required=True, default='simple')
    backend_id = fields.Many2one('magento.backend', 'Magento Backend', required=True, ondelete='restrict')
    website_m2m_ids = fields.Many2many('magento.website',string='Websites',domain="[('backend_id','=',backend_id)]")
    @api.multi
    def export(self):      
#         context=self.env.context or {}        
#         res = False
#         if (context.get('active_model') == 'product.product' and
#                 context.get('active_ids')):
#             res = context['active_ids']
#             print "res : %s"%(res)
#             for product in self.env['product.product'].browse(res):
#                 print product.id
#                 if product.default_code and product.attribute_set_id:
#                     #print product.default_code                
#                     #print product.attribute_set_id.id
        for wizard in self:
            products = self.env['product.product'].search([('attribute_set_id.magento_bind_ids.backend_id','=',wizard.backend_id.id)])
            if set(wizard.product_ids.ids)-set(products.ids) :
                raise ValidationError('In a few products proper attribute set is not selected. \n Please select proper attribute set.')
            for product in wizard.product_ids:
                if product.default_code and product.attribute_set_id:
                    print "m_b_i : %s "%(product.magento_bind_ids.id)
                    if not product.magento_bind_ids.id:
                        magento_product=self.env['magento.product.product']
                        obj=magento_product.create({'openerp_id':product.id,'backend_id':wizard.backend_id.id,'website_ids':[((6,0, wizard.website_m2m_ids.ids))],
                                            'created_at': datetime.now(),'updated_at':datetime.now(),'product_type':wizard.product_type})
#                       self._cr.execute("UPDATE magento_product_product SET magento_id = null WHERE id=%s"%(obj.id))
                        print obj
        return {'type': 'ir.actions.act_window_close'}
