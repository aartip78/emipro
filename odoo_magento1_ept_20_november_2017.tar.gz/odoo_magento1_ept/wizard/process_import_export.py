from odoo import models, fields, api
import logging
_logger = logging.getLogger(__name__)

class magento_process_import_export(models.TransientModel):
    _name = 'magento.process.import.export'
   
    backend_ids = fields.Many2many("magento.backend",'magento_backend_import_export_rel','process_id','backend_id',"Instances")
    import_customers_group = fields.Boolean('Customer Groups')
    import_customers = fields.Boolean('Customers')
    import_product_category = fields.Boolean('Products Categories')
    import_products = fields.Boolean('Products')
    import_sale_order = fields.Boolean('Sale order')
    export_inventory = fields.Boolean('Export Inventory')
        
    @api.model
    def default_get(self,fields):
        res = super(magento_process_import_export,self).default_get(fields)
        if 'backend_ids' in fields:
            backend_ids = self.env['magento.backend'].search([])
            res.update({'backend_ids':[(6,0,backend_ids.ids)]})
        return res
    
    @api.multi
    def import_export_processes(self):
        for backend in self.backend_ids:
            if self.import_customers_group:
                backend.import_customer_groups()
            if self.import_customers:
                backend.import_partners()
            if self.import_product_category:
                backend.import_product_categories()  
            if self.import_products:
                backend.import_product_product()
            if self.import_sale_order:
                backend.import_sale_orders()
            if self.export_inventory:
                backend.update_product_stock_qty()
                
        return True
