from openerp import models, fields,api


class magento_job_config(models.TransientModel):
    
    _name ='queue.done.job'
    _description ='Wizard to done a mutliple  jobs'
    
    
    @api.model
    def _default_job_ids(self):
        res = False
        context = self.env.context
        if (context.get('active_model') == 'queue.job' and
                context.get('active_ids')):
            res = context['active_ids']
        return res
    


    
    job_ids = fields.Many2many(comodel_name='queue.job',
                               string='Jobs',
                               default=_default_job_ids)
    
    @api.multi
    def button_done(self):
        jobs=self.job_ids
        jobs.button_done()
        return {'type': 'ir.actions.act_window_close'}

    
    