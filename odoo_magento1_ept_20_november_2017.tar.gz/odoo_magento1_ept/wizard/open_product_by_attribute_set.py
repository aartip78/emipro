from odoo import models, fields, api, _

class open_product_by_attribute_set(models.TransientModel):
    _name = 'open.product.by.attribute.set'
    _description = 'Wizard to open product by attributes set'

    attribute_set_id=fields.Many2one(comodel_name='attribute.set',string='Attribute Set')
        
    @api.multi
    def open_product_by_attribute(self):
        """
        Opens Product by attributes
        @param cr: the current row, from the database cursor,
        @param uid: the current user's ID for security checks,
        @param ids: List of account chart's IDs
        @return: dictionary of Product list window for a given attributes set
        """
        context=dict(self._context) or {}
        mod_obj = self.env['ir.model.data']
        act_obj = self.env['ir.actions.act_window']
        if context is None:
            context = {}
        attribute_set = self.browse(self.ids[0]).attribute_set_id
        result = mod_obj.get_object_reference('product', 'product_normal_action')
        id = result[1] if result else False #act_obj.search([('id','=',122)])
        #result = act_obj.read([id])[0]
        
        result=act_obj.search([('id','=',122)])
        result=result.read()[0]
        grps = self.env['attribute.group'].search([('attribute_set_id', '=', attribute_set.id)])
        grp_ids=[x.id for x in grps]
        ctx = "{'open_product_by_attribute_set': %s, \
              'attribute_group_ids': %s}" % (True, grp_ids)
        result['context'] = ctx
        result['domain'] = "[('attribute_set_id', '=', %s)]" % attribute_set.id
        result['name'] = attribute_set.name
        return result


